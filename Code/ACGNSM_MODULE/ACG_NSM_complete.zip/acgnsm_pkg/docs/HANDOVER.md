# ACG-NSM-guided TransFuser++ — Handover

## Goal
A new paper: **ACG-NSM-guided TransFuser++**, compared against TransFuser++ alone
and other models, on identical CARLA routes.

TransFuser++ (frozen, published weights) produces a **nominal** decision.
ACG-NSM produces a **conservative** decision. A disagreement layer suppresses the
nominal toward the conservative before actuation. ACG-NSM never vetoes; it
suppresses proportionally.

    u* = u_N - lambda * max(0, u_N - u_C)     lambda = 2/3 fixed

Worked examples (both reproduce exactly in code):
  nominal 60, conservative 30 -> execute 40
  nominal 60, conservative  0 -> execute 20

## Environment (working, verified)
- WSL2, conda env `carlaenv`, Python 3.10
- torch 2.5.1+cu121, CUDA True, RTX 4060 Laptop, **8188 MiB VRAM (tight)**
- numpy 1.26.4 (must stay <2, opencv 4.6 ABI), ultralytics 8.4.75
- CARLA 0.9.15 server on Windows at **192.168.144.1:2000**
  CARLA_ROOT=/mnt/d/CARLA_0.9.15/WindowsNoEditor
- carla_garage at /mnt/d/carla_garage, TransFuser++ weights load strict=True
  (120.7M params, single seed used; 3-seed ensemble does not fit in 8 GB)
- WSL has **no outbound network** (timm pretrained download patched off)

### Patches applied to carla_garage (backups exist alongside)
- `team_code/sensor_agent.py` — two lines exposing the planner's target speed
  and speed distribution (`_last_speed_distribution`, `_last_target_speed_scalar`)
- `team_code/transfuser.py` — `pretrained=True` -> `False` (no network in WSL)

## Baseline measured (TransFuser++ alone, devtest, Town12)
| route | status | driving | route % | infraction |
|---|---|---|---|---|
| RouteScenario_0 | blocked | 9.81 | 25.15 | 0.39 |
| RouteScenario_1 | completed | 0.91 | 100.00 | 0.01 |

8 collisions total. **Zero red-light, zero stop-sign violations.**
Collision forensics: 2 static vegetation, 1 stop sign, 5 vehicles in a line at
x≈-1340 over ~70 m (a sustained scrape, not a surprise cut-in).
=> the failures are physical, not legal; and they were all perceivable.

## Findings that shaped the design
1. **Binary fail-safe made the conservative channel override 99.8% of ticks.**
   Any distrust asserted a hazard, removed the permission, demanded a stop.
   Nothing of the nominal behaviour survived, so no arbitration was observable.
2. **Graded fail-safe fixes it.** Distrust becomes a depth
   delta=(theta-c)/theta; below a commitment threshold tau it inflates risk
   continuously, above it asserts the hazard as before. tau=0 reproduces the
   old binary behaviour exactly. Monotonicity verified: speed never rises as
   confidence falls.
3. **Constant absence confidence was a bug.** Non-detections were asserted at a
   fixed 0.617, below every gate threshold, so every tick became a hazard.
   Replaced with a Bayesian posterior from measured observation quality
   (LiDAR coverage, image visibility, effective range) and the detector's
   measured miss rate (1-recall=0.088). Range now 0.963 (clear) to 0.694 (poor).
4. **The Town10 detector does not transfer to Town12.** On a Town12 frame it
   returns almost only traffic signs: no pedestrians, no lights, one vehicle
   below conf 0.01. Two causes: severe class imbalance in the original dataset
   (pedestrian 352 instances, 1.0%) and an aspect-ratio mismatch (trained ~16:9,
   inference 1024x256 at FOV 110).
5. **Town12 will not load on 8 GB** (6.6 GB used at idle with Town10 alone).
   Decision: complete the architecture on Town10 first, retrain later.
6. **The first full collection run under-delivered pedestrians, and was
   clear-noon only.** See the section below — five defects, all now fixed in
   revision 2 of the collector.

## Data collection — run 1 (Town10HD_Opt, 10000 frames) and what it exposed

Command run: `--frames 10000 --vehicles 65 --walkers 100 --min_px 6`
into `data/town10_train_latest`. Result, 119675 instances:

| class | instances | share |
|---|---|---|
| pedestrian | 2991 | 2.5% |
| vehicle | 45776 | 38.3% |
| light_red | 20613 | 17.2% |
| light_yellow | 1866 | 1.6% |
| light_green | 6249 | 5.2% |
| cyclist | 9404 | 7.9% |
| traffic_sign | 32776 | 27.4% |

Pedestrians rose from 352 to 2991 instances (8.5x), but only to 0.3 per frame,
and every frame is ClearNoon. Five defects were responsible:

- **(a) No weather control at all.** The collector never called `set_weather()`,
  so every frame inherited whatever state the server was left in. The accuracy
  cost is secondary to the calibration cost: the absence model's miss rate
  (finding 3) would be measured on clear noon and then applied at dusk in rain,
  making the distrust channel most confident exactly where it has least right
  to be.
- **(b) The semantic camera is lighting-invariant.** This is the trap that makes
  naive night collection actively harmful. Segmentation renders object IDs, not
  photons, so at midnight or in dense fog a pedestrian at 40 m still produces a
  crisp blob and the revision-1 visibility test passes — writing a tight box
  over a region of RGB containing no evidence. That trains the detector to emit
  boxes from sensor noise.
- **(c) `light_red` was in the rare-class set.** The retention rule kept every
  frame containing a rare class and subsampled the rest, but light_red finished
  at 17.2%. The retention budget was spent on signals, so the pedestrian
  oversampling never engaged.
- **(d) Walkers were spawned once, around the ego's starting pose.** The
  forward-cone filter was right but applied only at spawn. The ego then drove
  autopilot for ~33 sim-minutes and left the cluster inside the first minute.
  This is the dominant cause of the pedestrian shortfall.
- **(e) `finish()` crashed** on `self.tag_evidence`, which is never assigned —
  so `collection_stats.json` was never written and run 1 ended on an
  AttributeError after the last frame. Related: `dataset.yaml` set `val` to the
  same directory as `train`, which would make any measured recall optimistic.
  Since the absence-confidence posterior is calibrated on that number, the
  error propagates straight into the safety argument.

### Revision 2 of the collector (`60_collect_town1213.py`)
- Weather cycles through presets plus explicit fog variants (stock presets carry
  no meaningful fog), every `--weather_every` kept frames, with settle ticks so
  no frame is written under a stale weather label. Vehicle lights driven by the
  traffic manager at night.
- Every candidate box passes a **photometric gate** on the RGB patch: peak
  luminance floor, RMS contrast, and Michelson contrast against the surrounding
  annulus *plus an absolute luminance delta* — Michelson alone is scale-free, so
  at near-zero luminance a one-grey-level difference reads as 0.13 contrast and
  an unlit pedestrian on unlit asphalt would pass a daylight threshold.
  Validated against ten synthetic day/night/fog/noise cases.
- Statistics for **every** candidate, kept or dropped, are written to `meta/`.
  The threshold is therefore a post-processing choice: re-filter offline with
  `61_merge_split.py` instead of re-running CARLA. This also makes the
  "GT-present but photometrically invisible" population directly measurable,
  which is the population the absence model is trying to reason about.
- Rare set is now `pedestrian,cyclist,light_yellow`; walkers are relocated ahead
  of the moving ego every `--walker_refresh` kept frames; `finish()` fixed;
  segment-held-out split emitted, and it refuses to silently point val at train.

## Current state of the pipeline
WORKING
- TransFuser++ runs unmodified on official leaderboard routes (local evaluator)
- Guided agent wraps it, logs a witness record per tick, never touches steering
- Graded bridge, suppression arbiter, absence model — all built and unit-tested
- Data collection with auto-labelling — validated; per-light colour assignment
  correct (red/green distinguished in one frame)
- Run 1 complete: 10000 clear-noon frames in `data/town10_train_latest`

NOT YET DONE
- Weather/night supplement run (~5000 frames) — command below
- Merge + block-split into the union set, then detector retrain on the
  planner's rig with balanced classes
- Dual-perception channel (ACG-NSM run twice per tick: once on TransFuser++'s
  own detections, once on its independent detector)
- Guided run with ACGNSM_ARBITRATE=1 and the comparison matrix

## Next commands
```bash
# 0. smoke test the revised collector FIRST -- fast weather cycle, 60 frames
cd /mnt/d/NSTM_Project
python src/60_collect_town1213.py --host 192.168.144.1 --town Town10HD_Opt \
  --tm_port 8100 --frames 60 --vehicles 40 --walkers 80 --min_px 6 \
  --weather cycle --weather_every 6 --walker_refresh 10 \
  --out /mnt/d/NSTM_Project/data/wx_smoke
# expect: several [weather] segment lines incl. a Night and a Fog entry;
# a non-zero "dropped unlit/fog" count concentrated in the dark segments;
# pedestrian share well above 2.5%.

# 1. the supplement (unattended, few hours)
python src/60_collect_town1213.py --host 192.168.144.1 --town Town10HD_Opt \
  --tm_port 8100 --frames 5000 --vehicles 65 --walkers 100 --min_px 6 \
  --weather cycle --weather_every 40 \
  --out /mnt/d/NSTM_Project/data/town10_weather

# 2. merge with run 1 and build the block-held-out split
python src/61_merge_split.py \
  --src /mnt/d/NSTM_Project/data/town10_train_latest \
  --src /mnt/d/NSTM_Project/data/town10_weather \
  --out /mnt/d/NSTM_Project/data/town10_union --val_frac 0.12
# train against data/town10_union/dataset.yaml

# observe-only guided run (logs disagreement, changes nothing)
ACGNSM_AGENT=/mnt/d/NSTM_Project/src/53_guided_agent.py ACGNSM_ARBITRATE=0 \
OUT=/mnt/d/NSTM_Project/results/observe \
  bash src/43_run_dual_channel.sh 2>&1 | grep -v "^=== \[Agent\]"

# guided run (applies suppression) -- the model under test
ACGNSM_AGENT=/mnt/d/NSTM_Project/src/53_guided_agent.py ACGNSM_ARBITRATE=1 \
OUT=/mnt/d/NSTM_Project/results/guided \
  bash src/43_run_dual_channel.sh 2>&1 | grep -v "^=== \[Agent\]"
```

## Open decisions
- **Routes.** Devtest is Town12 (detector out of domain). Need Town10 routes:
  check Bench2Drive / routes_training for Town10 coverage. A new TransFuser++
  baseline is required on whichever routes are chosen — the 9.81/0.91 numbers
  are Town12-specific and do not transfer.
- **Evaluation weather.** Undecided, which is why the training distribution now
  covers the range rather than assuming clear noon. Whatever is chosen must be
  stated as the operational design domain, and the absence model must be
  calibrated on val frames from the *same* conditions.
- **Hard constraints.** Current policy is pure suppression (`ACGNSM_POLICY=suppress`),
  never overriding even when the conservative channel demands a stop. A `guard`
  policy exists behind one env var for comparison. Decided by measurement.
- **Known label limitations.** Segmentation gives no instance separation, so
  adjacent lamps on one pole can merge; very distant lights fall below min_px.

## Caveats to carry into the paper
- Single-seed TransFuser++, not the published 3-seed ensemble. Compare only
  against your own baseline, never against published leaderboard numbers.
- ACG-NSM reads the same camera and LiDAR streams as the planner but shares no
  features: independent perception **models**, shared sensor front-end. That is
  analytic redundancy, not sensor redundancy. State it precisely.
- The state machine is authored for a signalized left turn; on open routes it
  sits mostly in APPROACH driven by risk events. Say so rather than implying a
  cruise state exists.
- TransFuser++ has its own uncertainty brake and geometric safety box. The
  witness log separates them from ACG-NSM's suppression so caution the planner
  already exercises is not credited to us.
- **Recall must be reported per condition, not pooled.** A single aggregate
  miss rate hides the fact that the detector is far weaker at night and in fog,
  and the absence model consumes that number directly. Report it by weather
  bucket, and calibrate the posterior accordingly.
