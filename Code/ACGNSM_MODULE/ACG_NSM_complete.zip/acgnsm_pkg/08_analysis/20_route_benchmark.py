"""
20_route_benchmark.py
=====================
Phase 8 Step 5: Multi-route closed-loop benchmark (CARLA Leaderboard-style).

Drives the ego over N predefined routes and computes the standard CARLA metrics:
  - Route Completion (RC): fraction of route distance covered
  - Infraction Score (IS):  product of per-infraction penalty coefficients
  - Driving Score (DS):     RC * IS  (the headline number)

Runs each route under a chosen configuration (full / ablations), so the same
benchmark can compare the full system against ablated variants -- showing that
the full system has the highest Infraction Score (fewest violations), which is
the paper's thesis quantified on a standard benchmark.

This reuses the live closed-loop stack (perception/bridge/STM/control) and the
RunMetrics infrastructure. Routes are auto-generated from CARLA spawn points so
the benchmark is reproducible on Town10HD without external route files.

Usage:
  python src/20_route_benchmark.py --host 192.168.144.1 --stm .../libstm.so \
         --config full --n_routes 10 --no_perception
"""
import sys, os, json, time, math, argparse, random
import numpy as np

# CARLA Leaderboard penalty coefficients (per infraction event)
PENALTY = {
    'collision_pedestrian': 0.50,
    'collision_vehicle':    0.60,
    'collision_static':     0.65,
    'red_light':            0.70,
    'stop_sign':            0.80,
    'failed_yield':         0.70,   # our addition: failure to yield right-of-way
}


def compute_infraction_score(infractions):
    """IS = product of penalty coefficients for each infraction event."""
    score = 1.0
    for inf_type, count in infractions.items():
        coeff = PENALTY.get(inf_type, 0.9)
        score *= (coeff ** count)
    return max(score, 0.0)


def route_length(waypoints):
    """Total length of a route in metres."""
    d = 0.0
    for i in range(1, len(waypoints)):
        a = waypoints[i-1].transform.location
        b = waypoints[i].transform.location
        d += math.hypot(b.x - a.x, b.y - a.y)
    return d


def run_one_route(world, cmap, bl, tm, args, stm_lib_path, route_idx_seed):
    """Drive one route; return (RC, IS, DS, detail)."""
    import carla
    # late imports of the project modules (reuse closed-loop building blocks)
    import importlib.util
    def _load(name, path):
        spec = importlib.util.spec_from_file_location(name, path)
        m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
    SRC = '/mnt/d/NSTM_Project/src'
    bridge_mod  = _load('bridge',  f'{SRC}/13_rlc_bridge.py')
    adapter_mod = _load('adapter', f'{SRC}/14_stm_adapter.py')
    metrics_mod = _load('metrics', f'{SRC}/17_metrics.py')

    bp = bl.filter('vehicle.tesla.model3')[0]
    sps = cmap.get_spawn_points()
    rng = random.Random(route_idx_seed)
    rng.shuffle(sps)

    # spawn ego
    ego = None
    for sp in sps:
        ego = world.try_spawn_actor(bp, sp)
        if ego: break
    if ego is None:
        return None
    world.tick()

    # build a route: follow the road for a fixed distance, choosing the straightest
    # continuation at junctions (random turns can produce tiny looping routes).
    start_wp = cmap.get_waypoint(ego.get_location())
    route = [start_wp]; wp = start_wp
    target_len = 120.0  # metres per route
    while route_length(route) < target_len:
        nxts = wp.next(3.0)
        if not nxts:
            break
        if len(nxts) > 1:
            cur_yaw = wp.transform.rotation.yaw
            def yaw_diff(c):
                d = (c.transform.rotation.yaw - cur_yaw + 180) % 360 - 180
                return abs(d)
            wp = min(nxts, key=yaw_diff)
        else:
            wp = nxts[0]
        route.append(wp)
    total_len = route_length(route)
    # skip implausibly short routes (dead-end at spawn): unusable for benchmarking
    if total_len < 40.0:
        try:
            ego.destroy()
        except Exception:
            pass
        return "SKIP"

    # Freeze a traffic light AHEAD on this route to RED, so every route exercises
    # signal compliance. Read this light directly (CARLA ego-association is unreliable).
    scenario_light = None
    ego_fwd0 = ego.get_transform().get_forward_vector()
    # find the junction ahead and the light nearest it
    jx, jy = ego.get_location().x, ego.get_location().y
    jwp = start_wp
    for _s in range(25):
        nn = jwp.next(3.0)
        if not nn: break
        jwp = nn[0]
        if jwp.is_junction:
            jx, jy = jwp.transform.location.x, jwp.transform.location.y
            break
    best_d = 1e9
    for t in world.get_actors().filter('traffic.traffic_light'):
        tl = t.get_location()
        dd = math.hypot(tl.x-jx, tl.y-jy)
        if dd < best_d and dd < 35:
            best_d = dd; scenario_light = t
    if scenario_light is not None:
        scenario_light.set_state(carla.TrafficLightState.Red)
        scenario_light.set_red_time(9999.0); scenario_light.freeze(True)

    # sensors: collision + lane invasion
    collisions = []
    col_bp = bl.find('sensor.other.collision')
    col = world.spawn_actor(col_bp, carla.Transform(), attach_to=ego)
    col.listen(lambda e: collisions.append(e))

    # set up pipeline
    bridge = bridge_mod.RLCBridge(weather='clear', ablation=args.config)
    stm = adapter_mod.STMAdapter(stm_lib_path); stm.init()
    metrics = metrics_mod.RunMetrics(args.config)

    # NPC traffic for realism
    npcs = []
    for sp in sps[5:5+args.n_npcs]:
        v = world.try_spawn_actor(rng.choice(bl.filter('vehicle.*')), sp)
        if v:
            v.set_autopilot(True, tm.get_port()); npcs.append(v)

    # simple controller (reuse logic: target speed by STM state)
    def speed_kmh():
        v = ego.get_velocity(); return 3.6*math.hypot(v.x, v.y)

    infractions = {'red_light':0, 'collision_pedestrian':0, 'collision_vehicle':0,
                   'collision_static':0, 'failed_yield':0}
    reached_idx = 0
    max_ticks = args.ticks_per_route
    last_wp_passed = 0
    stuck_counter = 0
    prev_pos = ego.get_location()
    red_run_latched = False
    stopline_done = False
    green_released = False
    red_hold_ticks = 0

    for tick in range(max_ticks):
        world.tick()
        speed = speed_kmh()

        # perception (GT mode if --no_perception)
        obs_dist = -1.0
        for a in world.get_actors().filter('vehicle.*'):
            if a.id == ego.id: continue
            d = a.get_location().distance(ego.get_location())
            ef = ego.get_transform().get_forward_vector()
            dx = a.get_location().x - ego.get_location().x
            dy = a.get_location().y - ego.get_location().y
            n = max(math.hypot(dx,dy),1e-6)
            if ef.x*(dx/n)+ef.y*(dy/n) > 0.5 and d < 40:
                obs_dist = d if obs_dist < 0 else min(obs_dist, d)

        # signal: read the frozen scenario light DIRECTLY (robust), but only when the
        # ego is actually approaching that junction (within range and ahead)
        signal = -1
        if scenario_light is not None:
            ll = scenario_light.get_location(); el = ego.get_location()
            d_light = math.hypot(ll.x-el.x, ll.y-el.y)
            ef = ego.get_transform().get_forward_vector()
            dx, dy = jx-el.x, jy-el.y; nn = max(math.hypot(dx,dy),1e-6)
            ahead = ef.x*(dx/nn)+ef.y*(dy/nn)
            if d_light < 35 and ahead > -0.2:   # near the controlled junction
                st = scenario_light.get_state()
                signal = {carla.TrafficLightState.Red:0, carla.TrafficLightState.Green:1,
                          carla.TrafficLightState.Yellow:2}.get(st, -1)

        perc_signal = -1 if args.config == 'risk_only' else signal
        perc = {'obs_dist': (obs_dist, 0.95 if obs_dist>0 else 0.95),
                'ego_speed': (speed, 0.95),
                'pedestrian': (False, 0.95),
                'traffic_light': (perc_signal, 0.95),
                'oncoming': (False, 0.92)}
        bout = bridge.process(perc, {'speed_limit': 50})

        wp_now = cmap.get_waypoint(ego.get_location())
        # distance to the controlled junction ahead
        el2 = ego.get_location()
        dist_to_junc = math.hypot(jx-el2.x, jy-el2.y)
        near_line = dist_to_junc < 12.0   # approaching the stop line
        # risk_only has NO legal reasoning of any kind, so the signal is not
        # available to the decision layer (neither via legality nor via the adapter).
        stm_signal = -1 if args.config == 'risk_only' else signal
        flags = {'stopline_reached': near_line and not stopline_done,
                 'at_stopline': near_line or wp_now.is_junction,
                 'signal': stm_signal, 'oncoming': False, 'pedestrian': False,
                 'current_state': stm.state_name(),
                 'committed_to_turn': wp_now.is_junction}
        if near_line:
            stopline_done = True
        result = stm.step_from_bridge(bout, flags)

        # control
        state = result['state_name']; action = result['action']
        if action in ('EmergBrake',) or state in ('BRAKE_HOLD','YIELD_WAIT'):
            ctrl = carla.VehicleControl(throttle=0.0, brake=0.8)
        else:
            tgt = 25.0 if state not in ('APPROACH','ASSESS_YIELD','TURNING') else 14.0
            thr = 0.5 if speed < tgt else 0.0
            # steer toward next route waypoint
            steer = 0.0
            if reached_idx < len(route)-1:
                tw = route[min(reached_idx+2, len(route)-1)].transform.location
                veh = ego.get_transform(); yaw = math.radians(veh.rotation.yaw)
                dx = tw.x - veh.location.x; dy = tw.y - veh.location.y
                lx = math.cos(-yaw)*dx - math.sin(-yaw)*dy
                ly = math.sin(-yaw)*dx + math.cos(-yaw)*dy
                if lx < 0.01: lx = 0.01
                ld = math.hypot(lx, ly)
                steer = float(np.clip(2.0*ly/(ld*ld)*3.0, -1.0, 1.0))
            ctrl = carla.VehicleControl(throttle=float(thr), brake=0.0, steer=steer)
        ego.apply_control(ctrl)

        # advance route progress
        ego_loc = ego.get_location()
        while reached_idx < len(route)-1 and \
              route[reached_idx].transform.location.distance(ego_loc) < 4.0:
            reached_idx += 1

        # red-light infraction: entered the controlled junction while the light is
        # still red AND has not been released to green. Count ONCE per crossing.
        if wp_now.is_junction and signal == 0 and (not green_released) and speed > 3.0:
            if not red_run_latched:
                infractions['red_light'] += 1
                red_run_latched = True
        if not wp_now.is_junction:
            red_run_latched = False

        # Realistic signal cycle: once the car has stopped at the red light, turn it
        # green after a short hold so the car can proceed (mirrors a normal red->green
        # phase). Robust trigger: any sustained stop while red is plausibly the reason.
        if scenario_light is not None and not green_released:
            el3 = ego.get_location()
            d_to_junc = math.hypot(jx-el3.x, jy-el3.y)
            stopped_for_red = (speed < 1.0) and (signal == 0 or d_to_junc < 15.0)
            if stopped_for_red:
                red_hold_ticks += 1
            if red_hold_ticks > 25 or (speed < 1.0 and red_hold_ticks > 0 and tick > 60):
                scenario_light.set_state(carla.TrafficLightState.Green)
                green_released = True

        # collisions
        for ce in collisions:
            other = ce.other_actor.type_id if hasattr(ce,'other_actor') else ''
            if 'walker' in other: infractions['collision_pedestrian'] += 1
            elif 'vehicle' in other: infractions['collision_vehicle'] += 1
            else: infractions['collision_static'] += 1
        collisions.clear()

        # stuck detection -> end route early
        if ego_loc.distance(prev_pos) < 0.05:
            stuck_counter += 1
        else:
            stuck_counter = 0
            prev_pos = ego_loc
        if stuck_counter > 80:  # stuck ~4s
            break

        if reached_idx >= len(route)-2:
            break

    # cleanup (ordered to avoid dangling-callback crash)
    try: col.stop()
    except: pass
    try: world.tick()
    except: pass
    time.sleep(0.1)
    try: col.destroy()
    except: pass
    for a in npcs+[ego]:
        try: a.destroy()
        except: pass
    time.sleep(0.05)

    # compute metrics
    covered = route_length(route[:reached_idx+1])
    RC = min(covered / max(total_len, 1.0), 1.0)
    # dedupe infraction counts (collisions can fire repeatedly per event)
    infr_dedup = {k: (1 if v>0 else 0) if 'collision' in k else v
                  for k,v in infractions.items()}
    IS = compute_infraction_score(infr_dedup)
    DS = RC * IS
    return RC, IS, DS, infr_dedup


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--host', default='127.0.0.1')
    ap.add_argument('--port', type=int, default=2000)
    ap.add_argument('--stm', required=True)
    ap.add_argument('--config', default='full')
    ap.add_argument('--n_routes', type=int, default=10)
    ap.add_argument('--ticks_per_route', type=int, default=600)
    ap.add_argument('--n_npcs', type=int, default=8)
    ap.add_argument('--no_perception', action='store_true')
    ap.add_argument('--out', default='/mnt/d/NSTM_Project/results/route_benchmark.json')
    args = ap.parse_args()

    import carla
    client = carla.Client(args.host, args.port); client.set_timeout(30.0)
    world = client.get_world(); cmap = world.get_map(); bl = world.get_blueprint_library()
    tm = client.get_trafficmanager(); tm.set_synchronous_mode(True)
    settings = world.get_settings()
    settings.synchronous_mode = True; settings.fixed_delta_seconds = 0.05
    world.apply_settings(settings)

    print(f"=== ROUTE BENCHMARK: config={args.config}, {args.n_routes} routes ===")
    rcs, iss, dss = [], [], []
    all_infr = {}
    completed = 0
    attempt_seed = 0
    # keep attempting routes (with fresh seeds) until we have n_routes valid ones
    while completed < args.n_routes and attempt_seed < args.n_routes * 4:
        res = run_one_route(world, cmap, bl, tm, args, args.stm, route_idx_seed=attempt_seed)
        attempt_seed += 1
        if res is None:
            print(f"  (seed {attempt_seed-1}: spawn failed, retrying)"); continue
        if res == "SKIP":
            print(f"  (seed {attempt_seed-1}: route too short/dead-end, retrying)"); continue
        RC, IS, DS, infr = res
        rcs.append(RC); iss.append(IS); dss.append(DS)
        for k,v in infr.items(): all_infr[k] = all_infr.get(k,0)+v
        print(f"  route {completed}: RC={RC:.1%}  IS={IS:.2f}  DS={DS*100:.1f}  infractions={ {k:v for k,v in infr.items() if v} }")
        completed += 1

    # restore async
    settings.synchronous_mode = False; world.apply_settings(settings)
    tm.set_synchronous_mode(False)

    summary = {
        'config': args.config, 'n_routes': len(rcs),
        'route_completion_mean': float(np.mean(rcs))*100 if rcs else 0,
        'route_completion_std': float(np.std(rcs))*100 if rcs else 0,
        'infraction_score_mean': float(np.mean(iss)) if iss else 0,
        'driving_score_mean': float(np.mean(dss))*100 if dss else 0,
        'driving_score_std': float(np.std(dss))*100 if dss else 0,
        'total_infractions': all_infr,
    }
    print("\n=== SUMMARY ===")
    print(f"  Route Completion: {summary['route_completion_mean']:.1f}% ± {summary['route_completion_std']:.1f}")
    print(f"  Infraction Score: {summary['infraction_score_mean']:.3f}")
    print(f"  Driving Score:    {summary['driving_score_mean']:.1f} ± {summary['driving_score_std']:.1f}")
    print(f"  Total infractions across routes: {all_infr}")

    json.dump(summary, open(args.out, 'w'), indent=2)
    print(f"\nSaved: {args.out}")


if __name__ == '__main__':
    main()
