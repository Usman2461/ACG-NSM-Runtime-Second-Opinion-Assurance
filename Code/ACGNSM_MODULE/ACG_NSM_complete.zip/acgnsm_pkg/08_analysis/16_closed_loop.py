"""
16_closed_loop.py
=================
Phase 8 Step 1: Live closed-loop driving in CARLA under the full stack.

Architecture (full STM control):
  CARLA live sensors -> perception -> bridge -> compiled ZIPC STM -> motion layer -> vehicle

The STM decides the BEHAVIOR (approach/hold/yield/turning/abort).
The motion layer executes it: pure-pursuit steering along a precomputed
left-turn route + longitudinal control gated by the STM state.

Scenario: left_turn_signalized (the full TL_Main logic, live).

USAGE:
  python 16_closed_loop.py --host 192.168.144.1 --stm /mnt/d/NSTM_Project/stm/libstm.so
  (CARLA server must be running on Windows)

Requires: the assessors, bridge, adapter in src/, and libstm.so built.
"""
import sys, os, time, math, argparse, json
sys.path.insert(0, '/mnt/d/NSTM_Project/src')
import numpy as np
import carla

# ---- load our stack ----
import importlib.util
def _load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

SRC = '/mnt/d/NSTM_Project/src'
bridge_mod  = _load('bridge',  f'{SRC}/13_rlc_bridge.py')
adapter_mod = _load('adapter', f'{SRC}/14_stm_adapter.py')
metrics_mod = _load('metrics', f'{SRC}/17_metrics.py')

IMG_W, IMG_H, FOV = 800, 600, 90.0



class PIDSpeedController:
    """Smooth longitudinal control: PID on speed error -> throttle/brake."""
    def __init__(self, kp=0.25, ki=0.02, kd=0.01):
        self.kp, self.ki, self.kd = kp, ki, kd
        self._integral = 0.0
        self._prev_err = 0.0

    def reset(self):
        self._integral = 0.0; self._prev_err = 0.0

    def step(self, target_kmh, current_kmh, dt=0.05):
        err = target_kmh - current_kmh
        self._integral = max(-20, min(20, self._integral + err*dt))
        deriv = (err - self._prev_err)/dt if dt>0 else 0.0
        self._prev_err = err
        u = self.kp*err + self.ki*self._integral + self.kd*deriv
        # map control signal to throttle/brake
        if u >= 0:
            return min(u, 1.0), 0.0          # throttle
        else:
            return 0.0, min(-u*0.5, 1.0)     # brake (gentler factor)


# ============ Motion layer: pure-pursuit + longitudinal control ============
class MotionController:
    """Executes STM behavior as concrete throttle/brake/steer."""

    def __init__(self, vehicle, world_map):
        self.vehicle = vehicle
        self.map = world_map
        self.route = []          # list of carla.Waypoint
        self.route_idx = 0
        self.target_speed = 25.0 # km/h cruising
        self.pid = PIDSpeedController()
        self._last_steer = 0.0   # for smoothing

    def plan_straight_route(self):
        """Build a route that goes straight through the next junction."""
        start_wp = self.map.get_waypoint(self.vehicle.get_location())
        route = [start_wp]
        wp = start_wp
        for _ in range(80):
            nxts = wp.next(3.0)
            if not nxts:
                break
            # at a junction or fork, pick the continuation closest to straight ahead
            cur_yaw = wp.transform.rotation.yaw
            def straight_score(c):
                d = (c.transform.rotation.yaw - cur_yaw + 180) % 360 - 180
                return abs(d)   # smallest yaw change = straightest
            wp = min(nxts, key=straight_score)
            route.append(wp)
        self.route = route
        self.route_idx = 0
        return len(route)

    def plan_left_turn_route(self):
        """Build a route from current pos that includes a left turn."""
        start_wp = self.map.get_waypoint(self.vehicle.get_location())
        route = [start_wp]
        wp = start_wp
        # walk forward, taking a left at the first junction
        took_left = False
        for _ in range(80):
            nxts = wp.next(3.0)
            if not nxts:
                break
            if wp.is_junction and not took_left:
                # at junction, prefer the left-turning continuation
                best = None; best_yaw = -999
                cur_yaw = wp.transform.rotation.yaw
                for cand in nxts:
                    dyaw = (cand.transform.rotation.yaw - cur_yaw + 180) % 360 - 180
                    if dyaw < best_yaw or best is None:  # most negative = left
                        pass
                # pick the candidate that turns most to the left (yaw decreasing)
                def left_score(c):
                    d = (c.transform.rotation.yaw - cur_yaw + 180) % 360 - 180
                    return d   # left turn = negative
                best = min(nxts, key=left_score)
                route.append(best); wp = best; took_left = True
            else:
                wp = nxts[0]; route.append(wp)
        self.route = route
        self.route_idx = 0
        return len(route)

    def _nearest_route_point_ahead(self, lookahead=5.0):
        loc = self.vehicle.get_location()
        # advance idx past points we've passed
        while self.route_idx < len(self.route)-1:
            wp = self.route[self.route_idx]
            if wp.transform.location.distance(loc) < 3.0:
                self.route_idx += 1
            else:
                break
        # find a point ~lookahead ahead
        for i in range(self.route_idx, len(self.route)):
            if self.route[i].transform.location.distance(loc) >= lookahead:
                return self.route[i]
        return self.route[-1] if self.route else None

    def pure_pursuit_steer(self):
        """Speed-adaptive pure-pursuit with steer smoothing."""
        speed = self._speed_kmh()
        # lookahead grows with speed: tight at low speed (sharp turns), longer fast
        lookahead = max(3.5, min(8.0, 2.0 + 0.35*speed))
        target = self._nearest_route_point_ahead(lookahead)
        if target is None:
            return self._last_steer
        veh_tf = self.vehicle.get_transform()
        veh_loc = veh_tf.location
        dx = target.transform.location.x - veh_loc.x
        dy = target.transform.location.y - veh_loc.y
        yaw = math.radians(veh_tf.rotation.yaw)
        local_x = math.cos(-yaw)*dx - math.sin(-yaw)*dy
        local_y = math.sin(-yaw)*dx + math.cos(-yaw)*dy
        if local_x <= 0.01:
            local_x = 0.01
        ld = math.hypot(local_x, local_y)
        curvature = 2.0 * local_y / (ld*ld)
        raw_steer = float(np.clip(curvature * 3.8, -1.0, 1.0))
        # smooth: blend with previous (low-pass) to avoid jerks
        steer = 0.6*raw_steer + 0.4*self._last_steer
        self._last_steer = steer
        return steer

    def control(self, stm_state_name, stm_action, risk_tier=0, gap=-1.0, highway=False):
        """Map STM behavior -> smooth carla.VehicleControl via PID.

        risk_tier and gap (optional) enable graduated adaptive-cruise following:
        on a SlowDown action or elevated risk, the target speed is reduced to keep
        a safe gap, rather than an all-or-nothing stop.

        highway=True: in low-risk cruise the ego holds highway speed (target_speed)
        rather than the low intersection-approach speed, so that adaptive following
        (slow with the lead, then resume) is exercised on an open road.
        """
        steer = self.pure_pursuit_steer()
        speed = self._speed_kmh()

        # decide TARGET speed from STM behavior (PID handles the smoothing)
        if stm_action in ('EmergBrake',) or stm_state_name == 'FAULT_EXIT':
            # hard emergency stop bypasses PID
            self.pid.reset()
            return carla.VehicleControl(throttle=0.0, brake=1.0, steer=float(steer))
        elif stm_action in ('Brake','Hold') or stm_state_name in ('BRAKE_HOLD','YIELD_WAIT'):
            target = 0.0
        elif stm_action == 'SlowDown' or risk_tier >= 2:
            # graduated adaptive-cruise slowdown: reduce speed to preserve a safe gap.
            if gap is not None and gap > 0:
                target = max(0.0, min(self.target_speed, (gap / 1.5) * 3.6))
                if risk_tier >= 3:
                    target = min(target, 8.0)   # near-collision: crawl
            else:
                target = 8.0 if risk_tier >= 3 else 18.0
        elif highway:
            # open-road cruise: hold highway speed whenever risk is low/medium
            target = self.target_speed
        elif stm_state_name == 'APPROACH':
            target = 14.0           # approach speed (intersection scenarios)
        elif stm_state_name == 'ASSESS_YIELD':
            target = 10.0           # slow while assessing/turning
        elif stm_state_name == 'TURNING':
            target = 12.0           # steady turn speed
        else:
            target = self.target_speed  # cruise

        if target <= 0.1:
            self.pid.reset()
            throttle, brake = 0.0, 0.7
        else:
            throttle, brake = self.pid.step(target, speed)

        return carla.VehicleControl(throttle=float(throttle), brake=float(brake),
                                    steer=float(steer))

    def _speed_kmh(self):
        v = self.vehicle.get_velocity()
        return 3.6*math.sqrt(v.x**2+v.y**2+v.z**2)


# ============ Perception (live, simplified for closed loop) ============
class LivePerception:
    """Runs YOLO + simple obstacle/signal extraction on live frames."""
    def __init__(self, model_path):
        from ultralytics import YOLO
        self.model = YOLO(model_path)
        self.latest = {'obs_dist': -1, 'pedestrian': False, 'oncoming': False}

    def process(self, image_bgr, lidar_pts, ego, world):
        # For closed-loop we use CARLA ground-truth-ish signals for speed/reliability,
        # but run YOLO for detection confidence (the gating signal).
        # (full LiDAR-projection perception is heavy per-tick; we use a hybrid)
        res = self.model(image_bgr, device=0, verbose=False, conf=0.25)[0]
        has_ped = any(int(b.cls)==0 for b in res.boxes)
        ped_conf = max([float(b.conf) for b in res.boxes if int(b.cls)==0], default=0.0)
        veh_conf = max([float(b.conf) for b in res.boxes if int(b.cls)==1], default=0.0)
        return has_ped, ped_conf, veh_conf


def get_signal_state(ego, world=None):
    # first try the direct association
    tl = ego.get_traffic_light()
    if tl is None and world is not None:
        # fallback: find nearest light ahead of the ego within 40m
        el = ego.get_location()
        ef = ego.get_transform().get_forward_vector()
        best = None; best_d = 40.0
        for t in world.get_actors().filter('traffic.traffic_light'):
            loc = t.get_location(); d = loc.distance(el)
            if d >= best_d: continue
            dx, dy = loc.x-el.x, loc.y-el.y; n = max(math.hypot(dx,dy),1e-6)
            if ef.x*(dx/n)+ef.y*(dy/n) > 0.3:   # roughly ahead
                best = t; best_d = d
        tl = best
    if tl is None: return -1
    st = tl.get_state()
    return {carla.TrafficLightState.Red:0, carla.TrafficLightState.Green:1,
            carla.TrafficLightState.Yellow:2}.get(st, -1)

def get_obs_dist(ego, world, max_range=60.0):
    el=ego.get_location(); ef=ego.get_transform().get_forward_vector(); best=max_range
    for a in world.get_actors():
        if a.id==ego.id: continue
        if not (a.type_id.startswith('vehicle') or a.type_id.startswith('walker')): continue
        loc=a.get_location(); d=loc.distance(el)
        if d>=max_range: continue
        dx,dy=loc.x-el.x,loc.y-el.y; n=max(math.hypot(dx,dy),1e-6)
        if ef.x*(dx/n)+ef.y*(dy/n)>0.6: best=min(best,d)
    return round(best,1) if best<max_range else -1

def get_oncoming(ego, world):
    el=ego.get_location(); ef=ego.get_transform().get_forward_vector()
    for a in world.get_actors():
        if a.id==ego.id or not a.type_id.startswith('vehicle'): continue
        d = a.get_location().distance(el)
        if d>45: continue
        v=a.get_velocity(); s=math.hypot(v.x,v.y)
        if s<0.5: continue
        # oncoming = moving roughly toward/against ego heading (lenient threshold)
        dot = ef.x*(v.x/s)+ef.y*(v.y/s)
        if dot < -0.3 and d < 35:   # moving against us and close
            return True
    return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--host', default='192.168.144.1')
    ap.add_argument('--port', type=int, default=2000)
    ap.add_argument('--stm', default='/mnt/d/NSTM_Project/stm/libstm.so')
    ap.add_argument('--model', default='/mnt/d/NSTM_Project/runs/finetune/weights/best.pt')
    ap.add_argument('--ticks', type=int, default=400)
    ap.add_argument('--no_perception', action='store_true', help='skip YOLO (faster test)')
    ap.add_argument('--force_green', action='store_true', help='set approaching light green (deterministic test)')
    ap.add_argument('--force_red', action='store_true', help='set approaching light red (test stopping)')
    ap.add_argument('--debug', action='store_true', help='print junction/flag debug info')
    ap.add_argument('--video', action='store_true', help='record chase-cam video to MP4')
    ap.add_argument('--video_out', default='/mnt/d/NSTM_Project/results/closed_loop_demo.mp4')
    ap.add_argument('--scripted_oncoming', action='store_true', help='spawn oncoming vehicle to force the yield')
    ap.add_argument('--config', default='full', help='config name for metrics (full/no_gate/etc)')
    ap.add_argument('--scenario', default='turn', help='turn | red_to_green | pedestrian | highway_follow')
    ap.add_argument('--hw_mode', default='adaptive',
                    help='highway_follow behavior: steady | adaptive | rear_pressure')
    ap.add_argument('--event_tick', type=int, default=120, help='tick at which scripted event fires (light turns green / ped appears)')
    ap.add_argument('--route', default='left', help='left | straight')
    ap.add_argument('--metrics_out', default=None, help='path to save metrics JSON')
    args = ap.parse_args()

    print("Connecting..."); client = carla.Client(args.host, args.port); client.set_timeout(30.0)
    world = client.get_world()
    cmap = world.get_map()
    bl = world.get_blueprint_library()
    print(f"[OK] world: {cmap.name}")

    # sync mode
    settings = world.get_settings()
    settings.synchronous_mode = True
    settings.fixed_delta_seconds = 0.05   # 20 Hz
    world.apply_settings(settings)
    tm = client.get_trafficmanager(8000); tm.set_synchronous_mode(True)

    # spawn ego near a signalized junction
    sps = cmap.get_spawn_points()
    ebp = bl.filter('vehicle.tesla.model3')[0]

    # ROUTE-AWARE spawn: pick a spawn where driving FORWARD reaches a junction soon.
    # Walk each candidate's forward waypoints; score by distance to first junction.
    tls = [a for a in world.get_actors().filter('traffic.traffic_light')]
    cmap_local = cmap
    def forward_junction_dist(sp):
        wp = cmap_local.get_waypoint(sp.location)
        if wp is None: return 9999
        d = 0.0
        for _ in range(20):
            nxts = wp.next(3.0)
            if not nxts: return 9999
            wp = nxts[0]; d += 3.0
            if wp.is_junction:
                return d
        return 9999

    # For the highway scenario we want the OPPOSITE of the turn scenarios: the
    # longest straight run with NO junction, so the ego can cruise and follow a
    # lead car without hitting an intersection.
    def forward_clear_dist(sp, max_steps=60):
        """How far can we drive forward before a junction? (m). Higher = better for highway."""
        wp = cmap_local.get_waypoint(sp.location)
        if wp is None: return 0.0
        d = 0.0
        for _ in range(max_steps):
            nxts = wp.next(4.0)
            if not nxts: break
            wp = nxts[0]
            if wp.is_junction:
                break
            d += 4.0
        return d

    if args.scenario == 'highway_follow':
        # rank spawns by the longest junction-free forward stretch (need >= ~120 m)
        clear_scored = sorted([(sp, forward_clear_dist(sp)) for sp in sps],
                              key=lambda x: -x[1])
        scored = [(sp, cd) for sp, cd in clear_scored if cd >= 80][:15]
        if not scored:
            scored = clear_scored[:10]   # fallback: just take the clearest available
        print(f"[OK] highway_follow: best clear stretch found = {scored[0][1]:.0f} m")
    else:
        # rank spawns: want a junction 15-45m straight ahead (turn/intersection scenarios)
        scored = []
        for sp in sps:
            fjd = forward_junction_dist(sp)
            if 15 <= fjd <= 45:
                scored.append((sp, fjd))
        scored.sort(key=lambda x: abs(x[1]-30))   # prefer ~30m ahead
        if not scored:
            # fallback to any spawn with a junction ahead
            scored = sorted([(sp, forward_junction_dist(sp)) for sp in sps],
                            key=lambda x: x[1])[:10]

    ego = None
    for sp, fjd in scored:
        ego = world.try_spawn_actor(ebp, sp)
        if ego:
            if args.scenario == 'highway_follow':
                print(f"[OK] ego spawned at ({sp.location.x:.1f},{sp.location.y:.1f}), "
                      f"clear stretch ~{fjd:.0f}m ahead (junction-free)")
            else:
                print(f"[OK] ego spawned at ({sp.location.x:.1f},{sp.location.y:.1f}), "
                      f"junction ~{fjd:.0f}m straight ahead")
            break
    if ego is None:
        print("[FATAL] could not spawn ego"); return
    world.tick()

    # some traffic for oncoming (spawned away from ego's immediate front)
    npcs = []
    oncoming_vehicle = None
    scenario_walker = None
    scenario_walker_ctrl = None
    scenario_state = {'ped_spawned': False, 'ped_cleared_tick': None, 'red_fired': False}
    ego_loc = ego.get_location()
    far_sps = [sp for sp in sps if sp.location.distance(ego_loc) > 30]
    np.random.shuffle(far_sps)
    n_npcs = 2 if (args.scripted_oncoming or args.scenario in ('red_ped_green','combined')) else 6
    for sp in far_sps[:n_npcs]:
        npc = world.try_spawn_actor(np.random.choice(bl.filter('vehicle.*')), sp)
        if npc: npc.set_autopilot(True, tm.get_port()); npcs.append(npc)
    print(f"[OK] spawned {len(npcs)} NPC vehicles (away from ego front)")

    # scripted oncoming vehicle: spawn opposite the ego, drive it toward the junction
    # so it crosses the ego's left-turn path (forces the Art.44 yield on camera)
    if args.scripted_oncoming:
        ego_tf = ego.get_transform()
        ego_fwd = ego_tf.get_forward_vector()
        # place oncoming ~45m ahead of ego, facing back toward ego (opposite heading)
        onc_loc = carla.Location(
            x=ego_tf.location.x + ego_fwd.x*45,
            y=ego_tf.location.y + ego_fwd.y*45,
            z=ego_tf.location.z + 0.5)
        # find a road waypoint near that location, on an oncoming lane
        onc_wp = cmap.get_waypoint(onc_loc)
        if onc_wp:
            onc_spawn = onc_wp.transform
            onc_spawn.location.z += 0.5
            onc_bp = bl.filter('vehicle.audi.tt')[0]
            oncoming_vehicle = world.try_spawn_actor(onc_bp, onc_spawn)
            if oncoming_vehicle:
                oncoming_vehicle.set_autopilot(True, tm.get_port())
                # make it ignore lights so it actually crosses (creates the conflict)
                tm.ignore_lights_percentage(oncoming_vehicle, 100)
                tm.vehicle_percentage_speed_difference(oncoming_vehicle, -20)  # 20% faster
                print("[OK] scripted oncoming vehicle spawned 45m ahead")
            else:
                print("[!] could not spawn oncoming vehicle (spot occupied)")

    # set the ego's approaching traffic light to green so we can observe the turn
    # (in a full experiment we cycle it; here we make the test deterministic)
    if args.force_green:
        # freeze ALL lights, then set the relevant group green and freeze it
        for t in world.get_actors().filter('traffic.traffic_light'):
            d = t.get_location().distance(ego_loc)
            if d < 60:
                t.set_state(carla.TrafficLightState.Green)
                t.set_green_time(9999.0)
                t.freeze(True)   # stop cycling - hold this state
        print("[OK] froze nearby traffic light(s) GREEN for test")
    if args.force_red:
        for t in world.get_actors().filter('traffic.traffic_light'):
            if t.get_location().distance(ego_loc) < 60:
                t.set_state(carla.TrafficLightState.Red)
                t.set_red_time(9999.0)
                t.freeze(True)
        print("[OK] froze nearby traffic light(s) RED for test")

    # --- SCENARIO SETUP ---
    scenario_lights = []   # lights we will flip green mid-run
    scenario_walker = None
    scenario_walker_ctrl = None
    if args.scenario == 'red_to_green':
        # start RED, will flip GREEN at event_tick
        for t in world.get_actors().filter('traffic.traffic_light'):
            if t.get_location().distance(ego_loc) < 60:
                t.set_state(carla.TrafficLightState.Red)
                t.set_red_time(9999.0); t.freeze(True)
                scenario_lights.append(t)
        print(f"[OK] scenario red_to_green: light RED, will turn GREEN at tick {args.event_tick}")
    elif args.scenario == 'pedestrian':
        # keep green; spawn a pedestrian ahead that will be on the path
        for t in world.get_actors().filter('traffic.traffic_light'):
            if t.get_location().distance(ego_loc) < 60:
                t.set_state(carla.TrafficLightState.Green)
                t.set_green_time(9999.0); t.freeze(True)
        print(f"[OK] scenario pedestrian: will spawn walker ahead at tick {args.event_tick}")
    elif args.scenario == 'combined':
        # ego goes STRAIGHT. Three events in sequence:
        #   tick T1: pedestrian crosses ahead
        #   tick T2: a vehicle drives straight across/ahead
        #   tick T3: green light turns RED
        for t in world.get_actors().filter('traffic.traffic_light'):
            if t.get_location().distance(ego_loc) < 60:
                t.set_state(carla.TrafficLightState.Green)
                t.set_green_time(9999.0); t.freeze(True)
                scenario_lights.append(t)
        print("[OK] scenario COMBINED: pedestrian -> vehicle -> green-to-red, ego straight")
    elif args.scenario == 'red_ped_green':
        # Narrative: stop at RED -> pedestrian crosses while waiting -> GREEN -> proceed.
        # Ego goes straight. Freeze the light AHEAD of the ego to RED.
        ego_fwd0 = ego.get_transform().get_forward_vector()
        # find the light nearest to the junction straight ahead of the ego.
        # walk forward to the junction point, then pick the closest light to it.
        jwp = cmap.get_waypoint(ego_loc); jx, jy = ego_loc.x, ego_loc.y
        for _s in range(20):
            nn = jwp.next(3.0)
            if not nn: break
            jwp = nn[0]
            if jwp.is_junction:
                jx, jy = jwp.transform.location.x, jwp.transform.location.y
                break
        best_tl = None; best_d = 999
        for t in world.get_actors().filter('traffic.traffic_light'):
            tl_loc = t.get_location()
            dj = math.hypot(tl_loc.x-jx, tl_loc.y-jy)   # distance to the junction ahead
            if dj < best_d and dj < 30:
                best_d = dj; best_tl = t
        if best_tl is not None:
            best_tl.set_state(carla.TrafficLightState.Red)
            best_tl.set_red_time(9999.0); best_tl.freeze(True)
            scenario_lights.append(best_tl)
            print(f"[OK] scenario RED_PED_GREEN: froze the light AHEAD to RED")
        else:
            # fallback: freeze all nearby
            for t in world.get_actors().filter('traffic.traffic_light'):
                if t.get_location().distance(ego_loc) < 50:
                    t.set_state(carla.TrafficLightState.Red); t.set_red_time(9999.0); t.freeze(True)
                    scenario_lights.append(t)
            print(f"[OK] scenario RED_PED_GREEN: froze {len(scenario_lights)} nearby lights RED (fallback)")

    elif args.scenario == 'highway_follow':
        # Adaptive-cruise scenario. The lead and rear vehicles are placed on the ego's
        # ACTUAL planned route (below, after route planning) so they are guaranteed to be
        # in the ego's lane. Nothing to do here at spawn time.
        print(f"[OK] scenario HIGHWAY_FOLLOW: lead/rear cars will be placed on the route")

    # sensors
    cam_bp = bl.find('sensor.camera.rgb')
    cam_bp.set_attribute('image_size_x', str(IMG_W)); cam_bp.set_attribute('image_size_y', str(IMG_H))
    cam_bp.set_attribute('fov', str(FOV))
    cam = world.spawn_actor(cam_bp, carla.Transform(carla.Location(x=1.5,z=2.0)), attach_to=ego)
    from queue import Queue, Empty
    img_q = Queue()
    cam.listen(lambda d: img_q.put(d))

    # chase camera for video (third-person, follows the car)
    video_frames = []
    if args.video:
        chase_bp = bl.find('sensor.camera.rgb')
        chase_bp.set_attribute('image_size_x', '1280')
        chase_bp.set_attribute('image_size_y', '720')
        chase_bp.set_attribute('fov', '90')
        # behind and above the car, looking forward
        chase_tf = carla.Transform(carla.Location(x=-6.0, z=3.5),
                                   carla.Rotation(pitch=-15))
        chase_cam = world.spawn_actor(chase_bp, chase_tf, attach_to=ego)
        hud = {'state':'INIT','speed':0.0,'signal':-1,'action':'none','risk':0,'oncoming':False}
        def _save_frame(image):
            arr = np.frombuffer(image.raw_data, dtype=np.uint8).reshape((720,1280,4))[:,:,:3].copy()
            video_frames.append((arr, dict(hud)))   # store frame + telemetry snapshot
        chase_cam.listen(_save_frame)
        print("[OK] chase camera attached for video")
    else:
        chase_cam = None

    # collision + lane-invasion sensors for metrics
    collision_events = []
    col_bp = bl.find('sensor.other.collision')
    col_sensor = world.spawn_actor(col_bp, carla.Transform(), attach_to=ego)
    col_sensor.listen(lambda e: collision_events.append(e))

    lane_events = []
    lane_bp = bl.find('sensor.other.lane_invasion')
    lane_sensor = world.spawn_actor(lane_bp, carla.Transform(), attach_to=ego)
    lane_sensor.listen(lambda e: lane_events.append(e))

    # build stack
    bridge = bridge_mod.RLCBridge(weather='clear')
    stm = adapter_mod.STMAdapter(args.stm)
    stm.init()
    motion = MotionController(ego, cmap)
    metrics = metrics_mod.RunMetrics(args.config)

    perception = None
    if not args.no_perception:
        perception = LivePerception(args.model)

    # plan route (straight or left-turn depending on scenario)
    world.tick()
    if args.route == 'straight' or args.scenario in ('combined','red_ped_green','highway_follow'):
        nroute = motion.plan_straight_route()
        print(f"[OK] planned STRAIGHT route: {nroute} waypoints")
    else:
        nroute = motion.plan_left_turn_route()
        print(f"[OK] planned left-turn route: {nroute} waypoints")

    # ---- highway_follow: place lead + rear vehicles ON the ego's route ----
    lead_vehicle = None
    rear_vehicle = None
    if args.scenario == 'highway_follow' and len(motion.route) > 12:
        # LEAD: a waypoint ~25 m ahead along the route (index chosen by cumulative dist)
        def route_index_at_distance(route, dist):
            acc = 0.0
            for i in range(1, len(route)):
                a = route[i-1].transform.location; b = route[i].transform.location
                acc += math.hypot(b.x-a.x, b.y-a.y)
                if acc >= dist:
                    return i
            return len(route)-1
        lead_idx = route_index_at_distance(motion.route, 15.0)
        lead_wp = motion.route[lead_idx]
        lead_tf = carla.Transform(
            carla.Location(x=lead_wp.transform.location.x,
                           y=lead_wp.transform.location.y,
                           z=lead_wp.transform.location.z + 0.3),
            lead_wp.transform.rotation)
        lead_bp = bl.filter('vehicle.tesla.model3')[0]
        lead_vehicle = world.try_spawn_actor(lead_bp, lead_tf)
        if lead_vehicle is not None:
            oncoming_vehicle = lead_vehicle  # reuse slot so existing cleanup destroys it
            print(f"[OK] highway_follow: LEAD car on route at ~15 m (idx {lead_idx})")
        else:
            print(f"[!] highway_follow: lead spawn point occupied")

        # REAR: a waypoint ~20 m BEHIND the ego start (previous waypoints along the lane)
        start_wp = motion.route[0]
        back = start_wp
        for _ in range(10):  # step backward ~20 m
            prev = back.previous(2.0)
            if not prev: break
            back = prev[0]
        rear_tf = carla.Transform(
            carla.Location(x=back.transform.location.x,
                           y=back.transform.location.y,
                           z=back.transform.location.z + 0.3),
            back.transform.rotation)
        rear_bp = bl.filter('vehicle.audi.tt')[0]
        rear_vehicle = world.try_spawn_actor(rear_bp, rear_tf)
        if rear_vehicle is not None:
            print(f"[OK] highway_follow: REAR car ~20 m behind ego")
        else:
            print(f"[!] highway_follow: rear spawn point occupied")

    # warm up
    for _ in range(5):
        world.tick()
        try: img_q.get(timeout=2.0)
        except Empty: pass

    print("\n=== CLOSED LOOP RUNNING ===")
    log = []
    stopline_sent = False
    last_signal = -1
    t0 = time.time()

    for tick in range(args.ticks):
        world.tick()
        speed = motion._speed_kmh()   # compute early; used by scenario logic below

        # --- scripted scenario events ---
        # Highway adaptive-cruise: drive the lead car per the chosen hw_mode, and drive
        # the rear car to sit behind the ego (or apply pressure), so we can verify the
        # ego follows safely with no collision front OR back.
        if args.scenario == 'highway_follow':
            motion.target_speed = 50.0   # ego cruises at highway speed

            def drive_to_speed(veh, target_kmh, gentle=False):
                """Simple longitudinal controller: throttle/brake a vehicle toward a target."""
                try:
                    vv = veh.get_velocity(); sp = 3.6*math.hypot(vv.x, vv.y)
                    if sp < target_kmh - 1.0:
                        veh.apply_control(carla.VehicleControl(throttle=0.5 if gentle else 0.7, brake=0.0))
                    elif sp > target_kmh + 1.0:
                        hard = 0.4 if gentle else (0.9 if (sp - target_kmh) > 15 else 0.55)
                        veh.apply_control(carla.VehicleControl(throttle=0.0, brake=hard))
                    else:
                        veh.apply_control(carla.VehicleControl(throttle=0.25, brake=0.0))
                    return sp
                except Exception:
                    return -1.0

            te = tick - args.event_tick

            # ----- LEAD car behavior by mode -----
            if lead_vehicle is not None:
                if args.hw_mode == 'steady':
                    lead_target_kmh = 50.0                     # cruises steady the whole time
                else:  # 'adaptive' and 'rear_pressure' both slow the lead then resume
                    if te < 0:      lead_target_kmh = 50.0     # cruise together first
                    elif te < 25:   lead_target_kmh = 12.0     # BRAKE: slow to 12 km/h
                    elif te < 50:   lead_target_kmh = 12.0     # HOLD slow
                    else:           lead_target_kmh = 50.0     # ACCELERATE back
                lead_spd = drive_to_speed(lead_vehicle, lead_target_kmh)

            # ----- REAR car behavior -----
            if rear_vehicle is not None:
                if args.hw_mode == 'rear_pressure':
                    rear_target_kmh = 55.0                     # pushes up behind the ego
                else:
                    rear_target_kmh = 48.0                     # follows a touch slower than cruise
                # rear car keeps its own safe gap to the EGO (won't ram): back off if too close
                try:
                    rl = rear_vehicle.get_location(); el = ego.get_location()
                    d_rear = rl.distance(el)
                    if d_rear < 10.0:
                        rear_vehicle.apply_control(carla.VehicleControl(throttle=0.0, brake=0.8))
                    elif d_rear < 14.0:
                        rear_vehicle.apply_control(carla.VehicleControl(throttle=0.0, brake=0.3))
                    else:
                        drive_to_speed(rear_vehicle, rear_target_kmh, gentle=True)
                except Exception:
                    pass

            if args.debug and tick % 10 == 0:
                try:
                    lv = lead_vehicle.get_velocity() if lead_vehicle else None
                    ls = 3.6*math.hypot(lv.x, lv.y) if lv else -1
                    rl = rear_vehicle.get_location() if rear_vehicle else None
                    dr = rl.distance(ego.get_location()) if rl else -1
                    print(f"     [hw:{args.hw_mode}] t={tick} lead={ls:.1f} ego={speed:.1f} "
                          f"rear_gap={dr:.1f}")
                except Exception:
                    pass

        if args.scenario == 'red_to_green' and tick == args.event_tick:
            for t in scenario_lights:
                t.set_state(carla.TrafficLightState.Green)
            print(f"  >>> [tick {tick}] LIGHT TURNED GREEN <<<")
        if args.scenario == 'combined':
            T1 = args.event_tick          # pedestrian
            T2 = args.event_tick + 40     # straight vehicle (while stopped for ped)
            # T3 (red) is fired dynamically shortly after the pedestrian clears,
            # so the car resumes then immediately faces a red -> stops again.
            T3 = None
            # --- T1: pedestrian crosses ahead ---
            if tick == T1 and scenario_walker is None:
                ego_tf2 = ego.get_transform(); fwd = ego_tf2.get_forward_vector()
                right = ego_tf2.get_right_vector()
                ped_loc = carla.Location(
                    x=ego_tf2.location.x + fwd.x*13 + right.x*4,
                    y=ego_tf2.location.y + fwd.y*13 + right.y*4,
                    z=ego_tf2.location.z + 1.0)
                wbp = np.random.choice(bl.filter('walker.pedestrian.*'))
                scenario_walker = world.try_spawn_actor(wbp, carla.Transform(ped_loc))
                if scenario_walker:
                    wctrl_bp = bl.find('controller.ai.walker')
                    scenario_walker_ctrl = world.spawn_actor(wctrl_bp, carla.Transform(), attach_to=scenario_walker)
                    world.tick(); scenario_walker_ctrl.start()
                    cross = carla.Location(
                        x=ego_tf2.location.x + fwd.x*15 - right.x*4,
                        y=ego_tf2.location.y + fwd.y*15 - right.y*4,
                        z=ego_tf2.location.z)
                    scenario_walker_ctrl.go_to_location(cross)
                    scenario_walker_ctrl.set_max_speed(1.4)
                    scenario_state['ped_spawned'] = True
                    print(f"  >>> [tick {tick}] EVENT 1: PEDESTRIAN crossing ahead <<<")
            # --- T2: a vehicle drives straight ahead/across ---
            if tick == T2 and oncoming_vehicle is None:
                ego_tf2 = ego.get_transform(); fwd = ego_tf2.get_forward_vector()
                vloc = carla.Location(
                    x=ego_tf2.location.x + fwd.x*30,
                    y=ego_tf2.location.y + fwd.y*30,
                    z=ego_tf2.location.z + 0.5)
                vwp = cmap.get_waypoint(vloc)
                if vwp:
                    vtf = vwp.transform; vtf.location.z += 0.5
                    vbp = bl.filter('vehicle.audi.tt')[0]
                    oncoming_vehicle = world.try_spawn_actor(vbp, vtf)
                    if oncoming_vehicle:
                        oncoming_vehicle.set_autopilot(True, tm.get_port())
                        tm.ignore_lights_percentage(oncoming_vehicle, 100)
                        print(f"  >>> [tick {tick}] EVENT 2: VEHICLE moving ahead <<<")
            # --- T3: light turns red, fired ~12 ticks after pedestrian clears ---
            if scenario_walker is None and not getattr(args,'_ped_was_present', False):
                pass  # ped never spawned yet
            # detect the clear transition
            if scenario_walker is None and getattr(main, '_ped_cleared_tick', None) is None                and getattr(main, '_ped_spawned', False):
                main._ped_cleared_tick = tick
            if getattr(main, '_ped_cleared_tick', None) is not None                and not getattr(main, '_red_fired', False)                and tick >= main._ped_cleared_tick + 12:
                for t in scenario_lights:
                    t.set_state(carla.TrafficLightState.Red)
                main._red_fired = True
                print(f"  >>> [tick {tick}] EVENT 3: LIGHT TURNED RED (car must stop again) <<<")

        if args.scenario == 'red_ped_green':
            wp_s = cmap.get_waypoint(ego.get_location())
            # distance to junction
            dj = 999; pr = wp_s
            for _st in range(1,8):
                nn = pr.next(2.0)
                if not nn: break
                pr = nn[0]
                if pr.is_junction: dj = _st*2.0; break
            stopped_at_line = (speed < 0.6) and (dj < 10 or wp_s.is_junction)
            # EVENT 1: once stopped at red line, spawn the pedestrian (after a short hold)
            if stopped_at_line and not scenario_state['ped_spawned'] and tick > args.event_tick:
                ego_tf2 = ego.get_transform(); fwd = ego_tf2.get_forward_vector(); right = ego_tf2.get_right_vector()
                ped_loc = carla.Location(
                    x=ego_tf2.location.x + fwd.x*11 + right.x*4,
                    y=ego_tf2.location.y + fwd.y*11 + right.y*4,
                    z=ego_tf2.location.z + 1.0)
                wbp = np.random.choice(bl.filter('walker.pedestrian.*'))
                scenario_walker = world.try_spawn_actor(wbp, carla.Transform(ped_loc))
                if scenario_walker:
                    wctrl_bp = bl.find('controller.ai.walker')
                    scenario_walker_ctrl = world.spawn_actor(wctrl_bp, carla.Transform(), attach_to=scenario_walker)
                    world.tick(); scenario_walker_ctrl.start()
                    cross = carla.Location(
                        x=ego_tf2.location.x + fwd.x*13 - right.x*4,
                        y=ego_tf2.location.y + fwd.y*13 - right.y*4,
                        z=ego_tf2.location.z)
                    scenario_walker_ctrl.go_to_location(cross)
                    scenario_walker_ctrl.set_max_speed(1.2)
                    scenario_state['ped_spawned'] = True
                    scenario_state['ped_spawn_tick'] = tick
                    print(f"  >>> [tick {tick}] EVENT: PEDESTRIAN crosses while car waits at RED <<<")
            # track pedestrian clearing
            if scenario_state['ped_spawned'] and scenario_walker is None and scenario_state['ped_cleared_tick'] is None:
                scenario_state['ped_cleared_tick'] = tick
            # EVENT 2: after pedestrian clears, turn the light GREEN
            if scenario_state['ped_cleared_tick'] is not None and not scenario_state['red_fired'] \
               and tick >= scenario_state['ped_cleared_tick'] + 10:
                for t in scenario_lights:
                    t.set_state(carla.TrafficLightState.Green)
                scenario_state['red_fired'] = True   # reusing flag = "green fired"
                print(f"  >>> [tick {tick}] LIGHT TURNED GREEN -> car proceeds <<<")

        if args.scenario == 'pedestrian' and tick == args.event_tick and scenario_walker is None:
            # spawn a walker ~12m ahead of the ego, crossing its path
            ego_tf2 = ego.get_transform(); fwd = ego_tf2.get_forward_vector()
            right = ego_tf2.get_right_vector()
            ped_loc = carla.Location(
                x=ego_tf2.location.x + fwd.x*12 + right.x*4,
                y=ego_tf2.location.y + fwd.y*12 + right.y*4,
                z=ego_tf2.location.z + 1.0)
            wbp = np.random.choice(bl.filter('walker.pedestrian.*'))
            scenario_walker = world.try_spawn_actor(wbp, carla.Transform(ped_loc))
            if scenario_walker:
                # make the walker cross the road (walk left, across ego's path)
                wctrl_bp = bl.find('controller.ai.walker')
                scenario_walker_ctrl = world.spawn_actor(wctrl_bp, carla.Transform(), attach_to=scenario_walker)
                world.tick()
                scenario_walker_ctrl.start()
                # walk toward a point across the road
                cross_target = carla.Location(
                    x=ego_tf2.location.x + fwd.x*14 - right.x*4,
                    y=ego_tf2.location.y + fwd.y*14 - right.y*4,
                    z=ego_tf2.location.z)
                scenario_walker_ctrl.go_to_location(cross_target)
                scenario_walker_ctrl.set_max_speed(1.4)
                print(f"  >>> [tick {tick}] PEDESTRIAN SPAWNED, crossing ahead <<<")

        # get frame
        img_bgr = None
        try:
            image = img_q.get(timeout=2.0)
            arr = np.frombuffer(image.raw_data, dtype=np.uint8).reshape((IMG_H, IMG_W, 4))[:,:,:3]
            img_bgr = arr
        except Empty:
            pass

        # --- perception / signals ---
        obs_dist = get_obs_dist(ego, world)
        signal = get_signal_state(ego, world)
        # For scripted-light scenarios, read the controlled light DIRECTLY (robust;
        # CARLA's ego->light association is unreliable and returns -1 here).
        if args.scenario in ('red_to_green','combined','red_ped_green') and scenario_lights:
            try:
                st = scenario_lights[0].get_state()
                signal = {carla.TrafficLightState.Red:0, carla.TrafficLightState.Green:1,
                          carla.TrafficLightState.Yellow:2}.get(st, signal)
            except: pass
        if signal != -1:
            last_signal = signal
        elif last_signal != -1:
            signal = last_signal
        oncoming = get_oncoming(ego, world)
        pedestrian = False; ped_conf = 0.95; veh_conf = 0.95

        # detect pedestrian on path (ground-truth based when no_perception)
        if args.scenario in ('pedestrian','combined','red_ped_green') and scenario_walker is not None:
            try:
                wl = scenario_walker.get_location(); el2 = ego.get_location()
                ef2 = ego.get_transform().get_forward_vector()
                er2 = ego.get_transform().get_right_vector()
                d = wl.distance(el2)
                dx, dy = wl.x-el2.x, wl.y-el2.y; n = max(math.hypot(dx,dy),1e-6)
                ahead = ef2.x*(dx/n)+ef2.y*(dy/n)
                lateral = er2.x*dx + er2.y*dy   # signed left/right offset
                # pedestrian is a hazard only while in front AND near the path centre
                if d < 20 and ahead > 0.2 and abs(lateral) < 3.5:
                    pedestrian = True; ped_conf = 0.95
                # despawn once crossed (lateral past -3) OR behind OR timed out
                walker_age = tick - scenario_state.get('ped_spawn_tick', tick)
                if lateral < -3.0 or (ahead < 0 and d > 5) or walker_age > 70:
                    if scenario_walker_ctrl:
                        try: scenario_walker_ctrl.stop(); scenario_walker_ctrl.destroy()
                        except: pass
                    try: scenario_walker.destroy()
                    except: pass
                    scenario_walker = None
                    print(f"  >>> [tick {tick}] pedestrian cleared the crossing <<<")
            except: pass

        if perception is not None and img_bgr is not None:
            pedestrian, ped_conf, veh_conf = perception.process(img_bgr, None, ego, world)

        # confidence values feed the gate
        perc = {
            'obs_dist': (obs_dist, veh_conf if obs_dist>0 else 0.95),
            'ego_speed': (speed, 0.95),
            'pedestrian': (pedestrian, ped_conf if pedestrian else 0.95),
            'traffic_light': (signal, 0.95),
            'oncoming': (oncoming, 0.92),
        }
        inp = {'speed_limit': 50}

        # --- bridge (timed for latency metric) ---
        _t_decision_start = time.time()
        bout = bridge.process(perc, inp)

        # --- scenario flags for the STM adapter ---
        wp = cmap.get_waypoint(ego.get_location())
        in_junction = wp.is_junction
        # robust distance to junction: probe ahead up to 20m
        dist_to_junction = 999
        probe = wp
        for step in range(1, 11):
            nx = probe.next(2.0)
            if not nx: break
            probe = nx[0]
            if probe.is_junction:
                dist_to_junction = step * 2.0
                break
        # "at line" = close to junction OR stopped near it OR in it
        nearly_stopped = speed < 1.0
        at_line = in_junction or dist_to_junction < 6.0 or (nearly_stopped and dist_to_junction < 12.0)
        approaching_line = (dist_to_junction < 10.0) and not stopline_sent

        # Highway car-following: the ego should react ONLY to the vehicle ahead (risk path),
        # not to intersection stop lines. Suppress the junction/stop-line flags so it cruises
        # and follows rather than halting at a junction.
        if args.scenario == 'highway_follow':
            in_junction = False
            at_line = False
            approaching_line = False

        # committed = past the stop line and proceeding (junction for turn, or moved along straight route)
        if args.route == 'straight' or args.scenario in ('combined','red_ped_green','highway_follow'):
            committed = motion.route_idx >= 5
        else:
            committed = in_junction and motion.route_idx >= 6
        flags = {
            'stopline_reached': approaching_line,
            'intersection_exit': in_junction and motion.route_idx > len(motion.route)*0.6,
            'oncoming': oncoming, 'pedestrian': pedestrian,
            'signal': signal,
            'at_stopline': at_line,
            'was_yielding': stm.state_name() in ('YIELD_WAIT',),
            'current_state': stm.state_name(),
            'committed_to_turn': committed,
        }
        if approaching_line:
            stopline_sent = True

        if args.debug and tick % 10 == 0:
            print(f"     [dbg] dist_junc={dist_to_junction:.0f} in_junc={in_junction} "
                  f"at_line={at_line} sig={signal} spd={speed:.1f} ped_spawned={scenario_state.get('ped_spawned',False)} "
                  f"route_idx={motion.route_idx}/{len(motion.route)}")

        # --- STM decision ---
        result = stm.step_from_bridge(bout, flags)
        _decision_latency_ms = (time.time() - _t_decision_start) * 1000.0

        # --- motion control ---
        ctrl = motion.control(result['state_name'], result['action'],
                              risk_tier=bout['ram']['RiskTier'], gap=obs_dist,
                              highway=(args.scenario == 'highway_follow'))
        ego.apply_control(ctrl)

        # update HUD telemetry for video overlay
        if args.video:
            hud['state'] = result['state_name']
            hud['speed'] = speed
            hud['signal'] = signal
            hud['action'] = result['action']
            hud['risk'] = bout['ram']['RiskTier']
            hud['oncoming'] = oncoming

        # --- record metrics ---
        wp_m = cmap.get_waypoint(ego.get_location())
        must_yield_now = oncoming or pedestrian
        proceeded_now = result['state_name'] in ('TURNING','ASSESS_YIELD') and speed > 2.0
        metrics.record_tick(
            stm_state=result['state_name'], signal=signal, speed=speed,
            speed_limit=50, in_junction=wp_m.is_junction, oncoming=oncoming,
            pedestrian=pedestrian, risk_tier=bout['ram']['RiskTier'],
            audit_record=bout['audit'], latency_ms=_decision_latency_ms,
            must_yield=must_yield_now, proceeded=proceeded_now)

        # --- log ---
        if tick % 10 == 0:
            print(f"t={tick:3d} spd={speed:4.1f} sig={signal} obs={obs_dist:5.1f} onc={oncoming} "
                  f"| STM={result['state_name']:12s} act={result['action']:10s} "
                  f"| thr={ctrl.throttle:.1f} brk={ctrl.brake:.1f} str={ctrl.steer:+.2f}")
        log.append({'tick':tick, 'speed':speed, 'signal':signal, 'obs_dist':obs_dist,
                    'oncoming':oncoming, 'stm_state':result['state_name'],
                    'action':result['action'], 'risk_tier':bout['ram']['RiskTier'],
                    'legal_mask':bout['ram']['LegalMask']})

        # stop if reached end of route (or got well past the junction)
        stop_idx = 40 if (args.route=='straight' or args.scenario in ('combined','red_ped_green')) else 25
        if motion.route_idx >= len(motion.route)-2 or motion.route_idx >= stop_idx:
            print(f"\n[Route complete at tick {tick}, route_idx={motion.route_idx}]")
            metrics.set_completed(True)
            break

    elapsed = time.time()-t0
    print(f"\n=== DONE: {tick+1} ticks in {elapsed:.1f}s ({(tick+1)/elapsed:.1f} Hz) ===")
    print(f"Collisions: {len(collision_events)}  Lane invasions: {len(lane_events)}")
    # transfer collision events + completion into metrics
    for ce in collision_events:
        metrics.record_collision(0, ce.other_actor.type_id if hasattr(ce,'other_actor') else 'unknown')
    metrics.lane_invasions = len(lane_events)
    # completed if reached end of route OR got through the junction (60%+ of route)
    completed = (motion.route_idx >= len(motion.route)-2) or (motion.route_idx >= len(motion.route)*0.5)
    metrics.set_completed(completed)

    msum = metrics.summary()
    print(f"\n--- METRICS ({msum['config']}) ---")
    print(f"  Infractions: ran_red={msum['infractions']['ran_red']} "
          f"failed_yield={msum['infractions']['failed_yield']}")
    print(f"  Correctness: {msum['correctness']}")
    print(f"  Latency: mean={msum['latency_ms']['mean']}ms p95={msum['latency_ms']['p95']}ms")
    print(f"  Audit completeness: {msum['audit_completeness']}")
    if args.metrics_out:
        metrics.save(args.metrics_out)
        print(f"  Saved metrics: {args.metrics_out}")

    # cleanup (order matters: stop sensor callback, tick, then destroy)
    # --- bulletproof cleanup ---
    # 1. stop all sensor callbacks while still in sync mode
    for s in (cam, col_sensor, lane_sensor, chase_cam):
        try:
            if s is not None: s.stop()
        except: pass
    # 2. tick once more so the stop() takes effect in the simulator
    try: world.tick()
    except: pass
    time.sleep(0.5)
    # 3. destroy sensors BEFORE switching async (avoids dangling callback)
    for s in (cam, col_sensor, lane_sensor, chase_cam):
        try:
            if s is not None: s.destroy()
        except: pass
    time.sleep(0.2)
    # 4. now restore async mode
    try:
        settings.synchronous_mode = False
        world.apply_settings(settings)
        tm.set_synchronous_mode(False)
    except: pass
    time.sleep(0.2)
    for a in npcs:
        try: a.destroy()
        except: pass
    try:
        if oncoming_vehicle: oncoming_vehicle.destroy()
        if 'rear_vehicle' in dir() and rear_vehicle: rear_vehicle.destroy()
    except: pass
    try:
        if scenario_walker_ctrl: scenario_walker_ctrl.stop()
        if scenario_walker_ctrl: scenario_walker_ctrl.destroy()
        if scenario_walker: scenario_walker.destroy()
    except: pass
    try: ego.destroy()
    except: pass

    os.makedirs('/mnt/d/NSTM_Project/results', exist_ok=True)
    # write video with HUD overlay
    if args.video and video_frames:
        print(f"Writing video ({len(video_frames)} frames)...")
        import cv2
        first_frame = video_frames[0][0]
        h, w = first_frame.shape[:2]
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        vw = cv2.VideoWriter(args.video_out, fourcc, 20.0, (w, h))
        STATE_COLORS = {'APPROACH':(0,200,0),'BRAKE_HOLD':(0,140,255),
                        'ASSESS_YIELD':(0,200,200),'YIELD_WAIT':(0,0,255),
                        'TURNING':(255,150,0),'INIT':(150,150,150)}
        SIG_TXT = {0:'RED',1:'GREEN',2:'YELLOW',-1:'--'}
        for frame, tel in video_frames:
            f = frame.copy()
            # semi-transparent panel top-left
            overlay = f.copy()
            cv2.rectangle(overlay, (0,0), (430,170), (0,0,0), -1)
            cv2.addWeighted(overlay, 0.55, f, 0.45, 0, f)
            col = STATE_COLORS.get(tel['state'], (255,255,255))
            cv2.putText(f, f"STM: {tel['state']}", (15,38), cv2.FONT_HERSHEY_SIMPLEX, 0.9, col, 2)
            cv2.putText(f, f"Speed: {tel['speed']:.0f} km/h", (15,72), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,255,255), 2)
            sig = tel['signal']; sigcol = {0:(0,0,255),1:(0,220,0),2:(0,220,220)}.get(sig,(180,180,180))
            cv2.putText(f, f"Signal: {SIG_TXT.get(sig,'--')}", (15,104), cv2.FONT_HERSHEY_SIMPLEX, 0.7, sigcol, 2)
            cv2.putText(f, f"Risk tier: {tel['risk']}", (15,134), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,255,255), 2)
            if tel['oncoming']:
                cv2.putText(f, "ONCOMING - YIELDING", (15,162), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,0,255), 2)
            vw.write(f)
        vw.release()
        print(f"[OK] video saved: {args.video_out}")

    summary = {'ticks': tick+1, 'hz': round((tick+1)/elapsed,1),
               'collisions': len(collision_events), 'lane_invasions': len(lane_events),
               'trace': log}
    json.dump(summary, open('/mnt/d/NSTM_Project/results/closed_loop_log.json','w'), indent=2)
    print("Saved closed_loop_log.json")


if __name__ == '__main__':
    main()
