"""
17_metrics.py
=============
Phase 8 Step 3: Metrics collection for closed-loop runs.

Records, for any run configuration:
  - Collisions (count + actor type hit)
  - Traffic infractions (ran red, failed-to-yield, speeding)
  - STM-state trace (full sequence, for state-accuracy analysis)
  - Decision latency (perception + bridge + STM, per tick) -> real-time proof
  - Audit completeness (fraction of ticks with full causal record)
  - Behavioral correctness (did it stop at red? yield when required?)

This module is imported by the closed-loop / ablation harness. It accumulates
per-tick data and produces a structured summary at the end.
"""
import time, json
import numpy as np


class RunMetrics:
    """Accumulates metrics over one closed-loop run."""

    def __init__(self, config_name='full'):
        self.config = config_name
        self.ticks = 0
        self.collisions = []           # list of (tick, actor_type)
        self.lane_invasions = 0

        # infractions
        self.ran_red_count = 0         # entered junction on red
        self.failed_yield_count = 0    # proceeded when should yield
        self.speeding_ticks = 0

        # behavioral events (for correctness)
        self.stopped_at_red = False
        self.yielded_to_oncoming = False
        self.yielded_to_pedestrian = False
        self.completed_route = False

        # traces
        self.state_trace = []          # STM state each tick
        self.latencies = []            # per-tick decision latency (ms)
        self.audit_complete_ticks = 0  # ticks with full audit record

        # per-tick context for infraction detection
        self._was_in_junction = False

    def record_tick(self, *, stm_state, signal, speed, speed_limit,
                    in_junction, oncoming, pedestrian, risk_tier,
                    audit_record=None, latency_ms=None,
                    must_yield=False, proceeded=False):
        self.ticks += 1
        self.state_trace.append(stm_state)
        if latency_ms is not None:
            self.latencies.append(latency_ms)

        # audit completeness: does this tick have a full causal record?
        if audit_record is not None and self._audit_is_complete(audit_record):
            self.audit_complete_ticks += 1

        # --- infraction detection ---
        # ran red: entered the junction while signal red and was moving
        entering_junction = in_junction and not self._was_in_junction
        if entering_junction and signal == 0 and speed > 1.0:
            self.ran_red_count += 1
        self._was_in_junction = in_junction

        # speeding
        if speed > speed_limit + 2:    # small tolerance
            self.speeding_ticks += 1

        # failed to yield: was required to yield but proceeded (moving) anyway
        if must_yield and proceeded and speed > 2.0:
            self.failed_yield_count += 1

        # --- behavioral correctness ---
        if signal == 0 and speed < 0.5 and not in_junction:
            self.stopped_at_red = True
        if oncoming and stm_state in ('YIELD_WAIT',) and speed < 1.0:
            self.yielded_to_oncoming = True
        if pedestrian and stm_state in ('YIELD_WAIT','BRAKE_HOLD') and speed < 1.0:
            self.yielded_to_pedestrian = True

    def record_collision(self, tick, actor_type):
        self.collisions.append((tick, actor_type))

    def set_completed(self, completed):
        self.completed_route = completed

    def _audit_is_complete(self, rec):
        """A complete audit record has gates, risk, legality, and action."""
        required = ['gates', 'risk', 'legality']
        return all(k in rec for k in required)

    def summary(self):
        lat = self.latencies if self.latencies else [0]
        return {
            'config': self.config,
            'ticks': self.ticks,
            'collisions': len(self.collisions),
            'collision_detail': self.collisions,
            'lane_invasions': self.lane_invasions,
            'infractions': {
                'ran_red': self.ran_red_count,
                'failed_yield': self.failed_yield_count,
                'speeding_ticks': self.speeding_ticks,
                'total': self.ran_red_count + self.failed_yield_count,
            },
            'correctness': {
                'stopped_at_red': self.stopped_at_red,
                'yielded_to_oncoming': self.yielded_to_oncoming,
                'yielded_to_pedestrian': self.yielded_to_pedestrian,
                'completed_route': self.completed_route,
            },
            'latency_ms': {
                'mean': round(float(np.mean(lat)), 2),
                'p50': round(float(np.percentile(lat, 50)), 2),
                'p95': round(float(np.percentile(lat, 95)), 2),
                'max': round(float(np.max(lat)), 2),
            },
            'audit_completeness': round(self.audit_complete_ticks / max(self.ticks,1), 3),
            'state_distribution': self._state_dist(),
        }

    def _state_dist(self):
        from collections import Counter
        c = Counter(self.state_trace)
        return {k: v for k, v in c.most_common()}

    def save(self, path):
        json.dump(self.summary(), open(path, 'w'), indent=2)


# ---- self-test ----
if __name__ == '__main__':
    print("="*60)
    print("Metrics module — self test")
    print("="*60)

    m = RunMetrics('full')
    # simulate a clean run: approach, stop at red, then green, turn, yield once
    import random
    for t in range(200):
        # fake a scenario
        signal = 0 if t < 50 else 1            # red then green
        in_junction = t > 80
        speed = 0.0 if (40 < t < 55) else 11.0  # stopped at red
        oncoming = (90 < t < 105)
        state = ('BRAKE_HOLD' if 40<t<55 else
                 'YIELD_WAIT' if (90<t<105) else
                 'TURNING' if t>80 else 'APPROACH')
        m.record_tick(stm_state=state, signal=signal, speed=(0.0 if oncoming else speed),
                      speed_limit=50, in_junction=in_junction, oncoming=oncoming,
                      pedestrian=False, risk_tier=0,
                      audit_record={'gates':{}, 'risk':{}, 'legality':{}},
                      latency_ms=random.uniform(8, 18),
                      must_yield=oncoming, proceeded=False)
    m.set_completed(True)

    s = m.summary()
    print(f"\nConfig: {s['config']}")
    print(f"Ticks: {s['ticks']}")
    print(f"Collisions: {s['collisions']}")
    print(f"Infractions: {s['infractions']}")
    print(f"Correctness: {s['correctness']}")
    print(f"Latency: mean={s['latency_ms']['mean']}ms p95={s['latency_ms']['p95']}ms")
    print(f"Audit completeness: {s['audit_completeness']}")
    print(f"State distribution: {s['state_distribution']}")
    print("\n[OK] metrics module working")
