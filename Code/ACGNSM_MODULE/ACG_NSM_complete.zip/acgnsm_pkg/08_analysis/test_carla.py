print("script started")
import sys, glob
eggs = glob.glob(r'D:\CARLA_0.9.15\WindowsNoEditor\PythonAPI\carla\dist\*.egg')
if eggs:
    sys.path.insert(0, eggs[0])
import carla
print("carla OK")
import carla
client = carla.Client('localhost', 2000)
client.set_timeout(10.0)
world = client.get_world()
print("world OK:", world.get_map().name)
