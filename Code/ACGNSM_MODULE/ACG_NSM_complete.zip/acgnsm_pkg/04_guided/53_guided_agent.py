"""
53_guided_agent.py
==================
ACG-NSM-guided TransFuser++.

Wraps the published SensorAgent so that, at every tick:

    u_N   comes from TransFuser++            (nominal, frozen, unmodified)
    u_C   comes from the ACG-NSM channel     (conservative, own perception)
    u*    = u_N - lambda * max(0, u_N - u_C) (suppression, lambda = 2/3)

and the executed control is re-derived for u*.

Two modes, selected by ACGNSM_ARBITRATE:

    0   observe only. u* is computed and logged but the planner's own control
        is returned untouched, so the trajectory is identical to the baseline
        and the disagreement statistics are measured against exactly the
        situations the planner actually encountered.

    1   guided. The suppressed speed is applied. This is the model under test.

Attribution
-----------
TransFuser++ already contains two safety behaviours of its own: an uncertainty
brake, and a geometric safety box that halts creeping. Both are logged
separately from our suppression so that caution the planner already exercises
is not credited to ACG-NSM.

Usage: point the leaderboard at this file with --agent
"""
import os, json, math, importlib.util
from pathlib import Path

SRC = Path(__file__).resolve().parent
GARAGE = os.environ.get('GARAGE', '/mnt/d/carla_garage')

import sys
for p in (str(Path(GARAGE) / 'team_code'),
          str(Path(GARAGE) / 'leaderboard'),
          str(Path(GARAGE) / 'scenario_runner')):
    if p not in sys.path:
        sys.path.insert(0, p)

import carla                                            # noqa: E402
from sensor_agent import SensorAgent                    # noqa: E402


def _load(name, path):
    spec = importlib.util.spec_from_file_location(name, str(path))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


MS_TO_KMH = 3.6


def get_entry_point():
    return 'GuidedAgent'


class GuidedAgent(SensorAgent):
    """TransFuser++ supervised by ACG-NSM through disagreement suppression."""

    # ------------------------------------------------------------------
    def setup(self, path_to_conf_file, route_index=None, traffic_manager=None):
        super().setup(path_to_conf_file, route_index, traffic_manager)

        self.arbitrate = int(os.environ.get('ACGNSM_ARBITRATE', 0))
        self.log_path = os.environ.get('ACGNSM_LOG', 'acgnsm_witness.jsonl')
        weights = os.environ.get('ACGNSM_WEIGHTS',
                                 '/mnt/d/NSTM_Project/runs/finetune/weights/best.pt')
        tau = float(os.environ.get('ACGNSM_TAU', 0.25))
        stride = int(os.environ.get('ACGNSM_STRIDE', 1))
        libstm = os.environ.get('ACGNSM_LIBSTM',
                                '/mnt/d/NSTM_Project/stm/libstm.so')

        ch = _load('acgnsm_channel', SRC / '52_acgnsm_channel.py')
        ar = _load('arbiter', SRC / '51_suppression_arbiter.py')
        self.channel = ch.ACGNSMChannel(weights=weights, tau=tau,
                                        stride=stride, libstm=libstm)
        self.arbiter = ar.SuppressionArbiter()
        self._can_stop = ch.ACGNSMChannel.can_stop.__get__(self.channel)

        self._log = open(self.log_path, 'w')
        self._n = 0
        print(f'[ACG-NSM] guided agent ready  '
              f'arbitrate={self.arbitrate}  lambda={self.arbiter.lam:.3f}  '
              f'policy={self.arbiter.policy}  tau={tau}  stride={stride}')

    # ------------------------------------------------------------------
    def run_step(self, input_data, timestamp, sensors=None):
        control = super().run_step(input_data, timestamp, sensors)
        self._n += 1

        rec = {'tick': self._n, 'valid': False}
        try:
            # ---- nominal: captured from the planner's own computation ----
            dist = getattr(self, '_last_speed_distribution', None)
            scal = getattr(self, '_last_target_speed_scalar', None)
            if dist is None or scal is None:
                rec['warmup'] = True
                self._log.write(json.dumps(rec) + '\n')
                return control

            u_n = float(scal) * MS_TO_KMH
            brake_prob = float(dist[0])
            self_braked = bool(brake_prob >
                               self.config.brake_uncertainty_threshold)

            # ---- conservative: ACG-NSM with its own perception ----
            ego_kmh = float(self.state_log[-1][3]) * MS_TO_KMH \
                if len(self.state_log) else 0.0
            u_c, wit = self.channel.step(input_data, ego_kmh,
                                         maneuver='PROCEED')

            can_stop = self._can_stop(wit['gap_effective'], ego_kmh)
            u_star, arb = self.arbiter.arbitrate(
                u_n, u_c, permitted=wit['permitted'], can_stop=can_stop)

            rec.update({'valid': True,
                        'nominal': {'target_speed_kmh': round(u_n, 2),
                                    'brake_class_prob': round(brake_prob, 4),
                                    'self_braked': self_braked,
                                    'control': {'steer': round(control.steer, 4),
                                                'throttle': round(control.throttle, 4),
                                                'brake': round(control.brake, 4)}},
                        'conservative': wit,
                        'arbitration': arb,
                        'applied': bool(self.arbitrate)})

            # ---- apply, if guided ----
            if self.arbitrate and u_star < u_n - 1e-6:
                control = self._control_for_speed(control, ego_kmh, u_star)
                rec['applied_control'] = {'throttle': round(control.throttle, 4),
                                          'brake': round(control.brake, 4)}
        except Exception as e:
            rec['error'] = f'{type(e).__name__}: {e}'[:200]

        self._log.write(json.dumps(rec) + '\n')
        if self._n % 200 == 0:
            self._log.flush()
        return control

    # ------------------------------------------------------------------
    def _control_for_speed(self, control, ego_kmh, target_kmh):
        """Re-derive longitudinal control for the suppressed target speed.

        Steering is left exactly as the planner produced it: ACG-NSM suppresses
        how fast the vehicle goes, never where it goes.
        """
        err = target_kmh - ego_kmh
        c = carla.VehicleControl()
        c.steer = control.steer
        c.hand_brake = False
        c.reverse = False
        if err >= 0.0:
            c.throttle = min(control.throttle, 0.75)
            c.brake = 0.0
        else:
            deficit = min(1.0, -err / max(10.0, ego_kmh))
            c.throttle = 0.0
            c.brake = float(min(1.0, 0.25 + 0.75 * deficit))
        return c

    # ------------------------------------------------------------------
    def destroy(self, results=None):
        try:
            s = self.arbiter.summary()
            try:
                s['adaptation'] = self.channel.adaptation_report()
            except Exception:
                pass
            self._log.write(json.dumps({'summary': s}) + '\n')
            self._log.close()
            print(f'[ACG-NSM] {s}')
        except Exception:
            pass
        try:
            super().destroy(results)
        except Exception:
            super().destroy()
