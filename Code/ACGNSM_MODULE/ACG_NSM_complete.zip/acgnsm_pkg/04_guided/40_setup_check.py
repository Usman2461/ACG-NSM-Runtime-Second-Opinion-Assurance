"""
40_setup_check.py
=================
Verifies everything the dual-channel experiment needs, and reports exactly what
is missing rather than failing halfway through a run.

Run this FIRST, on the machine that will host the experiment:

    python src/40_setup_check.py --carla_root /path/to/CARLA_0.9.15 \
                                --garage_root /path/to/carla_garage
"""
import argparse, importlib.util, os, sys, glob, json
from pathlib import Path

OK, WARN, BAD = "  [ok]   ", "  [warn] ", "  [MISS] "
report = {}


def check(label, cond, detail="", warn_only=False):
    tag = OK if cond else (WARN if warn_only else BAD)
    print(f"{tag}{label}{('  -> ' + detail) if detail else ''}")
    report[label] = bool(cond)
    return cond


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--carla_root', default=os.environ.get('CARLA_ROOT', ''))
    ap.add_argument('--garage_root', default='')
    a = ap.parse_args()

    print("\n=== 1. Python and core packages ===")
    check(f"python {sys.version_info.major}.{sys.version_info.minor}",
          sys.version_info >= (3, 7), sys.version.split()[0])
    for mod in ('numpy', 'cv2', 'torch'):
        spec = importlib.util.find_spec(mod)
        detail = ""
        if spec and mod == 'torch':
            import torch
            detail = f"torch {torch.__version__}, cuda={torch.cuda.is_available()}"
        check(f"module {mod}", spec is not None, detail)

    print("\n=== 2. CARLA ===")
    spec = importlib.util.find_spec('carla')
    if check("carla python api importable", spec is not None):
        import carla
        v = getattr(carla, '__version__', 'unknown')
        check("carla version is 0.9.15", str(v).startswith('0.9.15'), str(v),
              warn_only=True)
        try:
            cl = carla.Client('127.0.0.1', 2000); cl.set_timeout(5.0)
            check("simulator reachable on :2000", True, cl.get_server_version())
        except Exception as e:
            check("simulator reachable on :2000", False, str(e)[:60])

    if a.carla_root:
        root = Path(a.carla_root)
        check("CARLA_ROOT exists", root.is_dir(), str(root))
        check("leaderboard present",
              (root / 'leaderboard').is_dir() or
              Path(a.carla_root, '..', 'leaderboard').is_dir(),
              warn_only=True)

    print("\n=== 3. carla_garage / TransFuser++ ===")
    if not a.garage_root:
        print(f"{WARN}--garage_root not given; skipping planner checks")
        print("        clone with:  git clone https://github.com/autonomousvision/carla_garage")
    else:
        g = Path(a.garage_root)
        check("carla_garage cloned", g.is_dir(), str(g))
        check("team_code present", (g / 'team_code').is_dir())
        ckpts = glob.glob(str(g / '**' / '*.pth'), recursive=True) + \
                glob.glob(str(g / '**' / '*.pt'), recursive=True)
        check("pretrained weights found", len(ckpts) > 0,
              f"{len(ckpts)} checkpoint file(s)")
        if ckpts:
            for c in ckpts[:5]:
                sz = os.path.getsize(c) / 1e6
                print(f"           {Path(c).name}  ({sz:.0f} MB)")
        cfgs = glob.glob(str(g / '**' / 'config.py'), recursive=True)
        check("config.py found", len(cfgs) > 0, cfgs[0] if cfgs else "")

    print("\n=== 4. ACG-NSM modules ===")
    here = Path(__file__).resolve().parent
    for m in ('11_risk_assessor.py', '12_legality_assessor.py',
              '13_rlc_bridge.py', '14_stm_adapter.py'):
        check(f"{m}", (here / m).is_file())
    check("libstm.so", (here.parent / 'stm' / 'libstm.so').is_file() or
          (here / 'libstm.so').is_file(), warn_only=True)

    missing = [k for k, v in report.items() if not v]
    print("\n" + "=" * 60)
    if missing:
        print(f"{len(missing)} item(s) need attention:")
        for m in missing:
            print(f"   - {m}")
    else:
        print("All checks passed. Ready to run the dual-channel harness.")
    json.dump(report, open(here.parent / 'results' / 'setup_check.json', 'w')
              if (here.parent / 'results').is_dir() else open('setup_check.json', 'w'),
              indent=2)


if __name__ == '__main__':
    main()
