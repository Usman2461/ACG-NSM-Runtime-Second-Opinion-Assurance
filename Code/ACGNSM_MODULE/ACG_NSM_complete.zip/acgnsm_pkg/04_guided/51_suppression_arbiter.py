"""
51_suppression_arbiter.py
=========================
The disagreement layer of ACG-NSM-guided TransFuser++.

Design (as specified)
---------------------
The conservative channel does not veto the nominal decision; it SUPPRESSES it.
The executed command is drawn from the nominal command toward the conservative
one by a fixed fraction of their difference:

    u* = u_N - lambda * max(0, u_N - u_C)

The max() ensures the conservative channel can only ever slow the vehicle: if it
wants to go faster than the planner, that is ignored.

lambda is fixed. Note that a fixed lambda already produces "more disagreement,
more suppression" in absolute terms, because the suppression applied is
lambda * (u_N - u_C) and therefore scales with the gap. The specified examples

    u_N = 60, u_C = 30  ->  execute 40     (20 of a possible 30 gap)
    u_N = 60, u_C = 0   ->  execute 20     (40 of a possible 60 gap)

both correspond to lambda = 2/3 exactly, which is the default here.

Policies
--------
'suppress'  (default)  Never overrides. Even a conservative STOP only pulls the
                       nominal command down by lambda of the gap. This is the
                       specified behaviour.

'guard'     (optional) Identical, except that when the conservative channel
                       forbids the maneuver outright -- a rule prohibits it, or
                       the vehicle physically cannot stop within the perceived
                       gap -- the conservative command is executed in full.

Both are provided so the choice can be settled by measurement rather than
argument. Set ACGNSM_POLICY=guard to switch.

An empirical prediction worth recording before the run, so it can be checked
rather than rationalised afterwards: under 'suppress', a situation in which the
conservative channel demands a stop because the obstacle is unavoidable will
still end in contact, merely at a lower speed. CARLA scores a collision as a
collision regardless of impact speed, so if the baseline's eight collisions are
of that kind, suppression alone will not remove them from the infraction count,
though it may reduce their severity. If instead the collisions arise from
excess speed carried into a situation that was still recoverable, suppression
should prevent them. Which of these holds is exactly what the experiment
measures.
"""
import os


class SuppressionArbiter:
    def __init__(self, lam=2.0 / 3.0, policy=None):
        self.lam = float(os.environ.get('ACGNSM_LAMBDA', lam))
        self.policy = (policy or os.environ.get('ACGNSM_POLICY', 'suppress')).lower()
        if self.policy not in ('suppress', 'guard'):
            raise ValueError(f"unknown policy {self.policy!r}")
        self.stats = {'ticks': 0, 'suppressed': 0, 'overridden': 0,
                      'speed_removed': 0.0, 'max_gap': 0.0}

    # ------------------------------------------------------------------
    def arbitrate(self, u_nominal, u_conservative, permitted=True,
                  can_stop=True):
        """Return (executed_speed, record).

        u_nominal        km/h requested by the planner
        u_conservative   km/h the conservative channel would command
        permitted        False when a rule forbids the intended maneuver
        can_stop         False when the vehicle cannot stop within the gap
        """
        self.stats['ticks'] += 1
        gap = max(0.0, u_nominal - u_conservative)
        self.stats['max_gap'] = max(self.stats['max_gap'], gap)

        hard = (not permitted) or (not can_stop)
        if self.policy == 'guard' and hard:
            u_exec = u_conservative
            mode = 'override'
            self.stats['overridden'] += 1
        else:
            u_exec = u_nominal - self.lam * gap
            mode = 'suppress' if gap > 1e-9 else 'accept'
            if gap > 1e-9:
                self.stats['suppressed'] += 1

        self.stats['speed_removed'] += (u_nominal - u_exec)

        return u_exec, {
            'u_nominal': round(u_nominal, 3),
            'u_conservative': round(u_conservative, 3),
            'disagreement': round(gap, 3),
            'lambda': self.lam,
            'policy': self.policy,
            'hard_condition': hard,
            'mode': mode,
            'u_executed': round(u_exec, 3),
            'suppression_applied': round(u_nominal - u_exec, 3),
        }

    # ------------------------------------------------------------------
    def summary(self):
        n = max(1, self.stats['ticks'])
        return {
            'ticks': self.stats['ticks'],
            'suppression_rate': self.stats['suppressed'] / n,
            'override_rate': self.stats['overridden'] / n,
            'mean_speed_removed_kmh': self.stats['speed_removed'] / n,
            'max_disagreement_kmh': self.stats['max_gap'],
            'lambda': self.lam,
            'policy': self.policy,
        }


if __name__ == '__main__':
    print("Specified examples, lambda = 2/3, policy = suppress\n")
    a = SuppressionArbiter()
    print(f"{'nominal':>9}{'conserv':>9}{'gap':>7}{'executed':>10}  note")
    print('-' * 52)
    for un, uc, note in ((60, 30, 'moderate disagreement'),
                         (60, 0, 'conservative wants a stop'),
                         (60, 60, 'channels agree'),
                         (40, 55, 'conservative faster: ignored')):
        u, r = a.arbitrate(un, uc)
        print(f"{un:>9.0f}{uc:>9.0f}{r['disagreement']:>7.0f}{u:>10.1f}  {note}")

    print("\nSame situations under policy = guard "
          "(conservative forbids the maneuver)\n")
    b = SuppressionArbiter(policy='guard')
    for un, uc, perm, note in ((60, 30, True, 'permitted: blended as before'),
                               (60, 0, False, 'forbidden: handed over in full')):
        u, r = b.arbitrate(un, uc, permitted=perm)
        print(f"{un:>9.0f}{uc:>9.0f}{r['disagreement']:>7.0f}{u:>10.1f}  {note}")
