"""
41_dual_channel.py
==================
Runs a frozen neural planner and the ACG-NSM conservative channel in parallel
on the SAME CARLA tick, compares their decisions, arbitrates, and logs a
complete witness for every decision instant.

    shared world tick
        |-- NominalChannel      (TransFuser++, frozen)      -> u_N, maneuver_N
        |-- ConservativeChannel (ACG-NSM)                    -> u_C, maneuver_C
                |
                +-- DisagreementAnalyser  -> magnitude, materiality
                        +-- Arbiter       -> u_exec, correction strength
                                +-- witness (one JSON record per tick)

Both channels observe the same simulated world at the same tick through their
own sensor rigs. That is stated precisely rather than as "identical inputs",
because the planner requires the camera/LiDAR configuration it was trained on.

The planner is reached ONLY through PlannerAdapter, so the integration is
isolated in one class. Run with --mock_planner to exercise the entire pipeline
before the real weights are wired in.

Usage
    # plumbing test, no model, no simulator required
    python src/41_dual_channel.py --mock_planner --offline --ticks 200

    # real run
    python src/41_dual_channel.py --garage_root /path/to/carla_garage \
        --checkpoint /path/to/model.pth --host 127.0.0.1 --ticks 2000
"""
import argparse, json, importlib.util, math, random, sys, time
from pathlib import Path

SRC = Path(__file__).resolve().parent


def _load(name, path):
    spec = importlib.util.spec_from_file_location(name, str(path))
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m


# ------------------------------------------------------------------ channels
class PlannerAdapter:
    """The ONLY place that knows about the neural planner.

    Contract: act(obs) -> dict(target_speed_kmh, maneuver, raw)
    `maneuver` is one of PROCEED / TURN_LEFT / TURN_RIGHT / STOP.

    TransFuser++ emits waypoints plus a predicted target speed; we take the
    target speed directly and derive the maneuver from the lateral offset of
    the near-horizon waypoints. That conversion is a stated design choice, not
    a property of the model.
    """

    def __init__(self, garage_root=None, checkpoint=None, mock=False, seed=0):
        self.mock = mock
        self.rng = random.Random(seed)
        self.net = None
        if mock:
            return
        if not garage_root or not checkpoint:
            raise SystemExit("PlannerAdapter needs --garage_root and --checkpoint "
                             "(or pass --mock_planner)")
        sys.path.insert(0, str(Path(garage_root) / 'team_code'))
        import torch
        self.torch = torch
        # NOTE: class name/config entry point is repo-specific; verified at setup.
        from model import LidarCenterNet          # carla_garage team_code
        from config import GlobalConfig
        cfg = GlobalConfig()
        self.cfg = cfg
        self.net = LidarCenterNet(cfg)
        sd = torch.load(checkpoint, map_location='cpu')
        self.net.load_state_dict(sd, strict=False)
        self.net.eval()
        if torch.cuda.is_available():
            self.net.cuda()

    def act(self, obs):
        if self.mock:
            # plausible nominal behaviour: cruise, occasionally optimistic
            base = 45.0 + self.rng.gauss(0, 4)
            if obs.get('gap', 99) < 15:
                base = min(base, 25.0 + self.rng.gauss(0, 6))
            man = 'PROCEED'
            if obs.get('intent') == 'left':
                man = 'TURN_LEFT'
            return dict(target_speed_kmh=max(0.0, base), maneuver=man, raw=None)

        with self.torch.no_grad():
            out = self.net.forward(**obs['planner_inputs'])
        ts = float(out['target_speed']) if isinstance(out, dict) else float(out[0])
        wps = out.get('pred_wp') if isinstance(out, dict) else None
        man = 'PROCEED'
        if wps is not None:
            lat = float(wps[0][-1][1]) - float(wps[0][0][1])
            man = 'TURN_LEFT' if lat < -1.5 else ('TURN_RIGHT' if lat > 1.5 else 'PROCEED')
        return dict(target_speed_kmh=ts * 3.6 if ts < 30 else ts,
                    maneuver=man, raw=None)


class ConservativeChannel:
    """ACG-NSM: calibrate, gate, fail-safe, risk, legality -> speed + maneuver."""

    ORDER = ['PROCEED', 'TURN_LEFT', 'TURN_RIGHT',
             'LANE_CHANGE_L', 'LANE_CHANGE_R', 'STOP']

    def __init__(self, speed_limit=50.0):
        self.risk = _load('risk', SRC / '11_risk_assessor.py')
        self.leg = _load('leg', SRC / '12_legality_assessor.py')
        self.bridge_mod = _load('bridge', SRC / '13_rlc_bridge.py')
        self.bridge = self.bridge_mod.RLCBridge(weather='clear', ablation='full')
        self.speed_limit = speed_limit

    def act(self, perc, maneuver):
        out = self.bridge.process(perc, {'speed_limit': self.speed_limit})
        ram = out['ram']
        perms = {a for i, a in enumerate(self.ORDER) if ram['LegalMask'] & (1 << i)}
        tier = ram['RiskTier']
        gap = perc['obs_dist'][0]
        permitted = maneuver in perms
        if not permitted:
            ts = 0.0
        elif tier >= 3:
            ts = 0.0
        elif tier == 2:
            ts = min(self.speed_limit, max(0.0, (gap / 1.5) * 3.6)) if gap > 0 else 8.0
        elif tier == 1:
            ts = min(self.speed_limit, max(0.0, (gap / 1.2) * 3.6)) if gap > 0 else 18.0
        else:
            ts = self.speed_limit
        return dict(target_speed_kmh=ts, maneuver=(maneuver if permitted else 'STOP'),
                    permitted=permitted, risk_tier=tier,
                    legal_mask=ram['LegalMask'],
                    article=ram.get('ViolationArticle', 0),
                    gate=out.get('audit', {}).get('gates', {}),
                    fail_safe=out.get('audit', {}).get('fail_safe', []))


# -------------------------------------------------------- disagreement + arbiter
def analyse(nom, con, evidence):
    dv = nom['target_speed_kmh'] - con['target_speed_kmh']
    d_norm = abs(dv) / max(evidence['speed_limit'], 1e-6)
    man_conflict = nom['maneuver'] != con['maneuver']
    conf_min = evidence['conf_min']
    materiality = min(1.0, 0.5 * d_norm
                      + 0.3 * (con['risk_tier'] / 3.0)
                      + 0.2 * (1.0 - conf_min))
    return dict(delta_speed=dv, delta_norm=d_norm,
                maneuver_conflict=man_conflict, materiality=materiality)


def arbitrate(nom, con, dis):
    """Hard constraints are non-negotiable; otherwise correct proportionally."""
    if not con['permitted']:                 # legality or critical risk
        return con['target_speed_kmh'], 1.0, 'OVERRIDE'
    if dis['maneuver_conflict']:
        return con['target_speed_kmh'], 1.0, 'OVERRIDE'
    if dis['delta_speed'] <= 0:              # nominal already at or below
        return nom['target_speed_kmh'], 0.0, 'ACCEPT'
    lam = max(0.0, min(1.0, dis['materiality']))
    u = nom['target_speed_kmh'] - lam * dis['delta_speed']
    state = 'ACCEPT' if lam < 0.05 else ('WATCH' if lam < 0.25 else
                                         'CAUTION' if lam < 0.60 else 'RESTRICT')
    return u, lam, state


# ------------------------------------------------------------------- offline
def synthetic_tick(rng, degrade):
    true_gap = rng.choice([rng.uniform(5, 20), rng.uniform(20, 60), 100.0])
    ego = rng.uniform(15, 60)
    ped = rng.random() < 0.30
    onc = rng.random() < 0.30
    light = rng.choice([-1, 0, 1, 2])
    base = 0.96 - 0.55 * degrade
    jit = lambda c: max(0.05, min(0.99, rng.gauss(c, 0.05 + 0.10 * degrade)))
    pf = 0.02 + 0.35 * degrade
    obs_gap = max(0.5, true_gap * rng.gauss(1.0, 0.03 + 0.15 * degrade))
    cp, cl, co, cd = jit(base), jit(base), jit(base - 0.03), jit(base)
    perc = {'obs_dist': (obs_gap, cd), 'ego_speed': (ego, 0.95),
            'pedestrian': (ped ^ (rng.random() < pf), cp),
            'traffic_light': (light, cl),
            'oncoming': (onc ^ (rng.random() < pf), co)}
    truth = dict(gap=true_gap, ego=ego, ped=ped, onc=onc, light=light)
    return perc, truth, min(cp, cl, co, cd), obs_gap


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--garage_root'); ap.add_argument('--checkpoint')
    ap.add_argument('--mock_planner', action='store_true')
    ap.add_argument('--offline', action='store_true',
                    help='synthetic ticks; no simulator needed')
    ap.add_argument('--ticks', type=int, default=500)
    ap.add_argument('--degrade', type=float, default=0.4)
    ap.add_argument('--seed', type=int, default=0)
    ap.add_argument('--out', default='dual_channel_log.jsonl')
    a = ap.parse_args()

    planner = PlannerAdapter(a.garage_root, a.checkpoint, mock=a.mock_planner,
                             seed=a.seed)
    cons = ConservativeChannel()
    rng = random.Random(a.seed)

    counts = {'ACCEPT': 0, 'WATCH': 0, 'CAUTION': 0, 'RESTRICT': 0, 'OVERRIDE': 0}
    lam_sum = 0.0
    n_blend = 0
    fh = open(a.out, 'w')

    for t in range(a.ticks):
        if not a.offline:
            raise SystemExit("closed-loop path requires the CARLA runner; "
                             "use --offline for the plumbing test")
        perc, truth, conf_min, gap = synthetic_tick(rng, a.degrade)
        intent = 'left' if rng.random() < 0.35 else 'straight'
        maneuver = 'TURN_LEFT' if intent == 'left' else 'PROCEED'

        nom = planner.act(dict(gap=gap, intent=intent))
        con = cons.act(perc, maneuver)
        ev = dict(speed_limit=50.0, conf_min=conf_min)
        dis = analyse(nom, con, ev)
        u, lam, state = arbitrate(nom, con, dis)

        counts[state] += 1
        lam_sum += lam
        if 0.0 < lam < 1.0:
            n_blend += 1

        fh.write(json.dumps(dict(
            tick=t, truth=truth, conf_min=round(conf_min, 3),
            nominal=nom, conservative={k: v for k, v in con.items()
                                       if k not in ('gate',)},
            disagreement={k: (round(v, 4) if isinstance(v, float) else v)
                          for k, v in dis.items()},
            arbitration=dict(state=state, correction=round(lam, 4),
                             executed_kmh=round(u, 2)))) + "\n")
    fh.close()

    print(f"ticks: {a.ticks}   degradation: {a.degrade}")
    print(f"mean correction strength: {lam_sum/a.ticks:.3f}")
    print(f"partial corrections (0<lam<1): {100*n_blend/a.ticks:.1f}%")
    print("arbitration states:")
    for k, v in counts.items():
        print(f"   {k:<9} {100*v/a.ticks:>6.1f}%")
    print(f"\n[OK] witness log -> {a.out}")


if __name__ == '__main__':
    main()
