"""
42_tfpp_adapter.py
==================
Wraps carla_garage's SensorAgent (TransFuser++) so the dual-channel harness can
read its nominal decision WITHOUT modifying the upstream repository.

Why a subclass rather than calling the network directly
------------------------------------------------------
SensorAgent.run_step() returns a carla.VehicleControl; the target speed is
computed internally (sensor_agent.py:587) and converted to throttle/brake/steer
before returning. The agent is also stateful across ticks -- GPS filtering, a
LiDAR ring buffer, a stop-sign buffer and a state log -- and returns brake=1.0
until the LiDAR buffer has filled. Re-implementing the preprocessing would
therefore be both duplicative and wrong. We subclass instead and capture the
intermediate quantities as they are produced, so the planner runs exactly as
published.

Captured per tick
    u_N                 pred_target_speed_scalar  (m/s -> km/h)
    speed_distribution  softmax over the 8 target-speed classes
    self_braked         True when the agent triggered its OWN uncertainty brake
                        (sensor_agent.py:584). This is TransFuser++ being
                        cautious by itself, and must not be attributed to our
                        conservative channel.
    control             the VehicleControl it would have executed

IMPORTANT: because the agent is stateful and warm-starts, it cannot be replayed
on stored frames independently of its own history. It must run live in the loop.
"""
import os, sys, json
from pathlib import Path

MS_TO_KMH = 3.6


def build_agent_class(garage_root):
    """Import SensorAgent lazily and return a capturing subclass."""
    tc = Path(garage_root) / 'team_code'
    lb = Path(garage_root) / 'leaderboard'
    for p in (str(tc), str(lb), str(Path(garage_root) / 'scenario_runner')):
        if p not in sys.path:
            sys.path.insert(0, p)

    from sensor_agent import SensorAgent  # noqa: E402

    class CapturingSensorAgent(SensorAgent):
        """SensorAgent that records its nominal decision for the arbiter."""

        def setup(self, path_to_conf_file, route_index=None, traffic_manager=None):
            super().setup(path_to_conf_file, route_index, traffic_manager)
            self.nominal = dict(valid=False)

        def run_step(self, input_data, timestamp, sensors=None):
            control = super().run_step(input_data, timestamp, sensors)

            # inference_target_speeds is in m/s; the scalar is recomputed here
            # from the same tensors the agent used, so no upstream edit is needed.
            n = dict(valid=False, warmup=True)
            try:
                dist = getattr(self, '_last_speed_distribution', None)
                scal = getattr(self, '_last_target_speed_scalar', None)
                if dist is not None and scal is not None:
                    brake_prob = float(dist[0])
                    n = dict(
                        valid=True, warmup=False,
                        target_speed_kmh=float(scal) * MS_TO_KMH,
                        speed_distribution=[float(x) for x in dist],
                        brake_class_prob=brake_prob,
                        self_braked=bool(
                            brake_prob > self.config.brake_uncertainty_threshold),
                        control=dict(steer=float(control.steer),
                                     throttle=float(control.throttle),
                                     brake=float(control.brake)),
                    )
            except Exception as e:                      # never break the run
                n = dict(valid=False, error=str(e)[:120])
            self.nominal = n
            return control

    return CapturingSensorAgent


PATCH_NOTE = r"""
The two intermediates we need are local variables inside run_step. Rather than
forking sensor_agent.py, add these two lines to it (they only assign to self,
and change no behaviour):

    # sensor_agent.py, immediately after line 583
    #     uncertainty = pred_target_speed_ensemble.detach().cpu().numpy()
    self._last_speed_distribution = uncertainty

    # sensor_agent.py, immediately after line 587
    #     pred_target_speed_scalar = sum(uncertainty * self.inference_target_speeds)
    self._last_target_speed_scalar = pred_target_speed_scalar

Apply automatically with:
    python src/42_tfpp_adapter.py --patch /mnt/d/carla_garage
A timestamped backup of the original file is written alongside it.
"""


def apply_patch(garage_root):
    f = Path(garage_root) / 'team_code' / 'sensor_agent.py'
    src = f.read_text()
    if '_last_target_speed_scalar' in src:
        print('[skip] already patched')
        return
    a = 'uncertainty = pred_target_speed_ensemble.detach().cpu().numpy()'
    b = 'pred_target_speed_scalar = sum(uncertainty * self.inference_target_speeds)'
    if a not in src or b not in src:
        raise SystemExit('[FAIL] anchor lines not found; upstream file differs '
                         'from the version this adapter was written against')
    indent_a = src[:src.index(a)].split('\n')[-1]
    indent_b = src[:src.index(b)].split('\n')[-1]
    src = src.replace(a, a + '\n' + indent_a + 'self._last_speed_distribution = uncertainty', 1)
    src = src.replace(b, b + '\n' + indent_b + 'self._last_target_speed_scalar = pred_target_speed_scalar', 1)
    import time
    bak = f.with_suffix(f'.py.bak.{int(time.time())}')
    bak.write_text(f.read_text())
    f.write_text(src)
    print(f'[OK] patched {f}\n[OK] backup {bak}')



def apply_pretrained_patch(garage_root):
    """Stop timm fetching ImageNet weights for the image/LiDAR encoders.

    transfuser.py builds the encoders with pretrained=True, which contacts
    HuggingFace. Those weights are immediately overwritten by the TransFuser++
    checkpoint (load_state_dict(..., strict=True) verifies every parameter is
    supplied), so the download is unnecessary -- and impossible on a host
    without outbound network access. We set pretrained=False instead.
    """
    import time, re
    f = Path(garage_root) / 'team_code' / 'transfuser.py'
    src = f.read_text()
    if 'pretrained=True' not in src:
        print('[skip] transfuser.py already patched')
        return
    n = src.count('pretrained=True')
    if n == 0:
        raise SystemExit('[FAIL] no pretrained=True found in transfuser.py')
    bak = f.with_suffix(f'.py.bak.{int(time.time())}')
    bak.write_text(src)
    src = src.replace('pretrained=True', 'pretrained=False')
    f.write_text(src)
    print(f'[OK] transfuser.py: {n} occurrence(s) of pretrained=True -> False')
    print(f'[OK] backup {bak}')

if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--patch', metavar='GARAGE_ROOT')
    ap.add_argument('--show', action='store_true')
    a = ap.parse_args()
    if a.patch:
        # both patches are attempted independently; each is individually idempotent
        try:
            apply_patch(a.patch)
        except SystemExit as e:
            print(f'[sensor_agent] {e}')
        try:
            apply_pretrained_patch(a.patch)
        except SystemExit as e:
            print(f'[transfuser] {e}')
    else:
        print(PATCH_NOTE)
