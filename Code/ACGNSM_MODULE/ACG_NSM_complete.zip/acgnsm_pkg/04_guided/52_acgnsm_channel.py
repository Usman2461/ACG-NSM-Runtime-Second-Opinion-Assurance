"""
52_acgnsm_channel.py
====================
The ACG-NSM conservative channel, running with its OWN perception alongside
TransFuser++.

Independence, stated precisely
------------------------------
The CARLA leaderboard caps the sensor suite an agent may declare, so this
channel reads the same rgb_front and lidar streams the planner receives. It
does NOT reuse any of the planner's features, detections or intermediate
tensors. Perception is performed by a separately trained YOLOv8 detector and a
separate LiDAR routine, so the two channels have independent perception MODELS
with independent failure modes on a shared sensor front-end. That is analytic
redundancy, not full sensor redundancy, and it should be described as such: a
sensor-level fault (a blinded camera, a dead LiDAR) degrades both channels
together, whereas a model-level error in one does not imply the same error in
the other.

Pipeline
--------
    rgb_front  --> YOLOv8 (5 classes) --> pedestrian / vehicle / traffic light
    lidar      --> forward corridor   --> nearest obstacle distance
                        |
                   calibration (temperature scaling)
                        |
              risk assessor  +  legality assessor
                        |
                   RLC bridge with graded fail-safe
                        |
                 decision state machine
                        |
              conservative action + target speed
"""
import os, math, importlib.util
from pathlib import Path
import numpy as np

SRC = Path(__file__).resolve().parent


def _load(name, path):
    spec = importlib.util.spec_from_file_location(name, str(path))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


# class ids of the retrained detector (7 classes, lights split by state)
CLS_PED       = 0
CLS_VEHICLE   = 1
CLS_LIGHT_RED = 2
CLS_LIGHT_YEL = 3
CLS_LIGHT_GRN = 4
CLS_CYCLIST   = 5
CLS_SIGN      = 6

# CARLA signal encoding used by the legality assessor
SIG_UNKNOWN, SIG_RED, SIG_GREEN, SIG_YELLOW = -1, 0, 1, 2

# Calibration temperature. The value below was fitted for the previous
# detector; refit on the new validation split before trusting the gate, since
# an NMS-free head produces a different confidence distribution and a stale
# temperature silently mis-scales every threshold comparison.
TEMPERATURE = float(os.environ.get('ACGNSM_TEMPERATURE', 2.30))


def calibrate(p, T=TEMPERATURE):
    """Temperature-scale a detector confidence. T>1 lowers overconfidence."""
    p = min(max(float(p), 1e-6), 1.0 - 1e-6)
    logit = math.log(p / (1.0 - p))
    return 1.0 / (1.0 + math.exp(-logit / T))


class ACGNSMChannel:
    """Conservative channel: independent perception -> ACG-NSM -> target speed."""

    def __init__(self, weights, tau=0.25, device='cuda', imgsz=640,
                 conf_floor=0.10, stride=1, speed_limit=50.0,
                 libstm=None, verbose=False):
        from ultralytics import YOLO
        self.yolo = YOLO(str(weights))
        self.device = device
        self.imgsz = imgsz
        self.conf_floor = conf_floor
        self.stride = max(1, int(stride))     # run detector every Nth tick
        self.speed_limit = speed_limit
        self.verbose = verbose

        gb = _load('graded_bridge', SRC / '50_graded_bridge.py')
        self.bridge = gb.GradedBridge(tau=tau, speed_limit=speed_limit)

        # Absence confidence needs the detector's measured reliability. Without
        # it the posterior falls back to the previous detector's numbers, which
        # would mis-state how much a non-detection is worth.
        self.absence = _load('absence', SRC / '54_absence_confidence.py')
        metrics = os.environ.get(
            'ACGNSM_DET_METRICS',
            str(Path(weights).parent.parent / 'per_class_metrics.json'))
        if Path(metrics).is_file():
            got = self.absence.load_detector_metrics(metrics)
            print(f'[ACG-NSM] detector reliability from {metrics}')
            print(f'          recall {got["recall"]}')
        else:
            print(f'[ACG-NSM] WARNING no per-class metrics at {metrics}; '
                  f'absence confidence is using stale defaults')

        # optional compiled state machine
        self.stm = None
        if libstm and Path(libstm).is_file():
            try:
                ad = _load('stm_adapter', SRC / '14_stm_adapter.py')
                self.stm = ad.STMAdapter(str(libstm))
                self.stm.init()
            except Exception as e:
                print(f'[ACG-NSM] state machine unavailable ({e}); '
                      f'using bridge decision only')

        print(f'[ACG-NSM] channel build 2026-08-16b  '
              f'7-class detector, evidence-based absence, graded gate tau={tau}')
        self._tick = 0
        self._cache = None
        self._q = 1.0
        self._q_parts = {}

    # ------------------------------------------------------------- perception
    def _detect(self, rgb):
        """YOLOv8 on the front camera -> per-field (value, calibrated conf)."""
        res = self.yolo.predict(rgb, imgsz=self.imgsz, conf=self.conf_floor,
                                device=self.device, verbose=False)[0]
        best = {}
        for b in res.boxes:
            c = int(b.cls.item())
            p = float(b.conf.item())
            if p > best.get(c, (0.0,))[0]:
                xy = b.xyxy[0].tolist()
                best[c] = (p, xy)

        def field(cls, name):
            if cls in best:
                p, _ = best[cls]
                return True, calibrate(p)
            # Nothing detected. How much that is worth depends on how well the
            # region was observed, so the confidence in ABSENCE is a posterior
            # over observation quality rather than a constant. A fixed value
            # here previously sat below every gate threshold and asserted a
            # hazard on all 12544 ticks of the first run.
            return False, self.absence.absence_confidence(name, self._q)

        ped_v, ped_c = field(CLS_PED, 'pedestrian')
        veh_v, veh_c = field(CLS_VEHICLE, 'oncoming')

        # Signal state now comes from the detector directly: the retrained
        # model separates red, yellow and green, so the legality assessor can
        # evaluate signal compliance instead of receiving a permanent unknown.
        # Where several lights are visible the most restrictive state wins,
        # which matches the assessor's conjunctive most-restrictive rule and
        # errs toward stopping when the scene is ambiguous.
        lights = [(SIG_RED, CLS_LIGHT_RED),
                  (SIG_YELLOW, CLS_LIGHT_YEL),
                  (SIG_GREEN, CLS_LIGHT_GRN)]
        signal, sig_conf = SIG_UNKNOWN, None
        for state, cls in lights:            # red first, then yellow, then green
            if cls in best:
                signal = state
                sig_conf = calibrate(best[cls][0])
                break
        else:
            sig_conf = self.absence.absence_confidence('traffic_light', self._q)

        return {
            'pedestrian': (ped_v, ped_c),
            'oncoming': (veh_v, veh_c),
            'traffic_light': (signal, sig_conf),
        }

    def _lidar_gap(self, lidar):
        """Nearest return inside the forward driving corridor, in metres."""
        if lidar is None or len(lidar) == 0:
            return 100.0, 0.30
        pts = np.asarray(lidar)[:, :3]
        # forward corridor: ahead of the vehicle, within half a lane either side
        m = (pts[:, 0] > 1.5) & (np.abs(pts[:, 1]) < 1.6) & (pts[:, 2] > -1.4)
        sel = pts[m]
        if sel.shape[0] < 5:
            return 100.0, 0.55          # sparse: no obstacle, but low certainty
        d = float(np.min(np.linalg.norm(sel[:, :2], axis=1)))
        # confidence grows with return density, saturating quickly
        conf = min(0.97, 0.60 + 0.02 * math.sqrt(sel.shape[0]))
        return d, conf

    # ---------------------------------------------------------------- stepping
    def step(self, input_data, ego_speed_kmh, maneuver='PROCEED'):
        """Returns (target_speed_kmh, witness). Never touches the planner."""
        self._tick += 1
        run_detector = (self._tick % self.stride == 1) or self._cache is None

        rgb = input_data.get('rgb_front', (None, None))[1]
        if rgb is not None and rgb.ndim == 3 and rgb.shape[2] == 4:
            rgb = rgb[:, :, :3][:, :, ::-1]         # BGRA -> RGB

        lidar_raw = input_data.get('lidar', (None, None))[1]
        self._q, self._q_parts = self.absence.observation_quality(rgb, lidar_raw)

        if run_detector and rgb is not None:
            self._cache = self._detect(rgb)
        percep = dict(self._cache or {
            'pedestrian': (False, 0.5), 'oncoming': (False, 0.5),
            'traffic_light': (-1, 0.5)})

        lidar = input_data.get('lidar', (None, None))[1]
        gap, gap_conf = self._lidar_gap(lidar)
        percep['obs_dist'] = (gap, gap_conf)
        percep['ego_speed'] = (ego_speed_kmh, 0.95)

        out = self.bridge.process(percep, {'speed_limit': self.speed_limit})
        u_c = self.bridge.target_speed(out, maneuver)

        # state machine arbitration, when available
        stm_state, stm_action = None, None
        if self.stm is not None:
            try:
                tier = out['risk_tier']
                permitted = maneuver in out['permissions']
                flags = {'stopline_reached': False, 'at_stopline': False,
                         'signal': -1, 'oncoming': out['asserted']['oncoming'],
                         'pedestrian': out['asserted']['pedestrian'],
                         'current_state': self.stm.state_name(),
                         'committed_to_turn': False}
                bout = {'ram': {'RiskTier': tier,
                                'LegalMask': out['legal_mask'],
                                'ViolationArticle': out['article']},
                        'events': []}
                r = self.stm.step_from_bridge(bout, flags)
                stm_state, stm_action = r.get('state_name'), r.get('action')
                if stm_action in ('Brake', 'Hold', 'EmergBrake'):
                    u_c = 0.0
                elif stm_action == 'SlowDown':
                    u_c = min(u_c, max(0.0, (out['gap_effective'] / 1.5) * 3.6))
            except Exception:
                pass

        witness = {
            'tick': self._tick,
            'perception': {k: [v[0] if not isinstance(v[0], bool) else bool(v[0]),
                               round(v[1], 3)] for k, v in percep.items()},
            'risk_raw': round(out['risk_raw'], 4),
            'risk_graded': round(out['risk_graded'], 4),
            'risk_tier': out['risk_tier'],
            'beliefs': {k: round(v, 3) for k, v in out['beliefs'].items()},
            'residual_belief': round(out['residual_belief'], 3),
            'asserted': out['asserted'],
            'permitted': maneuver in out['permissions'],
            'article': out['article'],
            'gap_effective': round(out['gap_effective'], 2),
            'observation_quality': round(self._q, 3),
            'theta': out.get('theta'),
            'observation_parts': self._q_parts,
            'sensor_fault': out['sensor_fault'],
            'stm_state': stm_state,
            'stm_action': stm_action,
            'u_conservative': round(u_c, 2),
        }
        return u_c, witness

    def adaptation_report(self):
        """Threshold drift over the run, for the audit trail."""
        try:
            return self.bridge.adaptation_report()
        except Exception as e:
            return {'error': str(e)[:120]}

    # ------------------------------------------------------------------ helper
    def can_stop(self, out_gap_m, ego_kmh, mu=0.7, t_react=0.3):
        v = ego_kmh / 3.6
        d = v * t_react + (v * v) / (2 * mu * 9.81)
        return d <= max(0.1, out_gap_m)


if __name__ == '__main__':
    print(__doc__)
    print("calibration check (temperature scaling, T = %.2f):" % TEMPERATURE)
    for p in (0.95, 0.85, 0.70, 0.50, 0.30):
        print(f"   raw {p:.2f}  ->  calibrated {calibrate(p):.3f}")
