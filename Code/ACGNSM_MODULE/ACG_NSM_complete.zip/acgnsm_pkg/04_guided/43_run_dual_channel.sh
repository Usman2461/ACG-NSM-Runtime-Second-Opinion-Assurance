#!/usr/bin/env bash
# 43_run_dual_channel.sh
# ======================
# Runs TransFuser++ on official leaderboard routes with the ACG-NSM conservative
# channel evaluated in parallel, using carla_garage's LOCAL evaluator (no SLURM).
#
# Environment variables are set to exactly the values used by the authors'
# own evaluation script (evaluate_routes_slurm_tfpp.py), so the planner runs
# as published. They are echoed at the start of every run and must be quoted
# in the paper's reproducibility section.
#
# Usage:
#   bash src/43_run_dual_channel.sh                    # devtest, 1 route
#   ROUTES=routes_validation bash src/43_run_dual_channel.sh
set -euo pipefail

# ---------------------------------------------------------------- paths
GARAGE=${GARAGE:-/mnt/d/carla_garage}
export CARLA_ROOT=${CARLA_ROOT:-/mnt/d/CARLA_0.9.15/WindowsNoEditor}
export SCENARIO_RUNNER_ROOT=${GARAGE}/scenario_runner
export LEADERBOARD_ROOT=${GARAGE}/leaderboard
export PYTHONPATH="${CARLA_ROOT}/PythonAPI/carla:${SCENARIO_RUNNER_ROOT}:${LEADERBOARD_ROOT}:${GARAGE}/team_code:${PYTHONPATH:-}"

HOST=${HOST:-192.168.144.1}          # CARLA server (Windows host from WSL)
PORT=${PORT:-2000}
TM_PORT=${TM_PORT:-8000}

ROUTES_NAME=${ROUTES:-routes_devtest}
export ROUTES=${LEADERBOARD_ROOT}/data/${ROUTES_NAME}.xml
export TEAM_AGENT=${ACGNSM_AGENT:-${GARAGE}/team_code/sensor_agent.py}
export TEAM_CONFIG=${TEAM_CONFIG:-${GARAGE}/pretrained_models/all_towns}

OUT=${OUT:-/mnt/d/NSTM_Project/results/dual_channel}
mkdir -p "${OUT}"
export CHECKPOINT_ENDPOINT=${OUT}/${ROUTES_NAME}_results.json
export SAVE_PATH=${OUT}/logs
mkdir -p "${SAVE_PATH}"

# ------------------------------------------- agent behaviour (as published)
export CHALLENGE_TRACK_CODENAME=SENSORS
export REPETITIONS=1
export RESUME=0
export SEED=${SEED:-0}
export DEBUG_ENV_AGENT=0
export RECORD=0
export DIRECT=1
export COMPILE=0
export TOWN=eval
export REPETITION=0
export DATAGEN=0
export TUNED_AIM_DISTANCE=0
export SLOWER=0
export UNCERTAINTY_WEIGHT=1
export STOP_AFTER_METER=-1
export STOP_CONTROL=${STOP_CONTROL:-1}

# ------------------------------------------------- offline / determinism
export HF_HUB_OFFLINE=1              # no network in WSL; timm must not fetch
export TRANSFORMERS_OFFLINE=1
export ACGNSM_ENABLE=${ACGNSM_ENABLE:-1}      # run the conservative channel
export ACGNSM_ARBITRATE=${ACGNSM_ARBITRATE:-0} # 0 = observe only, 1 = allow override
export ACGNSM_LOG=${OUT}/${ROUTES_NAME}_witness.jsonl
export ACGNSM_WEIGHTS=${ACGNSM_WEIGHTS:-/mnt/d/NSTM_Project/runs/finetune/weights/best.pt}
export ACGNSM_TAU=${ACGNSM_TAU:-0.25}
export ACGNSM_STRIDE=${ACGNSM_STRIDE:-1}
export ACGNSM_LAMBDA=${ACGNSM_LAMBDA:-0.6667}
export ACGNSM_POLICY=${ACGNSM_POLICY:-suppress}
export ACGNSM_LIBSTM=${ACGNSM_LIBSTM:-/mnt/d/NSTM_Project/stm/libstm.so}

echo "=================================================================="
echo " routes            : ${ROUTES}"
echo " agent             : ${TEAM_AGENT}"
echo " checkpoint dir    : ${TEAM_CONFIG}"
echo " models present    : $(ls "${TEAM_CONFIG}"/model*.pth 2>/dev/null | wc -l)"
echo " carla             : ${HOST}:${PORT}"
echo " ACG-NSM enabled   : ${ACGNSM_ENABLE}   arbitrate: ${ACGNSM_ARBITRATE}"
echo " witness log       : ${ACGNSM_LOG}"
echo " agent env         : DIRECT=${DIRECT} UNCERTAINTY_WEIGHT=${UNCERTAINTY_WEIGHT}"
echo "                     SLOWER=${SLOWER} STOP_CONTROL=${STOP_CONTROL}"
echo "=================================================================="

cd "${GARAGE}"
python -u "${LEADERBOARD_ROOT}/leaderboard/leaderboard_evaluator_local.py" \
  --host="${HOST}" \
  --port="${PORT}" \
  --traffic-manager-port="${TM_PORT}" \
  --traffic-manager-seed="${SEED}" \
  --routes="${ROUTES}" \
  --repetitions="${REPETITIONS}" \
  --track="${CHALLENGE_TRACK_CODENAME}" \
  --checkpoint="${CHECKPOINT_ENDPOINT}" \
  --agent="${TEAM_AGENT}" \
  --agent-config="${TEAM_CONFIG}" \
  --debug=0 \
  --resume="${RESUME}"

echo
echo "[OK] results   : ${CHECKPOINT_ENDPOINT}"
echo "[OK] witness   : ${ACGNSM_LOG}"
