"""
07_finetune_yolo.py
===================
Phase 3c: Fine-tune YOLOv8n on the CARLA-labeled dataset.

Classes (5): 0=pedestrian 1=vehicle 2=traffic_light 3=cyclist 4=traffic_sign
(pedestrian detection is weak in CARLA data; at inference we ALSO use the
 pretrained COCO 'person' class as a fallback - handled in the perception script)

Optimized for RTX 4060 (8GB VRAM):
  - YOLOv8n (nano, smallest)
  - batch=16, imgsz=640
  - class weighting handled via YOLO's built-in loss

USAGE:
  python 07_finetune_yolo.py \
      --data /mnt/d/NSTM_Project/data/yolo_dataset/dataset.yaml \
      --epochs 50 --out /mnt/d/NSTM_Project/runs

OUTPUT:
  runs/finetune/weights/best.pt   <- your fine-tuned detector
  runs/finetune/results.png       <- training curves (Figure for paper)
  runs/finetune/confusion_matrix.png
"""
import argparse
from pathlib import Path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--data', default='/mnt/d/NSTM_Project/data/yolo_dataset/dataset.yaml')
    ap.add_argument('--epochs', type=int, default=50)
    ap.add_argument('--batch', type=int, default=16)
    ap.add_argument('--imgsz', type=int, default=640)
    ap.add_argument('--out', default='/mnt/d/NSTM_Project/runs')
    ap.add_argument('--model', default='yolov8n.pt')
    ap.add_argument('--resume', action='store_true')
    args = ap.parse_args()

    from ultralytics import YOLO
    import torch

    print(f"CUDA available: {torch.cuda.is_available()}")
    print(f"GPU: {torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'CPU'}")
    print(f"Dataset config: {args.data}")
    print(f"Epochs: {args.epochs}, batch: {args.batch}, imgsz: {args.imgsz}")

    # Load pretrained YOLOv8n
    model = YOLO(args.model)

    # Fine-tune
    results = model.train(
        data=args.data,
        epochs=args.epochs,
        batch=args.batch,
        imgsz=args.imgsz,
        device=0,                  # use GPU 0
        project=args.out,
        name='finetune',
        exist_ok=True,
        patience=15,               # early stop if no improvement for 15 epochs
        save=True,
        plots=True,                # generates results.png, confusion_matrix.png
        # augmentation (helps with class imbalance + robustness)
        hsv_h=0.015, hsv_s=0.7, hsv_v=0.4,
        degrees=0.0, translate=0.1, scale=0.5,
        fliplr=0.5, mosaic=1.0,
        # optimizer
        optimizer='AdamW',
        lr0=0.001, lrf=0.01,
        warmup_epochs=3,
        # class loss weighting (boost rare classes: ped, cyclist)
        cls=1.0,                   # classification loss gain
        box=7.5, dfl=1.5,
        verbose=True,
    )

    print("\n" + "="*50)
    print("Fine-tuning complete!")
    print(f"Best weights: {args.out}/finetune/weights/best.pt")
    print(f"Training curves: {args.out}/finetune/results.png")
    print(f"Confusion matrix: {args.out}/finetune/confusion_matrix.png")

    # Validate and print final metrics
    print("\nRunning final validation...")
    metrics = model.val(data=args.data, device=0)
    print(f"\nFinal mAP50: {metrics.box.map50:.3f}")
    print(f"Final mAP50-95: {metrics.box.map:.3f}")
    print("\nPer-class mAP50:")
    names = ['pedestrian', 'vehicle', 'traffic_light', 'cyclist', 'traffic_sign']
    try:
        for i, ap50 in enumerate(metrics.box.ap50):
            print(f"  {names[i]}: {ap50:.3f}")
    except Exception:
        pass

    print("\nNext: src/08_perception_inference.py (run detector + LiDAR distance)")


if __name__ == '__main__':
    main()
