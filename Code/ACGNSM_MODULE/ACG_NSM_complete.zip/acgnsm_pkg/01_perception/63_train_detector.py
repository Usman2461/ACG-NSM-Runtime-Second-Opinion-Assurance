"""
63_train_detector.py
====================
Trains the ACG-NSM perception detector on the Town10 union set.

Two properties of this dataset drive the configuration, and both were causes of
the previous detector's failure:

RECTANGULAR INPUT
    Frames are 1024x256, the geometry TransFuser++ actually presents at
    inference. Training at a square imgsz letterboxes a 4:1 image into a square
    and squashes every object into a horizontal band; the earlier detector was
    trained that way and found one object per frame on the planner's rig where
    it found several on a conventional one. We therefore train at imgsz=1024
    with rect=True so the native aspect ratio is preserved end to end.

CLASS IMBALANCE, IMPROVED BUT NOT GONE
    The original corpus had 352 pedestrians at 1.0% and they were unlearnable.
    The union set has 11423 at 6.9%, which is learnable. light_yellow remains
    thin at 1.9%: amber is transient by nature, so recall on it will trail red
    and that should be reported per class rather than hidden inside mAP.

Geometric augmentation is deliberately restrained. Vertical flip and large
rotations are wrong for driving imagery -- traffic lights do not appear upside
down -- and horizontal flip is left on only because the scene is broadly
mirror-symmetric. Colour augmentation is kept generous because the supplement
already contains weather and night variation that the model should generalise
across rather than memorise.
"""
import argparse, json, shutil
from pathlib import Path


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--data', default='/mnt/d/NSTM_Project/data/town10_union/dataset.yaml')
    p.add_argument('--model', default='yolo26n.pt')
    p.add_argument('--epochs', type=int, default=80)
    p.add_argument('--imgsz', type=int, default=1024)
    p.add_argument('--batch', type=int, default=8)
    p.add_argument('--device', default='0')
    p.add_argument('--workers', type=int, default=4)
    p.add_argument('--project', default='/mnt/d/NSTM_Project/runs')
    p.add_argument('--name', default='acgnsm_det')
    p.add_argument('--patience', type=int, default=20)
    p.add_argument('--resume', action='store_true')
    a = p.parse_args()

    from ultralytics import YOLO

    print(f'model   : {a.model}')
    print(f'data    : {a.data}')
    print(f'imgsz   : {a.imgsz} (rect=True, native 1024x256 preserved)')
    print(f'batch   : {a.batch}   epochs: {a.epochs}\n')

    m = YOLO(a.model)
    m.train(
        data=a.data,
        epochs=a.epochs,
        imgsz=a.imgsz,
        rect=True,             # keep 4:1; do not letterbox into a square
        batch=a.batch,
        device=a.device,
        workers=a.workers,
        project=a.project,
        name=a.name,
        exist_ok=True,
        resume=a.resume,
        patience=a.patience,
        seed=0,
        optimizer='auto',
        cos_lr=True,
        # colour: generous, the set spans weather and night
        hsv_h=0.015, hsv_s=0.7, hsv_v=0.5,
        # geometry: restrained, driving imagery has a fixed up direction
        degrees=0.0, shear=0.0, perspective=0.0,
        flipud=0.0, fliplr=0.5,
        translate=0.1, scale=0.4,
        mosaic=1.0, close_mosaic=15, mixup=0.0, erasing=0.3,
        val=True, plots=True,
    )

    out = Path(a.project) / a.name
    best = out / 'weights' / 'best.pt'
    print(f'\nbest weights: {best}')

    # per-class validation: aggregate mAP hides the thin classes that matter
    print('\nper-class validation')
    v = YOLO(str(best)).val(data=a.data, imgsz=a.imgsz, rect=True,
                            device=a.device, split='val', plots=False)
    names = v.names if hasattr(v, 'names') else {}
    try:
        rows = []
        for i, c in enumerate(v.box.ap_class_index):
            rows.append({'class': names.get(int(c), str(c)),
                         'precision': round(float(v.box.p[i]), 4),
                         'recall': round(float(v.box.r[i]), 4),
                         'mAP50': round(float(v.box.ap50[i]), 4),
                         'mAP50_95': round(float(v.box.ap[i]), 4)})
        print(f"{'class':>14}{'P':>9}{'R':>9}{'mAP50':>9}{'mAP50-95':>10}")
        print('-' * 51)
        for r in rows:
            print(f"{r['class']:>14}{r['precision']:>9.3f}{r['recall']:>9.3f}"
                  f"{r['mAP50']:>9.3f}{r['mAP50_95']:>10.3f}")
        summary = {'weights': str(best), 'imgsz': a.imgsz, 'rect': True,
                   'model': a.model, 'per_class': rows,
                   'mAP50': round(float(v.box.map50), 4),
                   'mAP50_95': round(float(v.box.map), 4),
                   'recall_mean': round(float(v.box.mr), 4),
                   'precision_mean': round(float(v.box.mp), 4)}
        json.dump(summary, open(out / 'per_class_metrics.json', 'w'), indent=2)
        print(f'\nwritten: {out / "per_class_metrics.json"}')
        print('\nNote: recall is the figure the conservative channel depends on.')
        print('A missed object cannot be gated, so the absence model uses')
        print('(1 - recall) as its miss rate; update it from these numbers.')
    except Exception as e:
        print(f'[warn] per-class extraction failed: {e}')


if __name__ == '__main__':
    main()
