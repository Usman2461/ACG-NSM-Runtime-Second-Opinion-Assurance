"""
05c_relabel.py
==============
Re-label EXISTING enriched frames using:
  - per-actor 3D boxes from meta.json  -> pedestrians, vehicles, cyclists
  - static map boxes from map_boxes.json -> traffic lights, signs (accurate)

No re-collection needed. Uses cam_to_world already saved in each frame.

USAGE:
  # test 8 frames
  python 05c_relabel.py --visualize --max_frames 8 --skip 40
  # full run
  python 05c_relabel.py
"""
import json, glob, os, math, argparse, random
from pathlib import Path
import numpy as np

IMG_W, IMG_H = 800, 600
MIN_BOX_PIXELS = 10
MAX_LABEL_DIST = 60.0
TL_MAX_DIST = 50.0
MAX_W_FRAC, MAX_H_FRAC = 0.5, 0.6

CLASS_NAMES = ['pedestrian', 'vehicle', 'traffic_light', 'cyclist', 'traffic_sign']
ACTOR_CLASSES = {0, 1, 3}     # from meta.json per-actor (ped, vehicle, cyclist)
MAP_CLASSES = {2, 4}          # from static map boxes (light, sign)


def corners_from_box(loc, ext, yaw, pitch=0.0, roll=0.0):
    dx, dy, dz = ext
    cl = np.array([
        [ dx,  dy,  dz],[ dx,-dy,  dz],[-dx,-dy,  dz],[-dx, dy,  dz],
        [ dx,  dy, -dz],[ dx,-dy, -dz],[-dx,-dy, -dz],[-dx, dy, -dz],
    ])
    y = math.radians(yaw); p = math.radians(pitch); r = math.radians(roll)
    cy, sy = math.cos(y), math.sin(y)
    cp, sp = math.cos(p), math.sin(p)
    cr, sr = math.cos(r), math.sin(r)
    R = np.array([[cp*cy, cy*sp*sr-sy*cr, -cy*sp*cr-sy*sr],
                  [cp*sy, sy*sp*sr+cy*cr, -sy*sp*cr+cy*sr],
                  [sp,    -cp*sr,          cp*cr]])
    return (R @ cl.T).T + np.array(loc)


def world_to_image(cw, cam_to_world, K):
    w2c = np.linalg.inv(np.array(cam_to_world))
    homo = np.hstack([cw, np.ones((cw.shape[0], 1))])
    cc = (w2c @ homo.T).T[:, :3]
    x = cc[:, 1]; y = -cc[:, 2]; z = cc[:, 0]
    in_front = z > 0.5
    zz = np.where(in_front, z, 1.0)
    pts = np.zeros((cc.shape[0], 2))
    pts[:, 0] = K[0,0]*(x/zz) + K[0,2]
    pts[:, 1] = K[1,1]*(y/zz) + K[1,2]
    return pts, in_front, z


def box_to_yolo(loc, ext, yaw, cls, cam_to_world, K, pitch=0.0, roll=0.0):
    cw = corners_from_box(loc, ext, yaw, pitch, roll)
    pts, valid, depth = world_to_image(cw, cam_to_world, K)

    if cls in MAP_CLASSES:
        if not valid.all():
            return None
    else:
        if valid.sum() < 6:
            return None

    vp = pts[valid]
    x_min, y_min = vp[:,0].min(), vp[:,1].min()
    x_max, y_max = vp[:,0].max(), vp[:,1].max()
    cx, cy = (x_min+x_max)/2, (y_min+y_max)/2
    if cx < -20 or cx > IMG_W+20 or cy < -20 or cy > IMG_H+20:
        return None
    if (x_max-x_min) > MAX_W_FRAC*IMG_W or (y_max-y_min) > MAX_H_FRAC*IMG_H:
        return None
    md = depth[valid].mean()
    if cls in MAP_CLASSES and md > TL_MAX_DIST: return None
    if md > MAX_LABEL_DIST: return None

    x_min=max(0,min(IMG_W,x_min)); x_max=max(0,min(IMG_W,x_max))
    y_min=max(0,min(IMG_H,y_min)); y_max=max(0,min(IMG_H,y_max))
    bw, bh = x_max-x_min, y_max-y_min
    if bw < MIN_BOX_PIXELS or bh < MIN_BOX_PIXELS: return None
    return (cls, (x_min+x_max)/2/IMG_W, (y_min+y_max)/2/IMG_H, bw/IMG_W, bh/IMG_H)


def process_frame(rec, calib, map_boxes, ego_loc):
    K = np.array(calib['K'])
    c2w = rec['cam_to_world']
    labels = []

    # per-actor (ped, vehicle, cyclist)
    for a in rec['actors']:
        if a['class'] not in ACTOR_CLASSES:
            continue
        ext = a['extent']
        loc = [a['loc'][0]+a['bb_loc'][0], a['loc'][1]+a['bb_loc'][1], a['loc'][2]+a['bb_loc'][2]]
        box = box_to_yolo(loc, ext, a['yaw'], a['class'], c2w, K,
                          a.get('pitch',0), a.get('roll',0))
        if box:
            c,xc,yc,w,h = box
            labels.append(f"{c} {xc:.6f} {yc:.6f} {w:.6f} {h:.6f}")

    # static map boxes (lights, signs) - filter by distance to ego first
    ex, ey = ego_loc
    for mb in map_boxes:
        mx, my = mb['loc'][0], mb['loc'][1]
        if math.hypot(mx-ex, my-ey) > TL_MAX_DIST:
            continue
        box = box_to_yolo(mb['loc'], mb['extent'], mb['yaw'], mb['class'], c2w, K,
                          mb.get('pitch',0), mb.get('roll',0))
        if box:
            c,xc,yc,w,h = box
            labels.append(f"{c} {xc:.6f} {yc:.6f} {w:.6f} {h:.6f}")

    return labels


def visualize(img_path, labels, out_path):
    import cv2
    img = cv2.imread(str(img_path))
    if img is None: return
    colors = [(0,0,255),(0,255,0),(255,0,0),(0,255,255),(255,0,255)]
    for l in labels:
        p=l.split(); c=int(p[0]); xc,yc,w,h=map(float,p[1:])
        x1=int((xc-w/2)*IMG_W); y1=int((yc-h/2)*IMG_H)
        x2=int((xc+w/2)*IMG_W); y2=int((yc+h/2)*IMG_H)
        cv2.rectangle(img,(x1,y1),(x2,y2),colors[c],2)
        cv2.putText(img,CLASS_NAMES[c],(x1,y1-4),cv2.FONT_HERSHEY_SIMPLEX,0.4,colors[c],1)
    cv2.imwrite(str(out_path), img)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--data', default='/mnt/d/NSTM_Project/data/enriched_nstm')
    ap.add_argument('--mapboxes', default='/mnt/d/NSTM_Project/data/map_boxes.json')
    ap.add_argument('--out', default='/mnt/d/NSTM_Project/data/yolo_dataset')
    ap.add_argument('--visualize', action='store_true')
    ap.add_argument('--max_frames', type=int, default=0)
    ap.add_argument('--skip', type=int, default=0)
    ap.add_argument('--val_split', type=float, default=0.2)
    args = ap.parse_args()

    map_boxes = json.load(open(args.mapboxes))['boxes']
    print(f"Loaded {len(map_boxes)} static map boxes")

    out = Path(args.out)
    for s in ['images/train','images/val','labels/train','labels/val']:
        (out/s).mkdir(parents=True, exist_ok=True)
    if args.visualize:
        (out/'viz').mkdir(parents=True, exist_ok=True)

    meta_files = sorted(glob.glob(os.path.join(args.data,'*','episode_*','meta.json')))
    print(f"Found {len(meta_files)} episodes")

    tf=tb=fi=seen=0
    cc={i:0 for i in range(5)}

    for mf in meta_files:
        ep = Path(mf).parent
        calib = json.load(open(str(ep/'calib.json')))
        for rec in json.load(open(mf)):
            ip = ep/rec['rgb']
            if not ip.exists(): continue
            labels = process_frame(rec, calib, map_boxes, (rec['ego_x'], rec['ego_y']))
            if not labels: continue
            for l in labels: cc[int(l.split()[0])] += 1
            tb += len(labels)

            if args.visualize:
                seen += 1
                if seen <= args.skip: continue
                visualize(ip, labels, out/'viz'/f"viz_{fi:05d}.jpg")
                print(f"  {ip.name}: {len(labels)} boxes")
                fi+=1; tf+=1
                if args.max_frames and tf>=args.max_frames:
                    print(f"\nDone viz: {out/'viz'}"); return
                continue

            split = 'val' if random.random()<args.val_split else 'train'
            nm=f"frame_{fi:06d}"
            import shutil
            shutil.copy(str(ip), str(out/'images'/split/f"{nm}.jpg"))
            open(str(out/'labels'/split/f"{nm}.txt"),'w').write('\n'.join(labels))
            fi+=1; tf+=1
            if tf%500==0: print(f"  {tf} frames, {tb} boxes")

    open(str(out/'dataset.yaml'),'w').write(
        f"path: {out}\ntrain: images/train\nval: images/val\nnc: 5\nnames: {CLASS_NAMES}\n")
    print(f"\n{'='*50}\nDone! Frames: {tf}  Boxes: {tb}")
    for i,n in enumerate(CLASS_NAMES): print(f"  {n}: {cc[i]}")


if __name__ == '__main__':
    main()
