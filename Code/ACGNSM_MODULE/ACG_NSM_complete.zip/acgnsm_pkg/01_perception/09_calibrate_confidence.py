"""
09_calibrate_confidence.py
==========================
Phase 3e: Calibrate detector confidence against ground truth.

Computes:
  - ECE (Expected Calibration Error) BEFORE and AFTER temperature scaling
  - Reliability diagram (paper figure)
  - The temperature T that the bridge will use to produce calibrated theta

Method:
  For each detection, determine if it's a True Positive (matches a GT object
  of the same class within IoU/distance) or False Positive. The confidence
  score should match the empirical accuracy. We bin predictions by confidence
  and compare mean confidence vs accuracy per bin = ECE.

For traffic lights / signs we use the static map boxes (always present near ego)
and for vehicles/pedestrians we use the per-frame GT flags + actor presence.

Simplified GT matching for calibration:
  - pedestrian detection is TP if Pedestrian_gt==1 (someone within 20m)
  - vehicle detection is TP if ObsDist_gt > 0 (an obstacle ahead)
  - traffic_light detection is TP if TrafficLight_gt != -1 (a light controls ego)
  This is approximate but gives a meaningful calibration signal.

USAGE:
  python 09_calibrate_confidence.py --perception /mnt/d/NSTM_Project/data/perception \
      --out /mnt/d/NSTM_Project/results
"""
import json, glob, os, argparse
from pathlib import Path
import numpy as np


def is_true_positive(det, rec):
    """Approximate TP/FP判定 using frame-level GT."""
    cls = det['class']
    if cls == 0:   # pedestrian
        return rec['Pedestrian_gt'] == 1
    if cls == 1:   # vehicle
        return rec['ObsDist_gt'] > 0
    if cls == 2:   # traffic_light
        return rec['TrafficLight_gt'] != -1
    # signs/cyclist: assume TP if conf high (no clean frame GT) - skip from ECE
    return None


def compute_ece(confidences, correctness, n_bins=10):
    """Expected Calibration Error."""
    confidences = np.array(confidences)
    correctness = np.array(correctness).astype(float)
    bins = np.linspace(0, 1, n_bins + 1)
    ece = 0.0
    bin_data = []
    for i in range(n_bins):
        lo, hi = bins[i], bins[i+1]
        mask = (confidences > lo) & (confidences <= hi)
        if mask.sum() == 0:
            bin_data.append((lo, hi, 0, 0, 0))
            continue
        bin_conf = confidences[mask].mean()
        bin_acc = correctness[mask].mean()
        bin_count = mask.sum()
        ece += (bin_count / len(confidences)) * abs(bin_conf - bin_acc)
        bin_data.append((lo, hi, bin_conf, bin_acc, bin_count))
    return ece, bin_data


def temperature_scale(confidences, correctness):
    """Find temperature T that minimizes ECE (grid search on logits)."""
    conf = np.clip(np.array(confidences), 1e-6, 1-1e-6)
    logits = np.log(conf / (1 - conf))   # inverse sigmoid
    correctness = np.array(correctness).astype(float)

    best_T, best_ece = 1.0, 999
    for T in np.linspace(0.5, 3.0, 51):
        scaled = 1 / (1 + np.exp(-logits / T))
        ece, _ = compute_ece(scaled, correctness)
        if ece < best_ece:
            best_ece, best_T = ece, T
    return best_T, best_ece


def plot_reliability(bin_data_before, bin_data_after, ece_before, ece_after, out_path):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    for ax, bin_data, ece, title in [
        (axes[0], bin_data_before, ece_before, 'Before Calibration'),
        (axes[1], bin_data_after, ece_after, 'After Temperature Scaling')]:
        centers = [(lo+hi)/2 for lo,hi,_,_,_ in bin_data]
        accs = [acc for _,_,_,acc,_ in bin_data]
        confs = [conf for _,_,conf,_,_ in bin_data]
        ax.bar(centers, accs, width=0.09, alpha=0.7, edgecolor='black', label='Accuracy')
        ax.plot([0,1],[0,1],'k--', label='Perfect calibration')
        ax.plot(centers, confs, 'ro-', markersize=4, label='Confidence', alpha=0.6)
        ax.set_xlabel('Confidence'); ax.set_ylabel('Accuracy')
        ax.set_title(f'{title}\nECE = {ece:.4f}')
        ax.legend(loc='upper left', fontsize=8)
        ax.set_xlim([0,1]); ax.set_ylim([0,1])
        ax.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(out_path, dpi=150, bbox_inches='tight')
    print(f"Saved reliability diagram: {out_path}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--perception', default='/mnt/d/NSTM_Project/data/perception')
    ap.add_argument('--out', default='/mnt/d/NSTM_Project/results')
    args = ap.parse_args()

    Path(args.out).mkdir(parents=True, exist_ok=True)

    files = glob.glob(os.path.join(args.perception, '*', '*_perception.json'))
    print(f"Loading {len(files)} perception files...")

    confidences, correctness = [], []
    per_class = {0: [[],[]], 1: [[],[]], 2: [[],[]]}

    for f in files:
        for rec in json.load(open(f)):
            for det in rec['detections']:
                tp = is_true_positive(det, rec)
                if tp is None:
                    continue
                confidences.append(det['conf'])
                correctness.append(1 if tp else 0)
                if det['class'] in per_class:
                    per_class[det['class']][0].append(det['conf'])
                    per_class[det['class']][1].append(1 if tp else 0)

    print(f"Total detections used for calibration: {len(confidences)}")
    print(f"Overall TP rate: {np.mean(correctness):.3f}")

    # ECE before
    ece_before, bins_before = compute_ece(confidences, correctness)
    print(f"\nECE BEFORE calibration: {ece_before:.4f}")

    # temperature scaling
    T, ece_after_search = temperature_scale(confidences, correctness)
    conf_arr = np.clip(np.array(confidences), 1e-6, 1-1e-6)
    logits = np.log(conf_arr/(1-conf_arr))
    calibrated = 1/(1+np.exp(-logits/T))
    ece_after, bins_after = compute_ece(calibrated, correctness)
    print(f"Optimal temperature T: {T:.3f}")
    print(f"ECE AFTER calibration: {ece_after:.4f}")

    # per-class ECE
    print("\nPer-class ECE (before):")
    names = {0:'pedestrian',1:'vehicle',2:'traffic_light'}
    for c, (confs, corrs) in per_class.items():
        if len(confs) > 20:
            ece_c, _ = compute_ece(confs, corrs)
            print(f"  {names[c]}: ECE={ece_c:.4f}, n={len(confs)}, TP_rate={np.mean(corrs):.3f}")

    # reliability diagram
    plot_reliability(bins_before, bins_after, ece_before, ece_after,
                     os.path.join(args.out, 'reliability_diagram.png'))

    # save calibration
    cal = {"temperature": float(T),
           "ece_before": float(ece_before),
           "ece_after": float(ece_after),
           "n_detections": len(confidences),
           "overall_tp_rate": float(np.mean(correctness))}
    json.dump(cal, open(os.path.join(args.out, 'confidence_calibration.json'), 'w'), indent=2)
    print(f"\nSaved calibration: {args.out}/confidence_calibration.json")
    print(f"\nThe bridge will apply: theta_calibrated = sigmoid(logit(conf) / {T:.3f})")
    print("\nNext: Phase 4 (SLAM) or Phase 5 (Risk+Legality bridge)")


if __name__ == '__main__':
    main()
