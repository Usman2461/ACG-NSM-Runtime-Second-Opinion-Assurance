"""
10_slam.py
==========
Phase 4: LiDAR odometry (ICP) + occupancy grid mapping.

For one episode:
  1. Load consecutive LiDAR scans
  2. ICP align scan[t] to scan[t-1] -> relative transform
  3. Accumulate -> estimated trajectory
  4. Build 2D occupancy grid from accumulated points
  5. Compare estimated trajectory to CARLA GT -> ATE, RPE
  6. Plot estimated vs GT trajectory (paper figure)

USAGE:
  # single episode with plot
  python 10_slam.py --episode /mnt/d/NSTM_Project/data/enriched_nstm/left_turn_signalized/episode_0000 --plot

  # evaluate across many episodes -> aggregate ATE/RPE
  python 10_slam.py --data /mnt/d/NSTM_Project/data/enriched_nstm --eval_all
"""
import json, glob, os, argparse, math
from pathlib import Path
import numpy as np
import open3d as o3d


def load_scan(path, voxel=0.3, z_min=-2.0, z_max=3.0):
    """Load LiDAR .npy -> open3d point cloud, ground-filtered & downsampled."""
    pts = np.load(path)[:, :3]
    # remove ground and very high points (keep structure: walls, cars, poles)
    mask = (pts[:, 2] > z_min) & (pts[:, 2] < z_max)
    pts = pts[mask]
    pc = o3d.geometry.PointCloud()
    pc.points = o3d.utility.Vector3dVector(pts)
    pc = pc.voxel_down_sample(voxel)
    pc.estimate_normals(search_param=o3d.geometry.KDTreeSearchParameters_Hybrid_KNN(0.5, 30)
                        if hasattr(o3d.geometry,'KDTreeSearchParameters_Hybrid_KNN')
                        else o3d.geometry.KDTreeSearchParamHybrid(radius=1.0, max_nn=30))
    return pc


def icp_pair(src, tgt, threshold=1.0, init=np.eye(4)):
    """Point-to-plane ICP. Returns 4x4 transform aligning src to tgt."""
    result = o3d.pipelines.registration.registration_icp(
        src, tgt, threshold, init,
        o3d.pipelines.registration.TransformationEstimationPointToPlane(),
        o3d.pipelines.registration.ICPConvergenceCriteria(max_iteration=50))
    return result.transformation, result.fitness, result.inlier_rmse


def run_slam(ep_dir, voxel=0.3):
    meta = json.load(open(f"{ep_dir}/meta.json"))
    n = len(meta)

    # GT trajectory (CARLA world frame)
    gt_xy = np.array([[r['ego_x'], r['ego_y']] for r in meta])
    gt_yaw = np.array([math.radians(r.get('ego_yaw', 0)) for r in meta])

    # estimated trajectory via ICP accumulation
    est_xy = [np.array([0.0, 0.0])]      # start at origin (we align frames later)
    est_yaw = [0.0]
    global_T = np.eye(4)

    prev = load_scan(f"{ep_dir}/{meta[0]['lidar']}", voxel)

    for t in range(1, n):
        cur = load_scan(f"{ep_dir}/{meta[t]['lidar']}", voxel)
        # ICP: align current to previous
        T, fitness, rmse = icp_pair(cur, prev)
        # accumulate
        global_T = global_T @ T
        # extract x,y and yaw from global transform
        x, y = global_T[0, 3], global_T[1, 3]
        yaw = math.atan2(global_T[1, 0], global_T[0, 0])
        est_xy.append(np.array([x, y]))
        est_yaw.append(yaw)
        prev = cur

    est_xy = np.array(est_xy)
    est_yaw = np.array(est_yaw)

    # ---- align estimated to GT frame (Umeyama: rotation+translation) ----
    # estimated starts at origin; rotate/translate to best-match GT for fair ATE
    est_aligned = align_trajectories(est_xy, gt_xy)

    # ---- ATE: RMSE of position error ----
    errors = np.linalg.norm(est_aligned - gt_xy, axis=1)
    ate_rmse = float(np.sqrt(np.mean(errors**2)))
    ate_mean = float(np.mean(errors))

    # ---- RPE: relative pose error over 1-step ----
    rpe_list = []
    for t in range(1, n):
        gt_step = np.linalg.norm(gt_xy[t] - gt_xy[t-1])
        est_step = np.linalg.norm(est_aligned[t] - est_aligned[t-1])
        rpe_list.append(abs(gt_step - est_step))
    rpe_mean = float(np.mean(rpe_list))

    return {
        'gt_xy': gt_xy, 'est_xy': est_aligned,
        'ate_rmse': ate_rmse, 'ate_mean': ate_mean, 'rpe_mean': rpe_mean,
        'path_length': float(np.sum([np.linalg.norm(gt_xy[i+1]-gt_xy[i]) for i in range(n-1)]))
    }


def align_trajectories(est, gt):
    """Umeyama alignment (2D): find R,t,scale aligning est to gt."""
    mu_est = est.mean(axis=0)
    mu_gt = gt.mean(axis=0)
    est_c = est - mu_est
    gt_c = gt - mu_gt
    H = est_c.T @ gt_c
    U, S, Vt = np.linalg.svd(H)
    R = Vt.T @ U.T
    if np.linalg.det(R) < 0:
        Vt[-1, :] *= -1
        R = Vt.T @ U.T
    aligned = (R @ est_c.T).T + mu_gt
    return aligned


def build_occupancy_grid(ep_dir, est_xy, meta, res=0.5, size=100):
    """Build 2D occupancy grid from LiDAR accumulated along trajectory."""
    grid = np.zeros((size*2, size*2), dtype=np.float32)
    for t in range(0, len(meta), 5):   # every 5th frame for speed
        pts = np.load(f"{ep_dir}/{meta[t]['lidar']}")[:, :3]
        mask = (pts[:, 2] > -1.5) & (pts[:, 2] < 2.5)
        pts = pts[mask]
        # to grid cells (ego-centric)
        gx = (pts[:, 0]/res + size).astype(int)
        gy = (pts[:, 1]/res + size).astype(int)
        valid = (gx >= 0) & (gx < size*2) & (gy >= 0) & (gy < size*2)
        grid[gy[valid], gx[valid]] += 1
    return grid


def plot_results(res, occ_grid, out_path):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    # trajectory
    ax = axes[0]
    gt = res['gt_xy']; est = res['est_xy']
    ax.plot(gt[:, 0], gt[:, 1], 'g-', linewidth=2, label='Ground truth')
    ax.plot(est[:, 0], est[:, 1], 'r--', linewidth=2, label='LiDAR odometry')
    ax.scatter(gt[0, 0], gt[0, 1], c='blue', s=80, marker='o', label='Start', zorder=5)
    ax.set_xlabel('X (m)'); ax.set_ylabel('Y (m)')
    ax.set_title(f"Trajectory\nATE RMSE = {res['ate_rmse']:.2f}m, RPE = {res['rpe_mean']:.3f}m")
    ax.legend(); ax.axis('equal'); ax.grid(alpha=0.3)
    # occupancy grid
    ax = axes[1]
    ax.imshow(np.log1p(occ_grid), cmap='viridis', origin='lower')
    ax.set_title('Occupancy Grid (log density)')
    ax.set_xlabel('grid X'); ax.set_ylabel('grid Y')
    plt.tight_layout()
    plt.savefig(out_path, dpi=150, bbox_inches='tight')
    print(f"Saved: {out_path}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--episode', default=None)
    ap.add_argument('--data', default='/mnt/d/NSTM_Project/data/enriched_nstm')
    ap.add_argument('--eval_all', action='store_true')
    ap.add_argument('--plot', action='store_true')
    ap.add_argument('--out', default='/mnt/d/NSTM_Project/results')
    ap.add_argument('--voxel', type=float, default=0.3)
    args = ap.parse_args()
    Path(args.out).mkdir(parents=True, exist_ok=True)

    if args.episode:
        print(f"Running SLAM on {args.episode}")
        res = run_slam(args.episode, args.voxel)
        print(f"\nPath length: {res['path_length']:.1f}m")
        print(f"ATE RMSE:    {res['ate_rmse']:.3f}m")
        print(f"ATE mean:    {res['ate_mean']:.3f}m")
        print(f"RPE mean:    {res['rpe_mean']:.3f}m")
        if args.plot:
            meta = json.load(open(f"{args.episode}/meta.json"))
            occ = build_occupancy_grid(args.episode, res['est_xy'], meta)
            plot_results(res, occ, os.path.join(args.out, 'slam_result.png'))

    elif args.eval_all:
        # evaluate a sample of episodes per scenario
        scenarios = ['left_turn_signalized', 'highway_cutin', 'pedestrian_crossing', 'adverse_weather']
        all_ate, all_rpe = [], []
        by_scenario = {}
        for sc in scenarios:
            eps = sorted(glob.glob(f"{args.data}/{sc}/episode_*"))[:5]
            ates, rpes = [], []
            for ep in eps:
                try:
                    res = run_slam(ep, args.voxel)
                    ates.append(res['ate_rmse']); rpes.append(res['rpe_mean'])
                    all_ate.append(res['ate_rmse']); all_rpe.append(res['rpe_mean'])
                except Exception as e:
                    print(f"  {ep}: ERROR {e}")
            if ates:
                by_scenario[sc] = (np.mean(ates), np.mean(rpes))
                print(f"{sc}: ATE={np.mean(ates):.3f}m  RPE={np.mean(rpes):.3f}m  (n={len(ates)})")
        print(f"\n=== OVERALL ===")
        print(f"Mean ATE RMSE: {np.mean(all_ate):.3f}m")
        print(f"Mean RPE:      {np.mean(all_rpe):.3f}m")
        json.dump({'overall_ate': float(np.mean(all_ate)),
                   'overall_rpe': float(np.mean(all_rpe)),
                   'by_scenario': {k: [float(v[0]), float(v[1])] for k,v in by_scenario.items()}},
                  open(os.path.join(args.out, 'slam_metrics.json'), 'w'), indent=2)
        print(f"Saved: {args.out}/slam_metrics.json")


if __name__ == '__main__':
    main()
