"""
55_check_detector.py
====================
Grabs one frame from CARLA and asks whether the detector sees anything at all.

The first observe-only run returned zero detections on all 12544 ticks, which
would make any absence model meaningless: a blind detector is confidently blind.
This isolates the cause -- wrong colour order, wrong dtype, wrong scale, or a
genuinely empty scene -- before more GPU time is spent.

    python src/55_check_detector.py --host 192.168.144.1
"""
import argparse, json, sys, importlib.util
from pathlib import Path
import numpy as np

SRC = Path(__file__).resolve().parent


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--host', default='192.168.144.1')
    ap.add_argument('--port', type=int, default=2000)
    ap.add_argument('--weights',
                    default='/mnt/d/NSTM_Project/runs/finetune/weights/best.pt')
    ap.add_argument('--out', default='/mnt/d/NSTM_Project/results/detcheck')
    a = ap.parse_args()
    Path(a.out).mkdir(parents=True, exist_ok=True)

    import carla
    cl = carla.Client(a.host, a.port); cl.set_timeout(20.0)
    world = cl.get_world()
    print('map:', world.get_map().name)

    bp = world.get_blueprint_library()
    veh = None
    for v in world.get_actors().filter('vehicle.*'):
        veh = v; break
    spawned = False
    if veh is None:
        sp = world.get_map().get_spawn_points()[0]
        veh = world.spawn_actor(bp.filter('vehicle.*')[0], sp)
        spawned = True
        print('spawned a probe vehicle')
    else:
        print('using existing vehicle', veh.type_id)

    cam_bp = bp.find('sensor.camera.rgb')
    cam_bp.set_attribute('image_size_x', '1024')
    cam_bp.set_attribute('image_size_y', '256')
    cam_bp.set_attribute('fov', '110')
    tf = carla.Transform(carla.Location(x=-1.5, z=2.0))
    cam = world.spawn_actor(cam_bp, tf, attach_to=veh)

    got = {}
    cam.listen(lambda img: got.setdefault('img', img))
    for _ in range(200):
        world.wait_for_tick()
        if 'img' in got:
            break
    cam.stop(); cam.destroy()
    if spawned:
        veh.destroy()

    if 'img' not in got:
        print('[FAIL] no camera frame received'); return

    img = got['img']
    arr = np.frombuffer(img.raw_data, dtype=np.uint8).reshape(
        (img.height, img.width, 4))
    print(f'frame {img.width}x{img.height}  mean luminance '
          f'{arr[..., :3].mean():.1f}')

    ac = importlib.util.spec_from_file_location(
        'ac', SRC / '54_absence_confidence.py')
    m = importlib.util.module_from_spec(ac); ac.loader.exec_module(m)

    rep = m.detector_selftest(a.weights, arr, save_to=f'{a.out}/det')
    print(json.dumps(rep, indent=2))

    best = max(rep['variants'].items(),
               key=lambda kv: kv[1].get('n', -1))
    print(f"\nbest variant: {best[0]}  detections: {best[1].get('n')}")
    if best[1].get('n', 0) == 0:
        print('[PROBLEM] no detections in any colour order -- the detector is '
              'not seeing this scene. Check class ids and the training domain.')
    else:
        print('[OK] detector works; use this colour order in the channel.')
    json.dump(rep, open(f'{a.out}/report.json', 'w'), indent=2)


if __name__ == '__main__':
    main()
