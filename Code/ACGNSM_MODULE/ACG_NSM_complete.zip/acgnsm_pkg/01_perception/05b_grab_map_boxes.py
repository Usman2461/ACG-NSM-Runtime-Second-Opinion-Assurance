"""
05b_grab_map_boxes.py
=====================
Grab static traffic light + sign bounding boxes from the CARLA map ONCE.
These are baked into the map geometry (accurate signal-head positions).
Saves them to a JSON so we can re-label existing frames without re-collecting.

USAGE:
  python 05b_grab_map_boxes.py --host 192.168.144.1 \
      --out /mnt/d/NSTM_Project/data/map_boxes.json
"""
import carla, json, argparse


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--host', default='192.168.144.1')
    ap.add_argument('--port', type=int, default=2000)
    ap.add_argument('--out', default='/mnt/d/NSTM_Project/data/map_boxes.json')
    args = ap.parse_args()

    c = carla.Client(args.host, args.port)
    c.set_timeout(10.0)
    world = c.get_world()
    print("Map:", world.get_map().name)

    def grab(label, cls_id):
        bbs = world.get_level_bbs(label)
        out = []
        for bb in bbs:
            out.append({
                "class": cls_id,
                "loc": [bb.location.x, bb.location.y, bb.location.z],
                "extent": [bb.extent.x, bb.extent.y, bb.extent.z],
                "yaw": bb.rotation.yaw,
                "pitch": bb.rotation.pitch,
                "roll": bb.rotation.roll,
            })
        return out

    boxes = []
    tls = grab(carla.CityObjectLabel.TrafficLight, 2)
    signs = grab(carla.CityObjectLabel.TrafficSigns, 4)
    boxes.extend(tls)
    boxes.extend(signs)

    json.dump({"map": str(world.get_map().name), "boxes": boxes},
              open(args.out, 'w'), indent=2)
    print(f"Saved {len(tls)} traffic lights + {len(signs)} signs = {len(boxes)} boxes")
    print(f"-> {args.out}")


if __name__ == '__main__':
    main()
