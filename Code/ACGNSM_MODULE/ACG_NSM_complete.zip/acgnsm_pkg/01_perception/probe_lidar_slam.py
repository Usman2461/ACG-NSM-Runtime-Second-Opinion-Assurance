"""Probe: check LiDAR data is suitable for ICP odometry."""
import json, glob, numpy as np
from pathlib import Path

# pick one episode
ep = sorted(glob.glob('/mnt/d/NSTM_Project/data/enriched_nstm/highway_cutin/episode_*'))[0]
print("Episode:", ep)
meta = json.load(open(f"{ep}/meta.json"))

# check a few lidar scans
print("\n=== LiDAR scan properties ===")
for tick in [0, 50, 100]:
    pts = np.load(f"{ep}/lidar/{tick:03d}.npy")
    print(f"tick {tick}: {pts.shape[0]} points, "
          f"x range [{pts[:,0].min():.1f},{pts[:,0].max():.1f}], "
          f"z range [{pts[:,2].min():.1f},{pts[:,2].max():.1f}]")

# check GT ego poses are available for evaluation
print("\n=== GT ego trajectory (for ATE/RPE evaluation) ===")
xs = [r['ego_x'] for r in meta]
ys = [r['ego_y'] for r in meta]
yaws = [r.get('ego_yaw', 0) for r in meta]
print(f"Ego moved from ({xs[0]:.1f},{ys[0]:.1f}) to ({xs[-1]:.1f},{ys[-1]:.1f})")
total_dist = sum(np.hypot(xs[i+1]-xs[i], ys[i+1]-ys[i]) for i in range(len(xs)-1))
print(f"Total path length: {total_dist:.1f}m over {len(meta)} ticks")
print(f"Yaw range: [{min(yaws):.0f}, {max(yaws):.0f}] degrees")

# check open3d available
try:
    import open3d as o3d
    print(f"\n[OK] open3d {o3d.__version__} available for ICP")
except ImportError:
    print("\n[NEED] pip install open3d")
