"""
05_autolabel.py  (v3 - strict box filtering)
===============
FIXES in v3:
  - reject boxes wider than MAX_W_FRAC OR taller than MAX_H_FRAC (kills wide strips)
  - require ALL corners in front of camera for small fixed objects (lights/signs)
  - require traffic light / sign within 40m to be labeled
  - tighter on-screen center requirement
"""

import json, glob, os, math, argparse, random
from pathlib import Path
import numpy as np

IMG_W = 800
IMG_H = 600
MIN_BOX_PIXELS = 10
MAX_LABEL_DIST = 60.0
MAX_W_FRAC = 0.5     # reject box wider than 50% of image width
MAX_H_FRAC = 0.6     # reject box taller than 60% of image height
TL_MAX_DIST = 45.0   # only label traffic lights/signs closer than this

SMALL_FIXED = {2: (0.3, 0.5, 0.9),    # traffic_light
               4: (0.3, 0.3, 0.5)}    # traffic_sign
NEED_ALL_CORNERS = {2, 4}             # these must have all 8 corners in front

CLASS_NAMES = ['pedestrian', 'vehicle', 'traffic_light', 'cyclist', 'traffic_sign']


def bbox_3d_corners(actor):
    loc = np.array(actor['loc'])
    cls = actor['class']
    if cls in SMALL_FIXED:
        ext = np.array(SMALL_FIXED[cls]); bb_loc = np.zeros(3)
        yaw = pitch = roll = 0.0
    else:
        ext = np.array(actor['extent']); bb_loc = np.array(actor['bb_loc'])
        yaw = math.radians(actor['yaw'])
        pitch = math.radians(actor.get('pitch', 0.0))
        roll = math.radians(actor.get('roll', 0.0))
    dx, dy, dz = ext
    cl = np.array([
        [ dx,  dy,  dz],[ dx,-dy,  dz],[-dx,-dy,  dz],[-dx, dy,  dz],
        [ dx,  dy, -dz],[ dx,-dy, -dz],[-dx,-dy, -dz],[-dx, dy, -dz],
    ]) + bb_loc
    cy, sy = math.cos(yaw), math.sin(yaw)
    cp, sp = math.cos(pitch), math.sin(pitch)
    cr, sr = math.cos(roll), math.sin(roll)
    R = np.array([[cp*cy, cy*sp*sr-sy*cr, -cy*sp*cr-sy*sr],
                  [cp*sy, sy*sp*sr+cy*cr, -sy*sp*cr+cy*sr],
                  [sp,    -cp*sr,          cp*cr]])
    return (R @ cl.T).T + loc


def world_to_camera(cw, cam_to_world):
    w2c = np.linalg.inv(np.array(cam_to_world))
    homo = np.hstack([cw, np.ones((cw.shape[0], 1))])
    return (w2c @ homo.T).T[:, :3]


def camera_to_image(cc, K):
    x = cc[:, 1]; y = -cc[:, 2]; z = cc[:, 0]
    in_front = z > 0.5
    zz = np.where(in_front, z, 1.0)
    pts = np.zeros((cc.shape[0], 2))
    pts[:, 0] = K[0,0]*(x/zz) + K[0,2]
    pts[:, 1] = K[1,1]*(y/zz) + K[1,2]
    return pts, in_front, z


def project_actor(actor, cam_to_world, K):
    cls = actor['class']
    cw = bbox_3d_corners(actor)
    cc = world_to_camera(cw, cam_to_world)
    pts, valid, depth = camera_to_image(cc, K)

    # small fixed objects: require ALL corners in front (avoids wide strips)
    if cls in NEED_ALL_CORNERS:
        if not valid.all():
            return None
    else:
        if valid.sum() < 6:   # vehicles/peds: most corners in front
            return None

    vp = pts[valid]
    x_min, y_min = vp[:,0].min(), vp[:,1].min()
    x_max, y_max = vp[:,0].max(), vp[:,1].max()

    # box must be substantially on-screen
    cx, cy = (x_min+x_max)/2, (y_min+y_max)/2
    if cx < -20 or cx > IMG_W+20 or cy < -20 or cy > IMG_H+20:
        return None

    # raw (pre-clip) size check kills wide strips BEFORE clipping
    raw_w = x_max - x_min
    raw_h = y_max - y_min
    if raw_w > MAX_W_FRAC * IMG_W or raw_h > MAX_H_FRAC * IMG_H:
        return None

    # distance gate for lights/signs
    md = depth[valid].mean()
    if cls in SMALL_FIXED and md > TL_MAX_DIST:
        return None
    if md > MAX_LABEL_DIST:
        return None

    # clip to image
    x_min = max(0, min(IMG_W, x_min)); x_max = max(0, min(IMG_W, x_max))
    y_min = max(0, min(IMG_H, y_min)); y_max = max(0, min(IMG_H, y_max))
    bw = x_max - x_min; bh = y_max - y_min
    if bw < MIN_BOX_PIXELS or bh < MIN_BOX_PIXELS:
        return None

    xc = (x_min+x_max)/2.0/IMG_W; yc = (y_min+y_max)/2.0/IMG_H
    return (cls, xc, yc, bw/IMG_W, bh/IMG_H)


def process_frame(rec, calib):
    K = np.array(calib['K'])
    labels = []
    for a in rec['actors']:
        box = project_actor(a, rec['cam_to_world'], K)
        if box:
            c, xc, yc, w, h = box
            labels.append(f"{c} {xc:.6f} {yc:.6f} {w:.6f} {h:.6f}")
    return labels


def visualize_frame(img_path, labels, out_path):
    import cv2
    img = cv2.imread(str(img_path))
    if img is None: return
    colors = [(0,0,255),(0,255,0),(255,0,0),(0,255,255),(255,0,255)]
    for line in labels:
        p = line.split(); c = int(p[0]); xc,yc,w,h = map(float, p[1:])
        x1=int((xc-w/2)*IMG_W); y1=int((yc-h/2)*IMG_H)
        x2=int((xc+w/2)*IMG_W); y2=int((yc+h/2)*IMG_H)
        cv2.rectangle(img,(x1,y1),(x2,y2),colors[c],2)
        cv2.putText(img,CLASS_NAMES[c],(x1,y1-4),cv2.FONT_HERSHEY_SIMPLEX,0.4,colors[c],1)
    cv2.imwrite(str(out_path), img)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--data', default='/mnt/d/NSTM_Project/data/enriched_nstm')
    ap.add_argument('--out', default='/mnt/d/NSTM_Project/data/yolo_dataset')
    ap.add_argument('--visualize', action='store_true')
    ap.add_argument('--max_frames', type=int, default=0)
    ap.add_argument('--val_split', type=float, default=0.2)
    ap.add_argument('--skip', type=int, default=0, help='skip first N labeled frames in viz')
    args = ap.parse_args()

    out = Path(args.out)
    for s in ['images/train','images/val','labels/train','labels/val']:
        (out/s).mkdir(parents=True, exist_ok=True)
    if args.visualize:
        (out/'viz').mkdir(parents=True, exist_ok=True)

    meta_files = sorted(glob.glob(os.path.join(args.data,'*','episode_*','meta.json')))
    print(f"Found {len(meta_files)} episodes")

    tf = tb = fi = 0
    cc = {i:0 for i in range(5)}
    seen = 0

    for mf in meta_files:
        ep = Path(mf).parent
        calib = json.load(open(str(ep/'calib.json')))
        for rec in json.load(open(mf)):
            ip = ep/rec['rgb']
            if not ip.exists(): continue
            labels = process_frame(rec, calib)
            if not labels: continue
            for l in labels: cc[int(l.split()[0])] += 1
            tb += len(labels)

            if args.visualize:
                seen += 1
                if seen <= args.skip: continue
                vp = out/'viz'/f"viz_{fi:05d}.jpg"
                visualize_frame(ip, labels, vp)
                print(f"  {ip.name}: {len(labels)} boxes")
                fi += 1; tf += 1
                if args.max_frames and tf >= args.max_frames:
                    print(f"\nVisualized {tf} frames to {out/'viz'}")
                    return
                continue

            split = 'val' if random.random() < args.val_split else 'train'
            nm = f"frame_{fi:06d}"
            import shutil
            shutil.copy(str(ip), str(out/'images'/split/f"{nm}.jpg"))
            with open(str(out/'labels'/split/f"{nm}.txt"),'w') as f:
                f.write('\n'.join(labels))
            fi += 1; tf += 1
            if tf % 500 == 0:
                print(f"  {tf} frames, {tb} boxes")

    with open(str(out/'dataset.yaml'),'w') as f:
        f.write(f"path: {out}\ntrain: images/train\nval: images/val\nnc: 5\nnames: {CLASS_NAMES}\n")
    print(f"\n{'='*50}\nDone! Frames: {tf}  Boxes: {tb}")
    for i,n in enumerate(CLASS_NAMES): print(f"  {n}: {cc[i]}")


if __name__ == '__main__':
    main()
