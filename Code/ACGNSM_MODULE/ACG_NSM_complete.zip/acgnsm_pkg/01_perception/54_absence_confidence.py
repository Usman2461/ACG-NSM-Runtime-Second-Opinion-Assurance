"""
54_absence_confidence.py
========================
Evidence-based confidence in ABSENCE, plus a diagnostic for verifying the
detector is actually seeing the scene.

The problem this solves
-----------------------
A detector scores the objects it returns and is silent about the objects it
misses. Treating "no detection" as a fixed-confidence assertion of absence is
therefore unsound: the same silence means something quite different in a clear,
well-lit, densely-sampled scene than it does in fog at long range. In the first
observe-only run this defect was immediate and total -- absence was asserted at
a constant 0.617 on every one of 12544 ticks, which fell below the gate
threshold, promoted every non-detection to an asserted hazard, and drove the
conservative channel to demand a full stop 100% of the time.

The formulation
---------------
Let q in (0,1] be the OBSERVATION QUALITY of the region a hazard would occupy,
estimated from measurable sensor evidence rather than assumed. The detector's
miss rate degrades as observation quality falls:

    m(q) = clamp(m0 / max(q, q_min), m0, 1)

with m0 = 1 - recall, the miss rate measured on the held-out split. Then, by
Bayes, the posterior probability that the hazard is genuinely absent given that
nothing was detected is

                      (1 - f) (1 - pi)
    c_absent = ---------------------------------
                (1 - f)(1 - pi) + m(q) pi

where f is the detector's false-positive rate and pi the prior probability the
hazard is present in this scene type. Well-observed scenes therefore yield a
confident absence; poorly-observed scenes yield a weak one, which the gate then
treats as distrust and the graded fail-safe converts into caution.

Observation quality is estimated from three signals that are available every
tick and require no extra sensors:

    coverage   LiDAR return density in the forward corridor
    visibility image luminance and contrast
    range      furthest LiDAR return, which collapses in fog and heavy rain
"""
import math
import numpy as np

# Detector reliability, PER CLASS. A single global recall is wrong here: the
# classes differ by an order of magnitude in training support, so a detector
# that finds vehicles almost always may still miss amber lights routinely, and
# collapsing that into one number makes the absence posterior confidently wrong
# exactly where it matters most.
#
# These are placeholders until the retrained detector is validated. Populate
# them from runs/acgnsm_det/per_class_metrics.json -- the loader below does it
# automatically when the file is present.
RECALL_BY_CLASS = {
    'pedestrian':    0.912,
    'oncoming':      0.912,   # the vehicle class
    'traffic_light': 0.912,
}
PRECISION_BY_CLASS = {
    'pedestrian':    0.973,
    'oncoming':      0.973,
    'traffic_light': 0.973,
}

# kept for callers that still expect a scalar
RECALL = 0.912
MISS_RATE_0 = 1.0 - RECALL
FALSE_POS_RATE = 0.027

# prior that the hazard is present, by scene type. Deliberately generous:
# under-stating the prior makes absence look more certain than it is.
PRIOR = {'pedestrian': 0.30, 'oncoming': 0.45, 'traffic_light': 0.35}

# map detector class names onto the scene fields the gate reasons about
_FIELD_OF = {'pedestrian': 'pedestrian', 'vehicle': 'oncoming',
             'light_red': 'traffic_light', 'light_yellow': 'traffic_light',
             'light_green': 'traffic_light'}


def load_detector_metrics(path):
    """Adopt measured per-class recall and precision from a validation run.

    For traffic lights the WORST of the three colour classes is taken, not the
    mean: amber is the thinnest class and the one the dilemma-zone logic
    depends on, so averaging it away would overstate how much a non-detection
    tells us about the signal.
    """
    import json as _json
    d = _json.load(open(path))
    rec, prec = {}, {}
    for row in d.get('per_class', []):
        f = _FIELD_OF.get(row['class'])
        if f is None:
            continue
        r, p = float(row['recall']), float(row['precision'])
        rec[f] = min(rec.get(f, 1.0), r)
        prec[f] = min(prec.get(f, 1.0), p)
    RECALL_BY_CLASS.update(rec)
    PRECISION_BY_CLASS.update(prec)
    return {'recall': dict(RECALL_BY_CLASS), 'precision': dict(PRECISION_BY_CLASS)}


# --------------------------------------------------------------- observation
def coverage_quality(lidar, x_min=1.5, x_max=45.0, y_half=6.0):
    """Fraction of the forward corridor that returned LiDAR points."""
    if lidar is None or len(lidar) == 0:
        return 0.05
    p = np.asarray(lidar)[:, :3]
    m = (p[:, 0] > x_min) & (p[:, 0] < x_max) & (np.abs(p[:, 1]) < y_half)
    n = int(m.sum())
    # ~2000 returns in the corridor is a well-sampled scene
    return float(min(1.0, 0.05 + n / 2000.0))


def visibility_quality(rgb):
    """Luminance and contrast of the image, normalised to (0,1]."""
    if rgb is None:
        return 0.30
    a = np.asarray(rgb)
    if a.ndim == 3:
        a = a[:, :, :3].mean(axis=2)
    lum = float(a.mean()) / 255.0
    con = float(a.std()) / 64.0
    # too dark or washed out both reduce quality
    q_lum = 1.0 - abs(lum - 0.45) / 0.45
    return float(max(0.05, min(1.0, 0.5 * max(0.0, q_lum) + 0.5 * min(1.0, con))))


def range_quality(lidar, nominal=50.0):
    """Furthest LiDAR return, relative to the sensor's nominal range."""
    if lidar is None or len(lidar) == 0:
        return 0.05
    p = np.asarray(lidar)[:, :3]
    fwd = p[p[:, 0] > 1.0]
    if fwd.shape[0] < 10:
        return 0.10
    r = float(np.percentile(np.linalg.norm(fwd[:, :2], axis=1), 95))
    return float(max(0.05, min(1.0, r / nominal)))


def observation_quality(rgb, lidar):
    """Combine the three signals. Geometric mean: any one being poor matters."""
    qc = coverage_quality(lidar)
    qv = visibility_quality(rgb)
    qr = range_quality(lidar)
    q = (qc * qv * qr) ** (1.0 / 3.0)
    return float(max(0.02, min(1.0, q))), {'coverage': round(qc, 3),
                                           'visibility': round(qv, 3),
                                           'range': round(qr, 3)}


# ----------------------------------------------------------------- posterior
def absence_confidence(field, q, m0=None, f=None, q_min=0.05):
    """P(hazard absent | nothing detected), given observation quality q."""
    pi = PRIOR.get(field, 0.30)
    if m0 is None:
        m0 = 1.0 - RECALL_BY_CLASS.get(field, RECALL)
    if f is None:
        f = 1.0 - PRECISION_BY_CLASS.get(field, 1.0 - FALSE_POS_RATE)
    m = min(1.0, max(m0, m0 / max(q, q_min)))
    num = (1.0 - f) * (1.0 - pi)
    den = num + m * pi
    return float(num / den) if den > 0 else 0.5


# ---------------------------------------------------------------- diagnostic
def detector_selftest(weights, rgb, imgsz=640, conf=0.05, device='cuda',
                      save_to=None):
    """Verify the detector actually sees the scene. Returns a report dict."""
    from ultralytics import YOLO
    y = YOLO(str(weights))
    a = np.asarray(rgb)
    variants = {'as_given': a}
    if a.ndim == 3 and a.shape[2] == 4:
        variants['bgra_to_rgb'] = a[:, :, :3][:, :, ::-1]
        variants['bgra_drop_alpha'] = a[:, :, :3]
    elif a.ndim == 3 and a.shape[2] == 3:
        variants['channel_swapped'] = a[:, :, ::-1]

    report = {'image_shape': list(a.shape),
              'dtype': str(a.dtype),
              'mean_luminance': round(float(a[..., :3].mean()), 2),
              'variants': {}}
    for name, img in variants.items():
        try:
            r = y.predict(np.ascontiguousarray(img), imgsz=imgsz, conf=conf,
                          device=device, verbose=False)[0]
            dets = [{'cls': int(b.cls.item()), 'conf': round(float(b.conf.item()), 3)}
                    for b in r.boxes]
            report['variants'][name] = {'n': len(dets), 'top': dets[:5]}
            if save_to and len(dets):
                r.save(filename=f'{save_to}_{name}.jpg')
        except Exception as e:
            report['variants'][name] = {'error': str(e)[:120]}
    return report


if __name__ == '__main__':
    print("Absence confidence as observation quality degrades\n")
    print(f"  measured recall {RECALL}  ->  nominal miss rate {MISS_RATE_0:.3f}\n")
    print(f"{'quality':>9}{'miss rate':>11}{'pedestrian':>12}{'oncoming':>10}")
    print('-' * 44)
    for q in (1.0, 0.8, 0.6, 0.4, 0.25, 0.15, 0.08):
        m = min(1.0, max(MISS_RATE_0, MISS_RATE_0 / q))
        print(f"{q:>9.2f}{m:>11.3f}"
              f"{absence_confidence('pedestrian', q):>12.3f}"
              f"{absence_confidence('oncoming', q):>10.3f}")
    print("\nAgainst theta_ped = 0.88: a well-observed scene clears the gate,")
    print("a poorly-observed one does not, which is the intended behaviour.")
    print("\nThe previous constant was 0.617 regardless of conditions, which")
    print("failed the gate always and asserted a hazard on every tick.")
