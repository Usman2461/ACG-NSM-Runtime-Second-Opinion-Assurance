"""
08_perception_inference.py
==========================
Phase 3d: Run fine-tuned detector + LiDAR distance fusion on frames.

For each frame:
  1. Run YOLO detector -> 2D boxes (class, conf, x1y1x2y2)
  2. Also run pretrained YOLO 'person' class for pedestrian fallback
  3. Project LiDAR points into camera image
  4. For each detection box, find LiDAR points inside it -> distance
  5. Output structured scene: list of detected objects with class, conf, distance

LiDAR is in the LiDAR sensor frame (x-fwd, y-right, z-up at z=2.4).
Camera is at x=1.5, z=2.0. We transform LiDAR -> camera -> image.

USAGE:
  # test on one episode
  python 08_perception_inference.py --model /mnt/d/NSTM_Project/runs/finetune/weights/best.pt \
      --episode /mnt/d/NSTM_Project/data/enriched_nstm/left_turn_signalized/episode_0000 \
      --visualize

  # process all enriched episodes -> perception output JSON per episode
  python 08_perception_inference.py --model .../best.pt \
      --data /mnt/d/NSTM_Project/data/enriched_nstm --out /mnt/d/NSTM_Project/data/perception
"""
import json, glob, os, math, argparse
from pathlib import Path
import numpy as np

IMG_W, IMG_H, FOV = 800, 600, 90.0
CLASS_NAMES = ['pedestrian', 'vehicle', 'traffic_light', 'cyclist', 'traffic_sign']

# sensor mounting (from collection script)
CAM_X, CAM_Z = 1.5, 2.0
LIDAR_Z = 2.4

# distance calibration (fitted on 1317 GT pairs): corrected = a*raw + b
DIST_CAL_A = 0.900
DIST_CAL_B = 5.060


def build_K():
    f = IMG_W / (2.0 * math.tan(FOV * math.pi / 360.0))
    return np.array([[f,0,IMG_W/2.0],[0,f,IMG_H/2.0],[0,0,1.0]])


def lidar_to_camera(points):
    """
    Transform LiDAR points (x-fwd,y-right,z-up at LIDAR_Z) into the
    camera frame (x-fwd,y-right,z-up at CAM_Z, offset x=CAM_X).
    Both share orientation; only translation differs.
    """
    pts = points[:, :3].copy()
    # translate from lidar mount to camera mount
    pts[:, 0] -= CAM_X      # camera is 1.5m forward of lidar... actually
    pts[:, 2] += (LIDAR_Z - CAM_Z)   # lidar is higher by 0.4m
    return pts


def project_to_image(cam_pts, K):
    """Project camera-frame points to image. Returns u,v,depth, valid mask."""
    x = cam_pts[:, 1]   # right
    y = -cam_pts[:, 2]  # down
    z = cam_pts[:, 0]   # forward (depth)
    valid = z > 0.5
    zz = np.where(valid, z, 1.0)
    u = K[0,0] * (x / zz) + K[0,2]
    v = K[1,1] * (y / zz) + K[1,2]
    return u, v, z, valid


def distance_in_box(u, v, depth, valid, box, shrink=0.6):
    """
    Distance to object via the DOMINANT depth cluster inside the box.

    A 2D box around a vehicle also captures road points in front/behind it.
    We (1) shrink the box to its center region (less road leakage),
    (2) histogram the depths and take the densest bin (the vehicle surface),
    (3) add half vehicle length so it matches GT center-distance + cam offset.
    """
    x1, y1, x2, y2 = box
    # shrink box toward center to reduce road/background leakage
    cx, cy = (x1+x2)/2, (y1+y2)/2
    hw, hh = (x2-x1)/2*shrink, (y2-y1)/2*shrink
    sx1, sx2, sy1, sy2 = cx-hw, cx+hw, cy-hh, cy+hh

    inside = valid & (u >= sx1) & (u <= sx2) & (v >= sy1) & (v <= sy2) & (depth > 0)
    if inside.sum() < 3:
        return -1.0
    d = depth[inside]

    # densest depth bin = the object surface (rejects scattered road points)
    hist, edges = np.histogram(d, bins=min(20, max(3, len(d)//2)))
    peak = int(np.argmax(hist))
    lo, hi = edges[peak], edges[peak+1]
    cluster = d[(d >= lo) & (d <= hi)]
    surface = float(np.median(cluster)) if len(cluster) else float(np.median(d))

    # GT = distance to object center; LiDAR = near surface. Add half-length + cam offset.
    raw = surface + 2.3 + CAM_X
    # apply linear calibration fitted against GT
    return DIST_CAL_A * raw + DIST_CAL_B


def run_episode(model, person_model, ep_dir, out_path, visualize=False, max_viz=0):
    import cv2
    calib = json.load(open(str(Path(ep_dir) / 'calib.json')))
    K = np.array(calib['K'])
    meta = json.load(open(str(Path(ep_dir) / 'meta.json')))

    results = []
    viz_count = 0
    viz_dir = Path(ep_dir).parent / 'perception_viz'
    if visualize:
        viz_dir.mkdir(exist_ok=True)

    for rec in meta:
        img_path = Path(ep_dir) / rec['rgb']
        lidar_path = Path(ep_dir) / rec['lidar']
        if not img_path.exists():
            continue

        # 1. detection (fine-tuned model)
        det = model(str(img_path), device=0, verbose=False, conf=0.25)[0]
        detections = []
        for b in det.boxes:
            cls = int(b.cls)
            conf = float(b.conf)
            x1, y1, x2, y2 = [float(v) for v in b.xyxy[0]]
            detections.append({'class': cls, 'class_name': CLASS_NAMES[cls],
                               'conf': conf, 'box': [x1, y1, x2, y2]})

        # 2. pedestrian fallback (pretrained person = class 0 in COCO)
        pdet = person_model(str(img_path), device=0, verbose=False, conf=0.30, classes=[0])[0]
        for b in pdet.boxes:
            conf = float(b.conf)
            x1, y1, x2, y2 = [float(v) for v in b.xyxy[0]]
            detections.append({'class': 0, 'class_name': 'pedestrian',
                               'conf': conf, 'box': [x1, y1, x2, y2], 'source': 'coco'})

        # 3. LiDAR distance per detection
        if lidar_path.exists():
            pts = np.load(str(lidar_path))
            cam_pts = lidar_to_camera(pts)
            u, v, depth, valid = project_to_image(cam_pts, K)
            for d in detections:
                d['distance'] = distance_in_box(u, v, depth, valid, d['box'])
        else:
            for d in detections:
                d['distance'] = -1.0

        results.append({
            'tick': rec['tick'],
            'rgb': rec['rgb'],
            'detections': detections,
            # ground truth for calibration later
            'ObsDist_gt': rec['ObsDist_gt'],
            'EgoSpd_gt': rec['EgoSpd_gt'],
            'Pedestrian_gt': rec['Pedestrian_gt'],
            'TrafficLight_gt': rec['TrafficLight_gt'],
        })

        # visualization
        if visualize and viz_count < (max_viz or 999999):
            img = cv2.imread(str(img_path))
            colors = [(0,0,255),(0,255,0),(255,0,0),(0,255,255),(255,0,255)]
            for d in detections:
                x1,y1,x2,y2 = [int(v) for v in d['box']]
                c = colors[d['class']]
                cv2.rectangle(img, (x1,y1), (x2,y2), c, 2)
                label = f"{d['class_name']} {d['conf']:.2f} {d['distance']:.1f}m"
                cv2.putText(img, label, (x1, y1-4), cv2.FONT_HERSHEY_SIMPLEX, 0.4, c, 1)
            cv2.imwrite(str(viz_dir / f"perc_{rec['tick']:03d}.jpg"), img)
            viz_count += 1

    if out_path:
        Path(out_path).parent.mkdir(parents=True, exist_ok=True)
        json.dump(results, open(out_path, 'w'), indent=2)
    return results, viz_count


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', default='/mnt/d/NSTM_Project/runs/finetune/weights/best.pt')
    ap.add_argument('--data', default='/mnt/d/NSTM_Project/data/enriched_nstm')
    ap.add_argument('--episode', default=None, help='single episode dir (for testing)')
    ap.add_argument('--out', default='/mnt/d/NSTM_Project/data/perception')
    ap.add_argument('--visualize', action='store_true')
    ap.add_argument('--max_viz', type=int, default=30)
    args = ap.parse_args()

    from ultralytics import YOLO
    print("Loading fine-tuned model...")
    model = YOLO(args.model)
    print("Loading pretrained model for pedestrian fallback...")
    person_model = YOLO('yolov8n.pt')

    if args.episode:
        # single episode test
        print(f"Processing single episode: {args.episode}")
        out = Path(args.out) / (Path(args.episode).name + '_perception.json')
        results, nviz = run_episode(model, person_model, args.episode, str(out),
                                     visualize=args.visualize, max_viz=args.max_viz)
        # stats
        total_det = sum(len(r['detections']) for r in results)
        with_dist = sum(1 for r in results for d in r['detections'] if d['distance'] > 0)
        print(f"\nFrames: {len(results)}")
        print(f"Total detections: {total_det}")
        print(f"Detections with valid LiDAR distance: {with_dist}")
        if args.visualize:
            print(f"Visualizations saved to: {Path(args.episode).parent / 'perception_viz'}")
        print(f"Output: {out}")
    else:
        # all episodes
        meta_files = sorted(glob.glob(os.path.join(args.data, '*', 'episode_*', 'meta.json')))
        print(f"Processing {len(meta_files)} episodes...")
        for i, mf in enumerate(meta_files):
            ep_dir = Path(mf).parent
            scenario = ep_dir.parent.name
            out = Path(args.out) / scenario / (ep_dir.name + '_perception.json')
            results, _ = run_episode(model, person_model, ep_dir, str(out))
            print(f"  [{i+1}/{len(meta_files)}] {scenario}/{ep_dir.name}: {len(results)} frames")
        print(f"\nDone! Perception output in: {args.out}")
        print("Next: src/09_calibrate_confidence.py")


if __name__ == '__main__':
    main()
