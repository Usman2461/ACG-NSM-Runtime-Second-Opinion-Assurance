"""
08b_calibrate_distance.py
=========================
Fit a linear correction for LiDAR distance: corrected = a*raw + b
using GT obstacle distance as reference. Removes the systematic
proportional underestimate.

Runs perception on several vehicle-heavy episodes, collects
(raw_detected, gt) pairs, fits least-squares, prints a,b.

USAGE:
  python 08b_calibrate_distance.py --model .../best.pt
"""
import json, glob, argparse, math
from pathlib import Path
import numpy as np


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', default='/mnt/d/NSTM_Project/runs/finetune/weights/best.pt')
    ap.add_argument('--data', default='/mnt/d/NSTM_Project/data/enriched_nstm')
    ap.add_argument('--scenarios', nargs='+',
                    default=['highway_cutin', 'left_turn_signalized', 'pedestrian_crossing'])
    ap.add_argument('--n_episodes', type=int, default=8)
    args = ap.parse_args()

    import sys
    sys.path.insert(0, '/mnt/d/NSTM_Project/src')
    from importlib import import_module
    # import the inference helpers
    import importlib.util
    spec = importlib.util.spec_from_file_location("perc", "/mnt/d/NSTM_Project/src/08_perception_inference.py")
    perc = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(perc)

    from ultralytics import YOLO
    model = YOLO(args.model)
    person_model = YOLO('yolov8n.pt')

    raw_list, gt_list = [], []

    for scenario in args.scenarios:
        eps = sorted(glob.glob(f"{args.data}/{scenario}/episode_*"))[:args.n_episodes]
        for ep in eps:
            results, _ = perc.run_episode(model, person_model, ep, None, visualize=False)
            for r in results:
                gt = r['ObsDist_gt']
                if gt <= 0:
                    continue
                dets = [d for d in r['detections'] if d['distance'] > 0 and d['class'] in (0, 1)]
                if not dets:
                    continue
                raw = min(dets, key=lambda d: d['distance'])['distance']
                raw_list.append(raw)
                gt_list.append(gt)
        print(f"  {scenario}: collected {len(raw_list)} pairs so far")

    raw = np.array(raw_list)
    gt = np.array(gt_list)
    print(f"\nTotal calibration pairs: {len(raw)}")

    if len(raw) < 10:
        print("Not enough pairs. Try more episodes or scenarios.")
        return

    # least-squares fit: gt = a*raw + b
    A = np.vstack([raw, np.ones_like(raw)]).T
    a, b = np.linalg.lstsq(A, gt, rcond=None)[0]
    print(f"\nLinear correction: corrected = {a:.3f} * raw + {b:.3f}")

    # evaluate
    corrected = a * raw + b
    err_before = np.abs(raw - gt)
    err_after = np.abs(corrected - gt)
    print(f"Mean abs error BEFORE: {err_before.mean():.1f}m")
    print(f"Mean abs error AFTER:  {err_after.mean():.1f}m")

    # tier accuracy after correction
    def tier(d):
        if d < 0: return 0
        if d > 50: return 1
        if d > 20: return 2
        return 3
    tier_correct = sum(1 for c, g in zip(corrected, gt) if tier(c) == tier(g))
    print(f"Tier accuracy AFTER correction: {tier_correct}/{len(gt)} = {100*tier_correct/len(gt):.0f}%")

    # save calibration
    cal = {"a": float(a), "b": float(b),
           "mean_err_before": float(err_before.mean()),
           "mean_err_after": float(err_after.mean()),
           "n_pairs": int(len(raw))}
    json.dump(cal, open('/mnt/d/NSTM_Project/data/distance_calibration.json', 'w'), indent=2)
    print(f"\nSaved -> /mnt/d/NSTM_Project/data/distance_calibration.json")
    print(f"Apply in perception: corrected_dist = {a:.3f} * raw_dist + {b:.3f}")


if __name__ == '__main__':
    main()
