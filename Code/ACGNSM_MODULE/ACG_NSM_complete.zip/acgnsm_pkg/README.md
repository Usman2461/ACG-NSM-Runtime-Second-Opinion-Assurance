# ACG-NSM — Complete Source Package

Adaptive Confidence-Gated Neural–State Machine, including the guided-planner
work (ACG-NSM-guided TransFuser++).

Every Python file in this package parses. That is not the same as every file
running: several depend on a CARLA server, on trained weights, or on a compiled
state-machine library, and some belong to the earlier standalone system rather
than the guided one. The status notes below say which is which.

---

## Layout

```
01_perception/          detection, calibration, absence confidence, SLAM
02_assessors/           risk and legality
03_bridge_stm/          RLC bridge, state machine adapter, adaptation
04_guided/              guided planner, INDEPENDENT perception
05_shared_perception/   guided planner, SHARED perception variant
06_datasets/            collection, labelling, merging
07_verification/        formal checks and their recorded results
08_analysis/            closed loop, metrics, ablations
docs/                   handover notes and specifications
```

---

## 01_perception

| file | role | status |
|---|---|---|
| `05_autolabel.py` | auto-label from simulator ground truth | original system |
| `05b_grab_map_boxes.py` | static map objects | original system |
| `05c_relabel.py` | relabelling pass | original system |
| `07_finetune_yolo.py` | YOLOv8 fine-tune | superseded by `63_train_detector.py` |
| `63_train_detector.py` | detector training, rect input, per-class metrics | current |
| `08_perception_inference.py` | live inference wrapper | original system |
| `08b_calibrate_distance.py` | distance calibration | original system |
| `09_calibrate_confidence.py` | temperature scaling | **needs refit for the new detector** |
| `54_absence_confidence.py` | Bayesian absence posterior from observation quality | current |
| `55_check_detector.py` | one-frame detector diagnostic | current |
| `10_slam.py`, `probe_lidar_slam.py` | LiDAR odometry | original system; not used in guided |

`54_absence_confidence.py` loads measured per-class recall from
`runs/acgnsm_det/per_class_metrics.json` when present. Without that file it
falls back to the previous detector's figures and prints a warning.

## 02_assessors

| file | role | status |
|---|---|---|
| `11_risk_assessor.py` | stopping distance, TTC, risk tier | current |
| `12_legality_assessor.py` | article-level permission mask | **deployed version** |
| `12_legality_assessor_FIXED.py` | conjunctive most-restrictive encoding | antitone by construction |

The FIXED variant repairs an ordering defect in which an amber signal
short-circuited the pedestrian check. Verified: 0 violations over 7,034
comparable pairs, against 486 for the original. Decide deliberately which one
the experiments use — they are not interchangeable.

## 03_bridge_stm

| file | role | status |
|---|---|---|
| `13_rlc_bridge.py` | gating, binary fail-safe, event quantisation | original |
| `50_graded_bridge.py` | gating with the **graded** fail-safe | current |
| `14_stm_adapter.py` | interface to the compiled state machine | needs `libstm.so` |
| `15_adaptation.py` | bounded threshold adaptation | **not wired into the guided channel** |

The graded bridge reproduces the binary behaviour exactly at `tau=0`, so the
original is a special case. Adaptation exists here but the guided channel does
not call it: as evaluated, the system is confidence-gated but not adaptive.

## 04_guided — independent perception

The main configuration. ACG-NSM runs its own detector and LiDAR routine and
consumes none of the planner's features.

| file | role |
|---|---|
| `40_setup_check.py` | verifies CARLA, torch, weights, modules before a run |
| `42_tfpp_adapter.py` | patches the planner to expose its target speed (backup written) |
| `52_acgnsm_channel.py` | the conservative channel end to end |
| `51_suppression_arbiter.py` | `u* = u_N − λ·max(0, u_N − u_C)`, λ = 2/3 |
| `53_guided_agent.py` | leaderboard agent wrapping both channels |
| `43_run_dual_channel.sh` | runner |
| `41_dual_channel.py` | offline harness with a mock planner |

```bash
python 04_guided/40_setup_check.py --carla_root ... --garage_root ...
python 04_guided/42_tfpp_adapter.py --patch /path/to/carla_garage

ACGNSM_AGENT=.../53_guided_agent.py ACGNSM_ARBITRATE=0 \
ACGNSM_WEIGHTS=.../best.pt ROUTES=routes_devtest \
  bash 04_guided/43_run_dual_channel.sh
```

`ACGNSM_ARBITRATE=0` observes only and returns the planner's control untouched.
`=1` applies suppression.

## 05_shared_perception

Variant in which ACG-NSM reads the planner's own bounding boxes instead of its
own detector. Built for maps where the detector is out of domain.

`72_patch_boxes.py` exposes the planner's boxes and relaxes the guard that
otherwise skips their conversion. The signal field is marked UNAVAILABLE and
excluded from the gate, because the planner has no traffic-light output and
treating an unreported field as a distrusted one asserted a red light on every
tick.

This variant answers whether the planner acted against evidence it already had.
It cannot show that independent sensing catches what the planner missed.

## 06_datasets

| file | role |
|---|---|
| `60_collect_town1213.py` | main collector: planner rig, auto-labels, two admission tests |
| `61_merge_split.py` | block-wise merge and split |
| `62_run_supplement.py` | weather/night supplement with a validation gate |
| `64_collect_pedestrian_dense.py` | staged pedestrian scenes |
| `65_diagnose_staging.py` | diagnoses why a staged scene produced no labels |
| `01–06_*` | earlier collectors from the original system |

Known issue in `64_collect_pedestrian_dense.py`: it inherits the base
collector's photometric gate without configuring its thresholds, so staged
frames are dropped. Set `a.photo_gate = False` in `main()`, or supply the
thresholds, before using it.

## 07_verification

Scripts and their recorded results.

| file | establishes |
|---|---|
| `23_verify_antitonicity.py` | hazard-order antitonicity over the legality domain |
| `27_verify_state_machine.py` | 8/8 properties after repair; 25/25 translation checks |
| `25_decision_correctness.py` | oracle-scored decision correctness |
| `28_second_opinion.py` | arbitration metrics |
| `30_fn_and_latency.py` | false-negative handling and latency |
| `32_graded_suppression.py`, `33_lambda_sweep.py` | λ inertness under the binary fail-safe (negative result) |
| `34_graded_failsafe.py` | graded fail-safe, τ sweep |
| `Main_m0_ORIGINAL.c` / `Main_m0_REPAIRED.c` | generated state machine before and after the P4/P7 repairs |

**The repairs exist only in the generated C.** They must be applied in the ZIPC
source model or they will be lost on regeneration.

## 08_analysis

Closed loop, metrics, ablations and route benchmark from the original
standalone system. `16_closed_loop.py` is the v1 driver in which ACG-NSM had
full control; the guided work supersedes it but it is kept because the
comparison in the paper refers to it.

---

## Dependencies

- CARLA 0.9.15, Python 3.10
- torch 2.5.1+cu121, **numpy < 2** (opencv 4.6 ABI), ultralytics
- `carla_garage` for the guided configurations
- `libstm.so` for the state machine; the channel runs without it and logs that
  it did

## Two patches applied to carla_garage

Both write timestamped backups and are idempotent.

1. `42_tfpp_adapter.py` — two assignments exposing the planner's target speed
   and speed distribution, plus `pretrained=False` so timm does not fetch
   weights that the checkpoint overwrites anyway.
2. `72_patch_boxes.py` — stores the planner's bounding boxes and relaxes the
   conversion guard. Shared-perception variant only.

A fresh clone or `git checkout` of carla_garage silently removes both, and the
guided agent then reports warm-up on every tick.

## Known limitations

- **Adaptation is not active.** Thresholds are fixed at their deployed values.
- **The state machine is exercised narrowly.** Authored for a signalised left
  turn; on open routes it stays in the approach state.
- **Detector recall on pedestrians is 0.077.** Instances are plentiful but
  concentrated: pedestrians appear in 64 of 1,880 validation frames. The
  absence model reports this faithfully, which makes the channel permanently
  cautious about pedestrians.
- **The detector does not transfer between towns.** Measured on a different map
  it returned no traffic lights across 9,807 ticks.
- **Calibration temperature is stale.** `TEMPERATURE = 2.30` was fitted for the
  previous detector; override with `ACGNSM_TEMPERATURE` or refit.
- **Only the longitudinal command is arbitrated.** Steering passes through.
