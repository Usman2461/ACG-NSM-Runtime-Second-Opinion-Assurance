"""
12_legality_assessor.py
=======================
Phase 5b: Legality Assessor.

Evaluates each candidate action against Chinese Road Traffic Safety Law
(道路交通安全法) and the project rules document. Returns per-action verdict:
LEGAL / WARNING / ILLEGAL, tagged with the article number.

Candidate actions:
  PROCEED, TURN_LEFT, TURN_RIGHT, LANE_CHANGE_L, LANE_CHANGE_R, STOP

Inputs (per tick):
  traffic_light : 0=red, 1=green, 2=yellow, -1=none
  ego_speed     : km/h
  speed_limit   : km/h (from road context / SLAM lane info)
  rss_distance  : following distance to lead vehicle (m), -1 if none
  rss_min       : minimum safe following distance (m)
  lane_marking  : 'solid' | 'dashed' | 'none' (left/right separately)
  pedestrian_crossing : bool (pedestrian on/near crosswalk ahead)
  oncoming      : bool (oncoming traffic present, for left turn)

Output: dict {action: (verdict, article, reason)}

Article references (Chinese Road Traffic Safety Law + Implementation Regs):
  Art.38  - obey traffic signals
  Art.44  - intersection right-of-way, yielding on turns
  Art.47  - yield to pedestrians on crosswalk
  Art.42  - speed limits
  Art.43  - safe following distance
  Art.82/90 - lane discipline, solid line crossing prohibited
"""

# Article catalog
ART = {
    'SIGNAL':      ('Art.38',  'Obey traffic signals'),
    'TURN_YIELD':  ('Art.44',  'Yield right-of-way at intersection turns'),
    'PED_YIELD':   ('Art.47',  'Yield to pedestrians on crosswalk'),
    'SPEED':       ('Art.42',  'Observe posted speed limit'),
    'FOLLOW_DIST': ('Art.43',  'Maintain safe following distance'),
    'SOLID_LINE':  ('Art.82',  'No crossing solid lane markings'),
    'LANE_DISC':   ('Art.90',  'Lane discipline'),
}


LEGAL, WARNING, ILLEGAL = 'LEGAL', 'WARNING', 'ILLEGAL'

# Severity order used to combine simultaneously-applicable constraints.
_SEVERITY = {LEGAL: 0, WARNING: 1, ILLEGAL: 2}


def _most_restrictive(constraints, default_reason):
    """Combine all applicable constraints, keeping the most restrictive verdict.

    Every hazardous condition contributes a constraint; the verdict is the
    maximum severity over them. This makes the permission map ANTITONE BY
    CONSTRUCTION: adding hazard can only add constraints, and the max over a
    larger set is never less restrictive, so permissions can only shrink.
    (An elif-chain does NOT have this property: an early, less-severe branch
    can mask a later, more-severe one.)
    """
    if not constraints:
        return (LEGAL, '-', default_reason)
    return max(constraints, key=lambda c: _SEVERITY[c[0]])


def assess_legality(traffic_light=-1, ego_speed=0.0, speed_limit=50.0,
                    rss_distance=-1.0, rss_min=10.0,
                    lane_marking_left='dashed', lane_marking_right='dashed',
                    pedestrian_crossing=False, oncoming=False):
    """Return {action: (verdict, article, reason)} for each candidate action."""
    verdicts = {}
    rss_bad = (rss_distance >= 0 and rss_distance < rss_min)
    speeding = (ego_speed > speed_limit)

    # ---- PROCEED (go straight through) ----
    c = []
    if traffic_light == 0:   c.append((ILLEGAL, *ART['SIGNAL']))
    elif traffic_light == 2: c.append((WARNING, *ART['SIGNAL']))
    if pedestrian_crossing:  c.append((ILLEGAL, *ART['PED_YIELD']))
    if rss_bad:              c.append((WARNING, *ART['FOLLOW_DIST']))
    if speeding:             c.append((WARNING, *ART['SPEED']))
    verdicts['PROCEED'] = _most_restrictive(c, 'clear to proceed')

    # ---- TURN_LEFT ----
    c = []
    if traffic_light == 0:   c.append((ILLEGAL, *ART['SIGNAL']))
    elif traffic_light == 2: c.append((WARNING, *ART['SIGNAL']))
    if oncoming:             c.append((ILLEGAL, *ART['TURN_YIELD']))
    if pedestrian_crossing:  c.append((ILLEGAL, *ART['PED_YIELD']))
    if speeding:             c.append((WARNING, *ART['SPEED']))
    verdicts['TURN_LEFT'] = _most_restrictive(c, 'left turn permitted')

    # ---- TURN_RIGHT ----
    c = []
    if traffic_light == 0:   c.append((WARNING, *ART['SIGNAL']))   # right-on-red
    if pedestrian_crossing:  c.append((ILLEGAL, *ART['PED_YIELD']))
    if speeding:             c.append((WARNING, *ART['SPEED']))
    verdicts['TURN_RIGHT'] = _most_restrictive(c, 'right turn permitted')

    # ---- LANE_CHANGE_LEFT ----
    c = []
    if lane_marking_left == 'solid': c.append((ILLEGAL, *ART['SOLID_LINE']))
    if rss_bad:                      c.append((WARNING, *ART['FOLLOW_DIST']))
    if pedestrian_crossing:          c.append((ILLEGAL, *ART['PED_YIELD']))
    if speeding:                     c.append((WARNING, *ART['SPEED']))
    verdicts['LANE_CHANGE_L'] = _most_restrictive(c, 'lane change left permitted')

    # ---- LANE_CHANGE_RIGHT ----
    c = []
    if lane_marking_right == 'solid': c.append((ILLEGAL, *ART['SOLID_LINE']))
    if rss_bad:                       c.append((WARNING, *ART['FOLLOW_DIST']))
    if pedestrian_crossing:           c.append((ILLEGAL, *ART['PED_YIELD']))
    if speeding:                      c.append((WARNING, *ART['SPEED']))
    verdicts['LANE_CHANGE_R'] = _most_restrictive(c, 'lane change right permitted')

    # ---- STOP ----
    # stopping is almost always legal (safety action)
    verdicts['STOP'] = (LEGAL, '-', 'stopping is safe and legal')

    return verdicts


def legal_action_mask(verdicts):
    """
    Convert verdicts into a bitmask of PERMITTED actions (LEGAL or WARNING).
    ILLEGAL actions are excluded (bit=0).
    Bit order: PROCEED, TURN_LEFT, TURN_RIGHT, LANE_CHANGE_L, LANE_CHANGE_R, STOP
    """
    order = ['PROCEED', 'TURN_LEFT', 'TURN_RIGHT', 'LANE_CHANGE_L', 'LANE_CHANGE_R', 'STOP']
    mask = 0
    for i, action in enumerate(order):
        verdict = verdicts[action][0]
        if verdict != ILLEGAL:    # LEGAL or WARNING = permitted
            mask |= (1 << i)
    return mask, order


def most_severe_violation(verdicts):
    """Return the article of the most severe pending violation (or None)."""
    for action, (verdict, art, reason) in verdicts.items():
        if verdict == ILLEGAL and art != '-':
            return art, reason
    return None, None


# ---- self-test ----
if __name__ == '__main__':
    print("="*60)
    print("Legality Assessor — self test")
    print("="*60)

    scenarios = [
        ("Green light, clear", dict(traffic_light=1, ego_speed=40, speed_limit=50)),
        ("Red light", dict(traffic_light=0, ego_speed=30, speed_limit=50)),
        ("Yellow light", dict(traffic_light=2, ego_speed=45, speed_limit=50)),
        ("Pedestrian on crossing", dict(traffic_light=1, pedestrian_crossing=True)),
        ("Left turn, oncoming traffic", dict(traffic_light=1, oncoming=True)),
        ("Speeding", dict(traffic_light=1, ego_speed=70, speed_limit=50)),
        ("Solid line left", dict(traffic_light=1, lane_marking_left='solid')),
        ("Tailgating", dict(traffic_light=1, rss_distance=4, rss_min=15)),
    ]

    for name, kwargs in scenarios:
        print(f"\n--- {name} ---")
        v = assess_legality(**kwargs)
        for action, (verdict, art, reason) in v.items():
            flag = {'LEGAL':'[OK]', 'WARNING':'[!]', 'ILLEGAL':'[X]'}[verdict]
            art_str = f"({art})" if art != '-' else ""
            print(f"  {flag} {action:14s}: {verdict:8s} {art_str} {reason}")
        mask, order = legal_action_mask(v)
        permitted = [order[i] for i in range(len(order)) if mask & (1<<i)]
        print(f"  LegalMask = {mask:06b} -> permitted: {', '.join(permitted)}")
        art, reason = most_severe_violation(v)
        if art:
            print(f"  Most severe violation: {art} ({reason})")
