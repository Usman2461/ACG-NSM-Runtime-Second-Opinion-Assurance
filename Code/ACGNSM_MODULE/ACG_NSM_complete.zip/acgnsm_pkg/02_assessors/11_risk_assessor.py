"""
11_risk_assessor.py
===================
Phase 5a: Risk Assessor (pure physics, no external deps).

Implements the risk model from the project rules documents:
  - Distance tiers: far >50m, mid 20-50m, near <20m
  - Speed tiers: low 0-30, med 30-60, high 60+ km/h
  - Core safety criterion: ego braking distance < obstacle remaining distance
  - Continuous risk score R in [0,1] from TTC + braking-margin coupling
  - Quantize R -> LOW/MED/HIGH/CRITICAL with hysteresis

Inputs (per tick):
  obs_dist   : distance to nearest obstacle ahead (m), -1 if none
  ego_speed  : ego speed (km/h)
  conf       : confidence of the distance estimate (calibrated theta) in [0,1]
  rel_speed  : closing speed to obstacle (km/h), optional (default = ego_speed)

Outputs:
  R          : continuous risk score [0,1]
  tier       : LOW / MED / HIGH / CRITICAL (with hysteresis)
  components : dict of intermediate values (for audit trail)
"""
import math


# ---- physical constants ----
G = 9.81                     # m/s^2
MU = 0.7                     # tyre-road friction (dry asphalt); lower in rain
REACTION_TIME = 0.3          # s (system reaction latency)

# ---- tier thresholds (from rules doc) ----
DIST_FAR = 50.0              # m
DIST_MID = 20.0              # m
SPD_LOW = 30.0               # km/h
SPD_MED = 60.0               # km/h

# ---- risk score quantization boundaries (adaptable later within bounds) ----
R_LOW_MED = 0.30
R_MED_HIGH = 0.70
R_CRITICAL = 0.90

# ---- hysteresis ----
HYST = 0.05                  # downward transitions need R below boundary-HYST
HYST_TICKS = 5               # for this many consecutive ticks


def braking_distance(speed_kmh, mu=MU):
    """
    Physical braking distance (m) including reaction distance.
    d_brake = v*t_react + v^2 / (2*mu*g)
    """
    v = speed_kmh / 3.6       # m/s
    d_react = v * REACTION_TIME
    d_stop = (v * v) / (2 * mu * G)
    return d_react + d_stop


def time_to_collision(obs_dist, rel_speed_kmh):
    """TTC (s). inf if not closing."""
    if rel_speed_kmh <= 0 or obs_dist < 0:
        return float('inf')
    v = rel_speed_kmh / 3.6
    return obs_dist / v


def compute_risk(obs_dist, ego_speed, conf=1.0, rel_speed=None, mu=MU):
    """
    Returns (R, components dict).
    R combines three normalized danger signals:
      1. braking margin: how much of the gap the braking distance consumes
      2. TTC: inverse time-to-collision (urgency)
      3. proximity: how close relative to the tier boundaries
    Weighted, clipped to [0,1]. Confidence scales the *certainty* but the
    bridge handles gating; here we report raw R plus the inputs.
    """
    if obs_dist < 0:
        return 0.0, {'reason': 'no_obstacle', 'd_brake': 0.0, 'ttc': float('inf')}

    if rel_speed is None:
        rel_speed = ego_speed

    d_brake = braking_distance(ego_speed, mu)
    ttc = time_to_collision(obs_dist, rel_speed)

    # --- signal 1: braking margin ratio ---
    # if braking distance >= obstacle distance, we cannot stop in time -> danger=1
    # core criterion from rules doc: d_brake < obs_dist for safety
    margin_ratio = d_brake / max(obs_dist, 0.1)
    s_brake = min(1.0, margin_ratio)          # 1.0 = can't stop in the gap

    # --- signal 2: TTC urgency ---
    # TTC < 2s is dangerous, < 1s critical; map inversely
    if ttc == float('inf'):
        s_ttc = 0.0
    else:
        s_ttc = max(0.0, min(1.0, (4.0 - ttc) / 4.0))   # ttc>=4s ->0, ttc=0 ->1

    # --- signal 3: proximity within tier scheme ---
    if obs_dist > DIST_FAR:
        s_prox = 0.1
    elif obs_dist > DIST_MID:
        # linear within mid band
        s_prox = 0.3 + 0.4 * (DIST_FAR - obs_dist) / (DIST_FAR - DIST_MID)
    else:
        # near band: high proximity danger
        s_prox = 0.7 + 0.3 * (DIST_MID - obs_dist) / DIST_MID

    # --- speed amplifier (high speed raises danger per rules doc) ---
    if ego_speed > SPD_MED:
        spd_amp = 1.2
    elif ego_speed > SPD_LOW:
        spd_amp = 1.0
    else:
        spd_amp = 0.85

    # weighted combination
    R = (0.45 * s_brake + 0.30 * s_ttc + 0.25 * s_prox) * spd_amp
    R = max(0.0, min(1.0, R))

    components = {
        'd_brake': round(d_brake, 2),
        'obs_dist': round(obs_dist, 2),
        'ttc': round(ttc, 2) if ttc != float('inf') else None,
        's_brake': round(s_brake, 3),
        's_ttc': round(s_ttc, 3),
        's_prox': round(s_prox, 3),
        'spd_amp': spd_amp,
        'can_stop': d_brake < obs_dist,    # the core safety criterion
        'dist_tier': dist_tier(obs_dist),
        'spd_tier': spd_tier(ego_speed),
    }
    return round(R, 4), components


def dist_tier(obs_dist):
    if obs_dist < 0: return 'none'
    if obs_dist > DIST_FAR: return 'far'
    if obs_dist > DIST_MID: return 'mid'
    return 'near'


def spd_tier(ego_speed):
    if ego_speed == 0: return 'idle'
    if ego_speed <= SPD_LOW: return 'low'
    if ego_speed <= SPD_MED: return 'med'
    return 'high'


class RiskQuantizer:
    """Quantizes continuous R into tiers with hysteresis (stateful)."""
    TIERS = ['LOW', 'MED', 'HIGH', 'CRITICAL']

    def __init__(self):
        self.current_tier = 'LOW'
        self._below_count = 0
        self._prev_R = 0.0

    def _raw_tier(self, R):
        if R > R_CRITICAL: return 'CRITICAL'
        if R > R_MED_HIGH: return 'HIGH'
        if R > R_LOW_MED: return 'MED'
        return 'LOW'

    def update(self, R):
        raw = self._raw_tier(R)
        cur_idx = self.TIERS.index(self.current_tier)
        raw_idx = self.TIERS.index(raw)

        if raw_idx > cur_idx:
            # upward: immediate (safety never waits)
            self.current_tier = raw
            self._below_count = 0
            self._prev_R = R
            return self.current_tier
        elif raw_idx < cur_idx:
            # downward. Immediate if EITHER:
            #   (a) drop of 2+ tiers, or
            #   (b) large magnitude drop in R (situation clearly improved,
            #       e.g. obstacle distance jumped 5m -> 53m)
            large_magnitude_drop = (self._prev_R - R) > 0.30
            if (cur_idx - raw_idx >= 2) or large_magnitude_drop:
                self.current_tier = raw
                self._below_count = 0
            else:
                # single-tier drop near a boundary: require sustained lower R
                boundary = [R_LOW_MED, R_MED_HIGH, R_CRITICAL][cur_idx-1] if cur_idx > 0 else 0
                if R < boundary - HYST:
                    self._below_count += 1
                    if self._below_count >= HYST_TICKS:
                        self.current_tier = raw
                        self._below_count = 0
                else:
                    self._below_count = 0
        else:
            self._below_count = 0

        self._prev_R = R
        return self.current_tier

    def reset(self):
        """Reset state - call between independent episodes."""
        self.current_tier = 'LOW'
        self._below_count = 0
        self._prev_R = 0.0


# ---- self-test / demo ----
if __name__ == '__main__':
    import json, glob, sys

    print("="*60)
    print("Risk Assessor — self test on physical scenarios")
    print("="*60)

    tests = [
        ("Clear road",          -1,  50, 1.0),
        ("Far obstacle, slow",   60,  25, 0.9),
        ("Mid obstacle, city",   35,  45, 0.9),
        ("Near obstacle, fast",  15,  70, 0.9),
        ("Very near, highway",    8,  80, 0.9),
        ("Mid dist, stopped",    30,   0, 0.9),
    ]
    for name, dist, spd, conf in tests:
        q = RiskQuantizer()        # fresh per scenario (independent tests)
        R, comp = compute_risk(dist, spd, conf)
        tier = q.update(R)
        cs = comp.get('can_stop', '-')
        print(f"\n{name}:")
        print(f"  dist={dist}m speed={spd}km/h -> R={R:.3f} tier={tier}")
        print(f"  braking_dist={comp.get('d_brake')}m  can_stop={cs}  TTC={comp.get('ttc')}s")
        print(f"  dist_tier={comp.get('dist_tier')} spd_tier={comp.get('spd_tier')}")

    # run on real perception data if available
    print("\n" + "="*60)
    print("Running on real perception data (episode sample)")
    print("="*60)
    files = glob.glob('/mnt/d/NSTM_Project/data/perception/highway_cutin/*_perception.json')
    if files:
        data = json.load(open(files[0]))
        q2 = RiskQuantizer()
        shown = 0
        for rec in data:
            gt = rec['ObsDist_gt']
            spd = rec['EgoSpd_gt']
            if gt <= 0: continue
            R, comp = compute_risk(gt, spd, 0.9)
            tier = q2.update(R)
            if shown < 12:
                print(f"tick {rec['tick']:3d}: dist={gt:5.1f}m spd={spd:5.1f} -> R={R:.3f} {tier:8s} can_stop={comp['can_stop']}")
                shown += 1
