"""Does ANY constant partial correction preserve the interception guarantee?
Sweeps lambda over [0,1] and traces the safety/cost frontier."""
import json, random, importlib.util
from pathlib import Path
SRC=Path(__file__).resolve().parent; OUT=Path('/tmp/results')
exec(open(SRC/'32_graded_suppression.py').read().split("def run(")[0].split('"""',2)[2])

def run_lambda(lam_fixed, n=4000, degrade=0.6, seed=1, clip=True):
    rng=random.Random(seed)
    nom=bridge_m.RLCBridge(weather='clear',ablation='no_gate')
    con=bridge_m.RLCBridge(weather='clear',ablation='full')
    unsafe=TP=FN=harsh=0; drop=0.0; N=0
    for _ in range(n):
        t=scene(rng); man=rng.choice(['PROCEED','TURN_LEFT'])
        o_act,_,_=oracle(t,man)
        perc,conf_min,gap=perceive(t,rng,degrade)
        piN,tierN,okN=opinion(nom,perc,man); piC,tierC,okC=opinion(con,perc,man)
        uN=target_speed(tierN,gap) if okN else 0.0
        uC=target_speed(tierC,gap) if okC else 0.0
        u=(1-lam_fixed)*uN+lam_fixed*uC
        if clip: u=min(u, v_safe(gap))
        if not okC: u=0.0
        N+=1; stop=(u<1.0)
        if o_act=='STOP' and not stop: unsafe+=1
        if o_act=='STOP' and uN>=1.0:
            TP+= 1 if stop else 0; FN+= 0 if stop else 1
        if o_act=='PROCEED':
            drop+=max(0.0,uN-u)
            if stop and uN>1.0: harsh+=1
    return dict(lam=lam_fixed, unsafe=unsafe/N,
                recall=(TP/(TP+FN)) if TP+FN else float('nan'),
                speed_given_up=drop/N, harsh=harsh/N)

if __name__=='__main__':
    print("degradation 0.6, WITH conservative-envelope clip")
    print(f"{'lambda':>7}{'unsafe %':>10}{'recall %':>10}{'given up':>10}{'harsh %':>9}")
    print('-'*46)
    rows=[]
    for lam in (0.0,0.2,0.4,0.5,0.6,0.8,1.0):
        r=run_lambda(lam); rows.append(r)
        print(f"{lam:>7.1f}{100*r['unsafe']:>10.2f}{100*r['recall']:>10.1f}"
              f"{r['speed_given_up']:>10.2f}{100*r['harsh']:>9.2f}")
    print("\nsame sweep WITHOUT the clip (shows what the clip is doing)")
    print(f"{'lambda':>7}{'unsafe %':>10}{'recall %':>10}")
    print('-'*27)
    noclip=[]
    for lam in (0.0,0.4,0.6,0.8,1.0):
        r=run_lambda(lam,clip=False); noclip.append(r)
        print(f"{lam:>7.1f}{100*r['unsafe']:>10.2f}{100*r['recall']:>10.1f}")
    json.dump({'clipped':rows,'unclipped':noclip}, open(OUT/'lambda_sweep.json','w'), indent=2)
    print(f"\n[OK] {OUT/'lambda_sweep.json'}")
