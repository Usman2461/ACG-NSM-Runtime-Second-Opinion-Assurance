"""
25_decision_correctness.py
==========================
AFFIRMATIVE evaluation of ACG-NSM: rather than removing components and observing
failure, we ask directly whether the system's decisions are CORRECT, whether its
stated REASON is correct, and whether its errors fall on the safe side.

Ground-truth oracle
-------------------
For a TRUE scene state (not the perceived one), the correct decision is
computable from physics and the encoded rule set alone:

    if the vehicle physically cannot stop in the available gap  -> STOP  (risk)
    else if the intended maneuver is prohibited by a rule       -> STOP  (legality)
    else                                                        -> PROCEED

The system, by contrast, sees only NOISY perception with confidences. We compare
its decision against the oracle over randomly sampled scenes.

Outcome taxonomy (per decision)
    CORRECT-PROCEED   oracle PROCEED, system PROCEED
    CORRECT-STOP      oracle STOP,    system STOP
    CONSERVATIVE      oracle PROCEED, system STOP    (safe: unnecessary caution)
    UNSAFE            oracle STOP,    system PROCEED (the only dangerous cell)

Attribution: when both agree on STOP, does the system cite the same cause
(risk / legality / both) that the oracle does?

Outputs
    results/decision_correctness.json
    results/fig_decision_correctness.png/.pdf
    results/decision_correctness_table.tex
"""
import json, random, importlib.util, sys
from pathlib import Path

SRC = Path(__file__).resolve().parent
OUT = SRC.parent / 'results'
OUT.mkdir(exist_ok=True)


def _load(name, path):
    spec = importlib.util.spec_from_file_location(name, str(path))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


risk_m = _load('risk', SRC / '11_risk_assessor.py')
leg_m = _load('leg', SRC / '12_legality_assessor.py')
bridge_m = _load('bridge', SRC / '13_rlc_bridge.py')

R_MED_HIGH = 0.70          # tier boundary above which the vehicle must slow/stop
SPEED_LIMIT = 50.0
RSS_MIN = 15.0


# ------------------------------------------------------------------ the oracle
def oracle(true_scene, maneuver='PROCEED'):
    """Correct decision + cause, computed from the TRUE scene."""
    R, _ = risk_m.compute_risk(true_scene['obs_dist'], true_scene['ego_speed'])
    verdicts = leg_m.assess_legality(
        traffic_light=true_scene['light'],
        ego_speed=true_scene['ego_speed'], speed_limit=SPEED_LIMIT,
        rss_distance=true_scene['obs_dist'], rss_min=RSS_MIN,
        pedestrian_crossing=true_scene['ped'], oncoming=true_scene['onc'])
    unsafe = R >= R_MED_HIGH
    illegal = verdicts[maneuver][0] == 'ILLEGAL'
    if unsafe and illegal:  return 'STOP', 'both'
    if unsafe:              return 'STOP', 'risk'
    if illegal:             return 'STOP', 'legality'
    return 'PROCEED', 'none'


# ------------------------------------------------- perception noise model
def perceive(true_scene, rng, degrade=0.0):
    """Simulate noisy perception: value errors and confidence drop.
    `degrade` in [0,1] scales both the error rate and the confidence loss."""
    base_conf = 0.96 - 0.55 * degrade
    jitter = lambda c: max(0.05, min(0.99, rng.gauss(c, 0.05 + 0.10 * degrade)))

    # distance: multiplicative error growing with degradation
    d_err = rng.gauss(1.0, 0.03 + 0.15 * degrade)
    obs = max(0.5, true_scene['obs_dist'] * d_err)

    # categorical fields flip with probability proportional to degradation
    p_flip = 0.02 + 0.35 * degrade
    ped = true_scene['ped'] ^ (rng.random() < p_flip)
    onc = true_scene['onc'] ^ (rng.random() < p_flip)
    light = true_scene['light']
    if rng.random() < p_flip * 0.6:
        light = rng.choice([-1, 0, 1, 2])

    return {
        'obs_dist': (obs, jitter(base_conf)),
        'ego_speed': (true_scene['ego_speed'], 0.95),
        'pedestrian': (ped, jitter(base_conf)),
        'traffic_light': (light, jitter(base_conf)),
        'oncoming': (onc, jitter(base_conf - 0.03)),
    }


def system_decision(bridge, perc, maneuver='PROCEED'):
    """Run the real bridge; derive decision + cited cause from its output."""
    out = bridge.process(perc, {'speed_limit': SPEED_LIMIT})
    ram = out['ram']
    tier = ram['RiskTier']
    order = ['PROCEED', 'TURN_LEFT', 'TURN_RIGHT',
             'LANE_CHANGE_L', 'LANE_CHANGE_R', 'STOP']
    idx = order.index(maneuver)
    permitted = bool(ram['LegalMask'] & (1 << idx))
    unsafe = tier >= 2                      # HIGH or CRITICAL
    if unsafe and not permitted: return 'STOP', 'both', out
    if unsafe:                   return 'STOP', 'risk', out
    if not permitted:            return 'STOP', 'legality', out
    return 'PROCEED', 'none', out


# ---------------------------------------------------------------- experiment
def sample_scene(rng):
    return {
        'obs_dist': rng.choice([rng.uniform(5, 20), rng.uniform(20, 60), 100.0]),
        'ego_speed': rng.uniform(15, 60),
        'light': rng.choice([-1, 0, 1, 2]),
        'ped': rng.random() < 0.30,
        'onc': rng.random() < 0.30,
    }


def run(n=4000, degrade=0.0, seed=0, gate=True):
    rng = random.Random(seed)
    bridge = bridge_m.RLCBridge(weather='clear',
                                ablation='full' if gate else 'no_gate')
    cells = {'CORRECT-PROCEED': 0, 'CORRECT-STOP': 0,
             'CONSERVATIVE': 0, 'UNSAFE': 0}
    attrib = {}          # (oracle_cause, system_cause) -> count
    for _ in range(n):
        true_s = sample_scene(rng)
        man = rng.choice(['PROCEED', 'TURN_LEFT'])
        o_act, o_cause = oracle(true_s, man)
        perc = perceive(true_s, rng, degrade)
        s_act, s_cause, _ = system_decision(bridge, perc, man)

        if o_act == 'PROCEED' and s_act == 'PROCEED':   cells['CORRECT-PROCEED'] += 1
        elif o_act == 'STOP' and s_act == 'STOP':       cells['CORRECT-STOP'] += 1
        elif o_act == 'PROCEED' and s_act == 'STOP':    cells['CONSERVATIVE'] += 1
        else:                                           cells['UNSAFE'] += 1

        if o_act == 'STOP' and s_act == 'STOP':
            attrib[(o_cause, s_cause)] = attrib.get((o_cause, s_cause), 0) + 1
    total = sum(cells.values())
    return {
        'n': total, 'degrade': degrade, 'gate': gate,
        'cells': cells,
        'rates': {k: v / total for k, v in cells.items()},
        'attribution': {f"{a}|{b}": c for (a, b), c in sorted(attrib.items())},
    }


if __name__ == '__main__':
    results = {'sweep': [], 'nogate_sweep': []}
    print(f"{'degrade':>8} {'correct':>9} {'conservative':>13} {'UNSAFE':>8}")
    print("-" * 44)
    for d in [0.0, 0.2, 0.4, 0.6, 0.8, 1.0]:
        r = run(degrade=d, seed=1, gate=True)
        results['sweep'].append(r)
        corr = r['rates']['CORRECT-PROCEED'] + r['rates']['CORRECT-STOP']
        print(f"{d:>8.1f} {corr:>9.1%} {r['rates']['CONSERVATIVE']:>13.1%} "
              f"{r['rates']['UNSAFE']:>8.2%}")
    print()
    print("--- ungated baseline (same inputs, gate disabled) ---")
    print(f"{'degrade':>8} {'correct':>9} {'conservative':>13} {'UNSAFE':>8}")
    print("-" * 44)
    for d in [0.0, 0.2, 0.4, 0.6, 0.8, 1.0]:
        r = run(degrade=d, seed=1, gate=False)
        results['nogate_sweep'].append(r)
        corr = r['rates']['CORRECT-PROCEED'] + r['rates']['CORRECT-STOP']
        print(f"{d:>8.1f} {corr:>9.1%} {r['rates']['CONSERVATIVE']:>13.1%} "
              f"{r['rates']['UNSAFE']:>8.2%}")

    (OUT / 'decision_correctness.json').write_text(json.dumps(results, indent=2))
    print(f"\n[OK] wrote {OUT/'decision_correctness.json'}")
