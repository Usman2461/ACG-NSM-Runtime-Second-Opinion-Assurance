"""
32_graded_suppression.py
========================
Rebuilt from scratch. Replaces the binary override of the second-opinion
arbiter with graded suppression, and measures whether the unnecessary-caution
cost falls while the interception guarantee is preserved.

Design
------
The maneuver decision remains symbolic and binary, so the permission-set
argument of Proposition 1 is untouched: if the conservative opinion forbids the
maneuver, the maneuver is forbidden. Suppression acts only on the CONTINUOUS
target speed within an admitted maneuver:

    u_N   nominal target speed      (from the ungated risk tier)
    u_C   conservative target speed (from the gated risk tier)
    u*    = (1 - lambda) u_N + lambda u_C ,      then hard-clipped to

    u* <- min( u*, v_safe(gap_C) )

where v_safe(d) is the greatest speed at which the vehicle can still stop
within the gap the CONSERVATIVE channel believes in. The clip is what keeps the
scheme sound: whatever lambda is chosen, the executed speed never exceeds the
conservative stopping envelope, so lambda can only ever make the vehicle
travel more slowly than the nominal proposal and never faster than the
conservative channel would permit.

lambda is not learned. It is a function of the formal state and the RLC
evidence, bounded per state, so that the executed command remains
reconstructible from logged quantities.

Compared configurations
    nominal       execute u_N (no second opinion)
    binary        execute u_C whenever the opinions disagree  (current paper)
    graded        execute u* as above

Reported
    interception recall, residual unsafe rate   -- must not degrade
    mean speed reduction, harsh-intervention rate -- should improve
"""
import json, random, importlib.util, math
from pathlib import Path

SRC = Path(__file__).resolve().parent
OUT = Path('/tmp/results'); OUT.mkdir(exist_ok=True)


def _load(n, p):
    s = importlib.util.spec_from_file_location(n, str(p))
    m = importlib.util.module_from_spec(s); s.loader.exec_module(m); return m


risk_m = _load('risk', SRC / '11_risk_assessor.py')
leg_m = _load('leg', SRC / '12_legality_assessor.py')
bridge_m = _load('bridge', SRC / '13_rlc_bridge.py')

SPEED_LIMIT, RSS_MIN, R_HIGH = 50.0, 15.0, 0.70
ORDER = ['PROCEED', 'TURN_LEFT', 'TURN_RIGHT',
         'LANE_CHANGE_L', 'LANE_CHANGE_R', 'STOP']

# lambda authority per formal state (Sec. "formal state machine controls lambda")
LAMBDA_BAND = {
    'NORMAL':    (0.00, 0.00),
    'WATCH':     (0.00, 0.20),
    'CAUTION':   (0.20, 0.50),
    'RESTRICT':  (0.50, 1.00),
    'OVERRIDE':  (1.00, 1.00),
}


def v_safe(gap_m, mu=0.7):
    """Greatest speed (km/h) at which braking distance still fits in gap_m."""
    if gap_m <= 0:
        return 0.0
    lo, hi = 0.0, 130.0
    for _ in range(40):                     # monotone in v, so bisect
        mid = 0.5 * (lo + hi)
        if risk_m.braking_distance(mid) <= gap_m:
            lo = mid
        else:
            hi = mid
    return lo


def target_speed(tier, gap, cruise=SPEED_LIMIT):
    """Controller's target speed for a risk tier (mirrors 16_closed_loop)."""
    if tier >= 3:  return 0.0
    if tier == 2:  return min(cruise, max(0.0, (gap / 1.5) * 3.6)) if gap > 0 else 8.0
    if tier == 1:  return min(cruise, max(0.0, (gap / 1.2) * 3.6)) if gap > 0 else 18.0
    return cruise


def formal_state(tier_C, permitted, conf_min, D_norm):
    """Formal state from RLC evidence. Deterministic, inspectable, logged."""
    if not permitted:            return 'OVERRIDE'     # legality forbids -> full
    if tier_C >= 3:              return 'OVERRIDE'
    if tier_C == 2:              return 'RESTRICT'
    if conf_min < 0.60:          return 'RESTRICT'
    if tier_C == 1 or conf_min < 0.85:
        return 'CAUTION' if D_norm > 0.25 else 'WATCH'
    return 'NORMAL' if D_norm < 0.10 else 'WATCH'


def choose_lambda(state, D_norm, conf_min, tier_C):
    """Materiality-weighted lambda inside the band the formal state permits."""
    lo, hi = LAMBDA_BAND[state]
    if hi == lo:
        return lo
    # materiality: disagreement matters more when risk is high or confidence low
    materiality = min(1.0, 0.5 * D_norm + 0.3 * (tier_C / 3.0) + 0.2 * (1.0 - conf_min))
    return lo + (hi - lo) * materiality


def oracle(t, man):
    R, _ = risk_m.compute_risk(t['obs_dist'], t['ego_speed'])
    v = leg_m.assess_legality(traffic_light=t['light'], ego_speed=t['ego_speed'],
                              speed_limit=SPEED_LIMIT, rss_distance=t['obs_dist'],
                              rss_min=RSS_MIN, pedestrian_crossing=t['ped'],
                              oncoming=t['onc'])
    unsafe = R >= R_HIGH
    illegal = v[man][0] == 'ILLEGAL'
    return ('STOP' if (unsafe or illegal) else 'PROCEED'), unsafe, illegal


def opinion(bridge, perc, man):
    out = bridge.process(perc, {'speed_limit': SPEED_LIMIT})
    ram = out['ram']
    perms = {a for i, a in enumerate(ORDER) if ram['LegalMask'] & (1 << i)}
    tier = ram['RiskTier']
    if tier >= 2:
        perms -= {'PROCEED', 'TURN_LEFT', 'TURN_RIGHT',
                  'LANE_CHANGE_L', 'LANE_CHANGE_R'}
    return perms, tier, (man in perms)


def perceive(t, rng, degrade):
    base = 0.96 - 0.55 * degrade
    jit = lambda c: max(0.05, min(0.99, rng.gauss(c, 0.05 + 0.10 * degrade)))
    d = max(0.5, t['obs_dist'] * rng.gauss(1.0, 0.03 + 0.15 * degrade))
    pf = 0.02 + 0.35 * degrade
    ped = t['ped'] ^ (rng.random() < pf)
    onc = t['onc'] ^ (rng.random() < pf)
    light = t['light']
    if rng.random() < pf * 0.6:
        light = rng.choice([-1, 0, 1, 2])
    cp, cl, co, cd = jit(base), jit(base), jit(base - 0.03), jit(base)
    return ({'obs_dist': (d, cd), 'ego_speed': (t['ego_speed'], 0.95),
             'pedestrian': (ped, cp), 'traffic_light': (light, cl),
             'oncoming': (onc, co)}, min(cp, cl, co, cd), d)


def scene(rng):
    return {'obs_dist': rng.choice([rng.uniform(5, 20), rng.uniform(20, 60), 100.0]),
            'ego_speed': rng.uniform(15, 60), 'light': rng.choice([-1, 0, 1, 2]),
            'ped': rng.random() < 0.30, 'onc': rng.random() < 0.30}


def run(n=4000, degrade=0.0, seed=1):
    rng = random.Random(seed)
    nom = bridge_m.RLCBridge(weather='clear', ablation='no_gate')
    con = bridge_m.RLCBridge(weather='clear', ablation='full')

    acc = {k: dict(unsafe=0, TP=0, FN=0, drop=0.0, harsh=0, n=0)
           for k in ('nominal', 'binary', 'graded')}
    lam_hist = []
    state_hist = {}

    for _ in range(n):
        t = scene(rng)
        man = rng.choice(['PROCEED', 'TURN_LEFT'])
        o_act, o_unsafe, o_illegal = oracle(t, man)
        perc, conf_min, gap_obs = perceive(t, rng, degrade)

        piN, tierN, okN = opinion(nom, perc, man)
        piC, tierC, okC = opinion(con, perc, man)

        uN = target_speed(tierN, gap_obs) if okN else 0.0
        uC = target_speed(tierC, gap_obs) if okC else 0.0

        # ---- normalized disagreement on the continuous command ----
        D = abs(uN - uC)
        D_norm = D / max(SPEED_LIMIT, 1e-6)

        q = formal_state(tierC, okC, conf_min, D_norm)
        lam = choose_lambda(q, D_norm, conf_min, tierC)
        lam_hist.append(lam); state_hist[q] = state_hist.get(q, 0) + 1

        # ---- the three executed commands ----
        u_nominal = uN
        u_binary = uC if (not okC or uC < uN) else uN
        u_graded = (1 - lam) * uN + lam * uC
        # HARD CLIP: never exceed the conservative stopping envelope
        u_graded = min(u_graded, v_safe(gap_obs))
        if not okC:
            u_graded = 0.0                      # maneuver forbidden -> no blending

        for key, u in (('nominal', u_nominal), ('binary', u_binary), ('graded', u_graded)):
            a = acc[key]; a['n'] += 1
            executed_stop = (u < 1.0)
            if o_act == 'STOP' and not executed_stop:
                a['unsafe'] += 1
            # interception bookkeeping relative to the nominal proposal
            nominal_would_be_unsafe = (o_act == 'STOP' and u_nominal >= 1.0)
            if nominal_would_be_unsafe:
                if executed_stop: a['TP'] += 1
                else:             a['FN'] += 1
            # cost: how much speed was given up when the oracle permitted proceeding
            if o_act == 'PROCEED':
                a['drop'] += max(0.0, uN - u)
                if executed_stop and uN > 1.0:
                    a['harsh'] += 1             # full stop although proceeding was fine

    res = {}
    for k, a in acc.items():
        res[k] = {
            'unsafe_rate': a['unsafe'] / a['n'],
            'interception_recall': (a['TP'] / (a['TP'] + a['FN'])) if (a['TP'] + a['FN']) else float('nan'),
            'mean_speed_given_up_kmh': a['drop'] / a['n'],
            'harsh_stop_rate': a['harsh'] / a['n'],
        }
    res['degrade'] = degrade
    res['mean_lambda'] = sum(lam_hist) / len(lam_hist)
    res['state_distribution'] = {k: v / n for k, v in sorted(state_hist.items())}
    return res


if __name__ == '__main__':
    allres = []
    hdr = (f"{'degr':>5} | {'unsafe %':>22} | {'recall %':>16} | "
           f"{'speed given up (km/h)':>24} | {'harsh stop %':>18}")
    print(hdr)
    print(f"{'':>5} | {'nom':>6}{'bin':>8}{'grad':>8} | {'bin':>7}{'grad':>9} | "
          f"{'bin':>11}{'grad':>13} | {'bin':>8}{'grad':>10}")
    print('-' * len(hdr))
    for d in (0.0, 0.2, 0.4, 0.6, 0.8, 1.0):
        r = run(degrade=d)
        allres.append(r)
        print(f"{d:>5.1f} | {100*r['nominal']['unsafe_rate']:>6.2f}"
              f"{100*r['binary']['unsafe_rate']:>8.2f}{100*r['graded']['unsafe_rate']:>8.2f} | "
              f"{100*r['binary']['interception_recall']:>7.1f}"
              f"{100*r['graded']['interception_recall']:>9.1f} | "
              f"{r['binary']['mean_speed_given_up_kmh']:>11.2f}"
              f"{r['graded']['mean_speed_given_up_kmh']:>13.2f} | "
              f"{100*r['binary']['harsh_stop_rate']:>8.2f}"
              f"{100*r['graded']['harsh_stop_rate']:>10.2f}")
    json.dump(allres, open(OUT / 'graded_suppression.json', 'w'), indent=2)
    print(f"\nmean lambda by degradation: "
          f"{[round(r['mean_lambda'],3) for r in allres]}")
    print(f"[OK] {OUT/'graded_suppression.json'}")
