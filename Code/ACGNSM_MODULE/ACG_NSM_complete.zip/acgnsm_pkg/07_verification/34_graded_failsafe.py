"""
34_graded_failsafe.py
=====================
Option A: make the fail-safe graded, so that decision disagreement becomes a
continuous quantity that partial correction can act upon.

The problem with the binary fail-safe
-------------------------------------
Presently, a field whose confidence falls below its threshold is replaced by the
hazard-dominating value outright. For a boolean hazard this asserts the hazard
as fact, which makes the intended maneuver ILLEGAL, which removes the
permission. The conservative channel therefore never says "proceed more slowly";
it says "do not proceed". Measurement confirms the consequence: over 4000
decisions at degradation 0.6, the number in which both channels permit the
maneuver -- the only case in which anything can be blended -- was 1.

The graded fail-safe
--------------------
Distrust becomes a depth rather than a switch:

    delta_i = clamp( (theta_i - c_i) / theta_i , 0, 1 )

For a boolean hazard field the system then holds a BELIEF that the hazard is
present rather than a substituted fact:

    b_i = 1                if the hazard was observed
        = delta_i          if it was not observed but the reading is distrusted

That belief is routed by depth:

  * b_i >= TAU_COMMIT  the evidence is strong enough to assert the hazard, the
                       governing article fires, and the permission is removed
                       exactly as before. Hard legal constraints stay binary.
  * b_i <  TAU_COMMIT  the hazard is not asserted, but the belief inflates the
                       physical risk continuously, lowering the speed target.

Consequently shallow distrust produces a small speed reduction, deep distrust
produces a full override, and the region between them is continuous -- which is
what partial correction requires.

Soundness is preserved in the direction that matters: b_i is monotone
non-decreasing in distrust, risk is monotone non-decreasing in b_i, and the
speed target is monotone non-increasing in risk. Uncertainty can therefore only
slow the vehicle, never speed it up, and at b_i >= TAU_COMMIT the original
hazard-dominating substitution is recovered exactly.
"""
import json, random, importlib.util, math
from pathlib import Path

SRC = Path(__file__).resolve().parent
OUT = Path('/tmp/results'); OUT.mkdir(exist_ok=True)


def _load(n, p):
    s = importlib.util.spec_from_file_location(n, str(p))
    m = importlib.util.module_from_spec(s); s.loader.exec_module(m); return m


risk_m = _load('risk', SRC / '11_risk_assessor.py')
leg_m = _load('leg', SRC / '12_legality_assessor.py')

SPEED_LIMIT, RSS_MIN = 50.0, 15.0
R_LM, R_MH, R_CRIT = 0.30, 0.70, 0.90
TAU_COMMIT = 0.70          # belief at which a hazard is asserted as fact
W_HAZ = 0.55               # weight of believed hazard in the risk score
THETA = {'pedestrian': 0.88, 'oncoming': 0.88, 'traffic_light': 0.92,
         'obs_dist': 0.85}


def depth(theta, c):
    return max(0.0, min(1.0, (theta - c) / theta))


def tier_of(R):
    return 3 if R >= R_CRIT else 2 if R >= R_MH else 1 if R >= R_LM else 0


def target_speed(tier, gap, cruise=SPEED_LIMIT):
    if tier >= 3:  return 0.0
    if tier == 2:  return min(cruise, max(0.0, (gap / 1.5) * 3.6)) if gap > 0 else 8.0
    if tier == 1:  return min(cruise, max(0.0, (gap / 1.2) * 3.6)) if gap > 0 else 18.0
    return cruise


# ----------------------------------------------------------------- channels
def nominal_channel(perc, man, gap):
    """Estimates at face value; no gating."""
    R, _ = risk_m.compute_risk(gap, perc['ego_speed'][0])
    v = leg_m.assess_legality(
        traffic_light=perc['traffic_light'][0], ego_speed=perc['ego_speed'][0],
        speed_limit=SPEED_LIMIT, rss_distance=gap, rss_min=RSS_MIN,
        pedestrian_crossing=perc['pedestrian'][0], oncoming=perc['oncoming'][0])
    ok = v[man][0] != 'ILLEGAL'
    t = tier_of(R)
    return (target_speed(t, gap) if ok else 0.0), ok, t


def conservative_channel(perc, man, gap, graded):
    """Binary fail-safe when graded=False; graded fail-safe when graded=True."""
    beliefs = {}
    for f in ('pedestrian', 'oncoming'):
        val, c = perc[f]
        d = depth(THETA[f], c)
        beliefs[f] = 1.0 if val else (d if not graded else d)
        if not graded:
            beliefs[f] = 1.0 if (val or d > 0) else 0.0     # binary substitution
    # signal: distrust asserts red
    sval, sc = perc['traffic_light']
    sd = depth(THETA['traffic_light'], sc)
    sig_belief = 1.0 if sval == 0 else (1.0 if (not graded and sd > 0) else sd)

    # committed hazards (asserted as fact -> legality may fire)
    ped_fact = beliefs['pedestrian'] >= TAU_COMMIT
    onc_fact = beliefs['oncoming'] >= TAU_COMMIT
    sig_fact = 0 if sig_belief >= TAU_COMMIT else sval

    v = leg_m.assess_legality(
        traffic_light=sig_fact, ego_speed=perc['ego_speed'][0],
        speed_limit=SPEED_LIMIT, rss_distance=gap, rss_min=RSS_MIN,
        pedestrian_crossing=ped_fact, oncoming=onc_fact)
    ok = v[man][0] != 'ILLEGAL'

    # uncommitted belief inflates physical risk continuously
    R, _ = risk_m.compute_risk(gap, perc['ego_speed'][0])
    if graded:
        residual = max([b for b in (beliefs['pedestrian'], beliefs['oncoming'],
                                    sig_belief) if b < TAU_COMMIT] + [0.0])
        R = min(1.0, R + W_HAZ * residual)
    t = tier_of(R)
    return (target_speed(t, gap) if ok else 0.0), ok, t


# ------------------------------------------------------------------ harness
def oracle(t, man):
    R, _ = risk_m.compute_risk(t['obs_dist'], t['ego_speed'])
    v = leg_m.assess_legality(traffic_light=t['light'], ego_speed=t['ego_speed'],
                              speed_limit=SPEED_LIMIT, rss_distance=t['obs_dist'],
                              rss_min=RSS_MIN, pedestrian_crossing=t['ped'],
                              oncoming=t['onc'])
    return 'STOP' if (R >= R_MH or v[man][0] == 'ILLEGAL') else 'PROCEED'


def perceive(t, rng, degrade):
    base = 0.96 - 0.55 * degrade
    jit = lambda c: max(0.05, min(0.99, rng.gauss(c, 0.05 + 0.10 * degrade)))
    d = max(0.5, t['obs_dist'] * rng.gauss(1.0, 0.03 + 0.15 * degrade))
    pf = 0.02 + 0.35 * degrade
    ped = t['ped'] ^ (rng.random() < pf)
    onc = t['onc'] ^ (rng.random() < pf)
    light = t['light']
    if rng.random() < pf * 0.6: light = rng.choice([-1, 0, 1, 2])
    return {'obs_dist': (d, jit(base)), 'ego_speed': (t['ego_speed'], 0.95),
            'pedestrian': (ped, jit(base)), 'traffic_light': (light, jit(base)),
            'oncoming': (onc, jit(base - 0.03))}, d


def scene(rng):
    return {'obs_dist': rng.choice([rng.uniform(5, 20), rng.uniform(20, 60), 100.0]),
            'ego_speed': rng.uniform(15, 60), 'light': rng.choice([-1, 0, 1, 2]),
            'ped': rng.random() < 0.30, 'onc': rng.random() < 0.30}


def run(n=4000, degrade=0.6, seed=1, graded=True, lam=None):
    rng = random.Random(seed)
    blend = both = 0
    unsafe = TP = FN = harsh = 0
    drop = 0.0
    for _ in range(n):
        t = scene(rng); man = rng.choice(['PROCEED', 'TURN_LEFT'])
        o = oracle(t, man)
        perc, gap = perceive(t, rng, degrade)
        uN, okN, tN = nominal_channel(perc, man, gap)
        uC, okC, tC = conservative_channel(perc, man, gap, graded)
        if okN and okC:
            both += 1
            if abs(uN - uC) > 0.5: blend += 1
        L = 1.0 if lam is None else lam
        u = uN - L * (uN - uC) if okC else 0.0
        stop = u < 1.0
        if o == 'STOP' and not stop: unsafe += 1
        if o == 'STOP' and uN >= 1.0:
            TP += 1 if stop else 0; FN += 0 if stop else 1
        if o == 'PROCEED':
            drop += max(0.0, uN - u)
            if stop and uN > 1.0: harsh += 1
    return dict(degrade=degrade, graded=graded, lam=lam,
                both_permit=both / n, blendable=blend / n,
                unsafe=unsafe / n,
                recall=(TP / (TP + FN)) if (TP + FN) else float('nan'),
                speed_given_up=drop / n, harsh=harsh / n)


if __name__ == '__main__':
    print("=== does the graded fail-safe create blendable disagreement? ===")
    print(f"{'degr':>5}{'binary both%':>14}{'binary blend%':>15}"
          f"{'graded both%':>14}{'graded blend%':>15}")
    print('-' * 63)
    for d in (0.2, 0.4, 0.6, 0.8, 1.0):
        b = run(degrade=d, graded=False); g = run(degrade=d, graded=True)
        print(f"{d:>5.1f}{100*b['both_permit']:>14.1f}{100*b['blendable']:>15.2f}"
              f"{100*g['both_permit']:>14.1f}{100*g['blendable']:>15.2f}")

    print("\n=== lambda sweep on the GRADED architecture (degradation 0.6) ===")
    print(f"{'lambda':>7}{'unsafe %':>10}{'recall %':>10}{'given up':>10}{'harsh %':>9}")
    print('-' * 46)
    rows = []
    for lam in (0.0, 0.25, 0.5, 0.75, 1.0):
        r = run(degrade=0.6, graded=True, lam=lam); rows.append(r)
        print(f"{lam:>7.2f}{100*r['unsafe']:>10.2f}{100*r['recall']:>10.1f}"
              f"{r['speed_given_up']:>10.2f}{100*r['harsh']:>9.2f}")
    json.dump(rows, open(OUT / 'graded_failsafe.json', 'w'), indent=2)
    print(f"\n[OK] {OUT/'graded_failsafe.json'}")
