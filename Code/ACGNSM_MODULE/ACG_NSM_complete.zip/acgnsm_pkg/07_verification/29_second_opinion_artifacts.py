import json
from pathlib import Path
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

OUT = Path('/tmp/results')
res = json.load(open(OUT/'second_opinion.json'))
d = [r['degrade'] for r in res]
g = lambda k: [100*r[k] for r in res]

fig, ax = plt.subplots(1, 3, figsize=(13.2, 3.7))

# (a) the win: interception + residual
ax[0].plot(d, g('nominal_unsafe_rate'), 'o--', color='#D62728', lw=2.2, ms=6,
           label='nominal unsafe (before arbitration)')
ax[0].plot(d, g('residual_unsafe_rate'), 'o-', color='#1A9850', lw=2.4, ms=6,
           label='residual unsafe (after arbitration)')
ax[0].set_title('(a) Unsafe actions intercepted', fontsize=11)
ax[0].set_xlabel('perception degradation', fontsize=10)
ax[0].set_ylabel('rate (%)', fontsize=10)
ax[0].grid(alpha=.3); ax[0].legend(fontsize=8.5)

# (b) interception recall vs override precision
ax[1].plot(d, g('interception_recall'), 'o-', color='#1A9850', lw=2.4, ms=6,
           label='interception recall')
ax[1].plot(d, g('override_precision'), 's-', color='#F0A24B', lw=2.2, ms=6,
           label='override precision')
ax[1].plot(d, g('false_override_rate'), '^--', color='#D62728', lw=2.0, ms=6,
           label='false-override rate')
ax[1].set_title('(b) Arbitration quality', fontsize=11)
ax[1].set_xlabel('perception degradation', fontsize=10)
ax[1].set_ylabel('rate (%)', fontsize=10)
ax[1].set_ylim(-3, 103); ax[1].grid(alpha=.3); ax[1].legend(fontsize=8.5)

# (c) disagreement volume
w = 0.06
ax[2].bar(np.array(d)-w/2, g('disagreement_rate'), width=w, color='#4C78A8',
          label='permission disagreement $\\Delta_{perm}\\neq\\emptyset$')
ax[2].bar(np.array(d)+w/2, g('override_rate'), width=w, color='#8B5CF6',
          label='override $\\Delta_{act}=1$')
ax[2].set_title('(c) How often the opinions differ', fontsize=11)
ax[2].set_xlabel('perception degradation', fontsize=10)
ax[2].set_ylabel('share of decisions (%)', fontsize=10)
ax[2].grid(alpha=.25, axis='y'); ax[2].legend(fontsize=8.5)

plt.tight_layout()
plt.savefig(OUT/'fig_second_opinion.png', dpi=200, bbox_inches='tight')
plt.savefig(OUT/'fig_second_opinion.pdf', bbox_inches='tight')
print('[OK] figure')

rows = []
for r in res:
    rows.append(f"{r['degrade']:.1f} & {100*r['disagreement_rate']:.1f} & "
                f"{100*r['override_rate']:.1f} & {100*r['nominal_unsafe_rate']:.2f} & "
                f"{100*r['interception_recall']:.1f} & {100*r['override_precision']:.1f} & "
                f"{100*r['false_override_rate']:.1f} & "
                f"\\textbf{{{100*r['residual_unsafe_rate']:.2f}}} \\\\")
tex = r"""\begin{table*}[t]
\centering
\caption{Runtime second-opinion arbitration. For each scene both opinions are computed from the same
evidence: the nominal opinion uses the perception estimates directly, the conservative opinion applies
calibrated gating and fail-safe substitution. An oracle over the true scene scores each arbitration.
\emph{Interception recall} is the fraction of unsafe nominal actions the second opinion blocked;
\emph{override precision} the fraction of overrides that were necessary; \emph{false-override rate} the
fraction of safe nominal actions blocked unnecessarily. $4000$ decisions per level.}
\label{tab:secondopinion}
\small
\begin{tabular}{lccccccc}
\toprule
Degr. & Disagree. & Override & Nominal unsafe & Intercept. & Override & False-override & Residual unsafe \\
      & (\%)      & (\%)     & (\%)           & recall (\%) & prec. (\%) & (\%)          & (\%) \\
\midrule
""" + "\n".join(rows) + r"""
\bottomrule
\end{tabular}
\end{table*}"""
(OUT/'second_opinion_table.tex').write_text(tex)
print('[OK] table')
