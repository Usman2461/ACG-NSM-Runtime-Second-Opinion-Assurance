"""
23_verify_antitonicity.py
=========================
Exhaustive verification of the antitonicity property required by Proposition 1:

        s <= s'   ==>   Pi(s') subseteq Pi(s)

("a more hazardous scene never grants more permissions")

The permission map Pi is taken directly from 12_legality_assessor.py via
legal_action_mask(); an action is PERMITTED iff its verdict is not ILLEGAL.

The hazard order is a product order over six fields, each a finite chain:

    traffic_light   : none(-1) <= green(1) <= yellow(2) <= red(0)
    pedestrian      : False <= True
    oncoming        : False <= True
    lane_left       : dashed <= solid
    lane_right      : dashed <= solid
    rss_violation   : False <= True        (following distance below minimum)
    speeding        : False <= True        (ego speed above posted limit)

The domain is finite, so the check is EXHAUSTIVE, not sampled: every ordered
pair (s, s') with s <= s' is tested.

Outputs
    results/antitonicity_report.json   machine-readable result
    results/antitonicity_table.tex     LaTeX table for the paper
    results/fig_antitonicity.png/.pdf  figure for the paper

Usage
    python src/23_verify_antitonicity.py
"""
import json, itertools, importlib.util, sys
from pathlib import Path

SRC = Path(__file__).resolve().parent
OUT = SRC.parent / 'results'
OUT.mkdir(exist_ok=True)


def _load(name, path):
    spec = importlib.util.spec_from_file_location(name, str(path))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


leg = _load('legality', SRC / '12_legality_assessor.py')

# ---------------------------------------------------------------- field chains
# each chain is ordered from LEAST to MOST hazardous
LIGHT = [-1, 1, 2, 0]          # none <= green <= yellow <= red
BOOL = [False, True]
LANE = ['dashed', 'solid']

FIELDS = ['traffic_light', 'pedestrian', 'oncoming',
          'lane_left', 'lane_right', 'rss_violation', 'speeding']
CHAINS = {
    'traffic_light': LIGHT,
    'pedestrian':    BOOL,
    'oncoming':      BOOL,
    'lane_left':     LANE,
    'lane_right':    LANE,
    'rss_violation': BOOL,
    'speeding':      BOOL,
}
RANK = {f: {v: i for i, v in enumerate(c)} for f, c in CHAINS.items()}

ACTIONS = ['PROCEED', 'TURN_LEFT', 'TURN_RIGHT',
           'LANE_CHANGE_L', 'LANE_CHANGE_R', 'STOP']


def scenes():
    """Enumerate the entire finite scene space."""
    for combo in itertools.product(*(CHAINS[f] for f in FIELDS)):
        yield dict(zip(FIELDS, combo))


def leq(a, b):
    """Product order: a <= b iff a_i <= b_i on every chain."""
    return all(RANK[f][a[f]] <= RANK[f][b[f]] for f in FIELDS)


def permissions(s):
    """Pi(s): set of permitted actions, straight from the legality assessor."""
    v = leg.assess_legality(
        traffic_light=s['traffic_light'],
        ego_speed=60.0 if s['speeding'] else 40.0,
        speed_limit=50.0,
        rss_distance=4.0 if s['rss_violation'] else 30.0,
        rss_min=15.0,
        lane_marking_left=s['lane_left'],
        lane_marking_right=s['lane_right'],
        pedestrian_crossing=s['pedestrian'],
        oncoming=s['oncoming'],
    )
    mask, order = leg.legal_action_mask(v)
    return frozenset(order[i] for i in range(len(order)) if mask & (1 << i))


def fmt(s):
    lname = {-1: 'none', 1: 'green', 2: 'yellow', 0: 'red'}[s['traffic_light']]
    return (f"light={lname}, ped={int(s['pedestrian'])}, onc={int(s['oncoming'])}, "
            f"lnL={s['lane_left'][:4]}, lnR={s['lane_right'][:4]}, "
            f"rss={int(s['rss_violation'])}, spd={int(s['speeding'])}")


def main():
    S = list(scenes())
    PI = {i: permissions(s) for i, s in enumerate(S)}
    print(f"scene space |S| = {len(S)}")

    comparable = 0
    violations = []          # (i, j, actions gained)
    per_action = {a: 0 for a in ACTIONS}
    per_field = {f: 0 for f in FIELDS}

    for i, si in enumerate(S):
        for j, sj in enumerate(S):
            if i == j or not leq(si, sj):
                continue
            comparable += 1
            gained = PI[j] - PI[i]        # permitted in the MORE hazardous scene
            if gained:
                violations.append((i, j, sorted(gained)))
                for a in gained:
                    per_action[a] += 1
                for f in FIELDS:
                    if RANK[f][si[f]] < RANK[f][sj[f]]:
                        per_field[f] += 1

    print(f"comparable ordered pairs tested = {comparable}")
    print(f"antitonicity violations         = {len(violations)}")

    # ---- minimal witnesses: violating pairs differing in exactly one field ----
    minimal = []
    for i, j, gained in violations:
        diffs = [f for f in FIELDS if S[i][f] != S[j][f]]
        if len(diffs) == 1:
            minimal.append((i, j, gained, diffs[0]))

    print(f"minimal (single-field) witnesses = {len(minimal)}")
    seen = set()
    uniq = []
    for i, j, gained, f in minimal:
        key = (f, S[i][f], S[j][f], tuple(gained))
        if key in seen:
            continue
        seen.add(key)
        uniq.append((i, j, gained, f))

    print(f"\n=== distinct minimal violation patterns ({len(uniq)}) ===")
    for i, j, gained, f in uniq:
        print(f"  field '{f}': {S[i][f]} -> {S[j][f]}   gains {gained}")
        print(f"      less hazardous: {fmt(S[i])}")
        print(f"      more hazardous: {fmt(S[j])}")
        print(f"      Pi(low)={sorted(PI[i])}")
        print(f"      Pi(high)={sorted(PI[j])}")
        print()

    report = {
        'scene_space_size': len(S),
        'comparable_pairs_tested': comparable,
        'violations': len(violations),
        'verified': len(violations) == 0,
        'violations_by_action': per_action,
        'violations_by_field': per_field,
        'minimal_patterns': [
            {'field': f, 'from': str(S[i][f]), 'to': str(S[j][f]),
             'actions_gained': g,
             'scene_low': fmt(S[i]), 'scene_high': fmt(S[j]),
             'pi_low': sorted(PI[i]), 'pi_high': sorted(PI[j])}
            for i, j, g, f in uniq
        ],
    }
    (OUT / 'antitonicity_report.json').write_text(json.dumps(report, indent=2))
    print(f"[OK] wrote {OUT/'antitonicity_report.json'}")
    return report, S, PI, uniq


if __name__ == '__main__':
    main()
