"""
30_fn_and_latency.py
====================
Two experiments closing gaps identified in review.

(A) ADDED LATENCY OF THE SECOND OPINION
    The arbitration architecture computes two opinions per tick instead of one.
    We measure the cost directly: nominal-only, conservative-only, and the full
    dual-opinion cycle including the disagreement computation.

(B) MISSED DETECTIONS (FALSE NEGATIVES)
    The confidence gate is justified by the detector's residual miss rate, but
    every experiment so far degrades the CONFIDENCE of an object that was still
    detected. A complete miss is different and more dangerous: the object is
    simply absent from the perception output.

    We distinguish two designs for the boolean presence fields:

      naive absence    a non-detection is reported as (absent, high confidence).
                       The gate cannot fire, because the field looks reliable.

      evidence-aware   a non-detection is reported as (absent, c_absent) where
                       c_absent reflects how well the region was actually
                       observed. Under occlusion, range, or weather the absence
                       claim is itself low-confidence, so the gate fires and the
                       fail-safe substitution applies.

    The experiment quantifies the difference. This isolates a design requirement
    that the confidence-gating argument depends on but which detector confidence
    alone does not supply.
"""
import json, random, time, importlib.util
from pathlib import Path

SRC = Path(__file__).resolve().parent
OUT = Path('/tmp/results'); OUT.mkdir(exist_ok=True)


def _load(n, p):
    s = importlib.util.spec_from_file_location(n, str(p))
    m = importlib.util.module_from_spec(s); s.loader.exec_module(m); return m


risk_m = _load('risk', SRC / '11_risk_assessor.py')
leg_m = _load('leg', SRC / '12_legality_assessor.py')
bridge_m = _load('bridge', SRC / '13_rlc_bridge.py')

SPEED_LIMIT, RSS_MIN, R_HIGH = 50.0, 15.0, 0.70
ORDER = ['PROCEED', 'TURN_LEFT', 'TURN_RIGHT',
         'LANE_CHANGE_L', 'LANE_CHANGE_R', 'STOP']


def oracle(t, man):
    R, _ = risk_m.compute_risk(t['obs_dist'], t['ego_speed'])
    v = leg_m.assess_legality(traffic_light=t['light'], ego_speed=t['ego_speed'],
                              speed_limit=SPEED_LIMIT, rss_distance=t['obs_dist'],
                              rss_min=RSS_MIN, pedestrian_crossing=t['ped'],
                              oncoming=t['onc'])
    if R >= R_HIGH or v[man][0] == 'ILLEGAL':
        return 'STOP'
    return 'PROCEED'


def opinion(bridge, perc, man):
    out = bridge.process(perc, {'speed_limit': SPEED_LIMIT})
    ram = out['ram']
    perms = {a for i, a in enumerate(ORDER) if ram['LegalMask'] & (1 << i)}
    if ram['RiskTier'] >= 2:
        perms -= {'PROCEED', 'TURN_LEFT', 'TURN_RIGHT',
                  'LANE_CHANGE_L', 'LANE_CHANGE_R'}
    return perms, (man if man in perms else 'STOP')


def scene(rng):
    return {'obs_dist': rng.choice([rng.uniform(5, 20), rng.uniform(20, 60), 100.0]),
            'ego_speed': rng.uniform(15, 60), 'light': rng.choice([-1, 0, 1, 2]),
            'ped': rng.random() < 0.35, 'onc': rng.random() < 0.30}


# =====================================================================  (A)
def latency(n=4000):
    rng = random.Random(7)
    nom = bridge_m.RLCBridge(weather='clear', ablation='no_gate')
    con = bridge_m.RLCBridge(weather='clear', ablation='full')
    scenes = []
    for _ in range(n):
        t = scene(rng)
        scenes.append({'obs_dist': (t['obs_dist'], 0.9), 'ego_speed': (t['ego_speed'], 0.95),
                       'pedestrian': (t['ped'], 0.9), 'traffic_light': (t['light'], 0.9),
                       'oncoming': (t['onc'], 0.9)})

    def timed(fn):
        fn(scenes[0])                                    # warm up
        t0 = time.perf_counter()
        for p in scenes:
            fn(p)
        return 1000.0 * (time.perf_counter() - t0) / len(scenes)

    ms_nom = timed(lambda p: opinion(nom, p, 'PROCEED'))
    ms_con = timed(lambda p: opinion(con, p, 'PROCEED'))

    def dual(p):
        piN, aN = opinion(nom, p, 'PROCEED')
        piC, aC = opinion(con, p, 'PROCEED')
        _ = piN - piC
        _ = aN not in piC
        return aN if aN in piC else aC
    ms_dual = timed(dual)

    return {'nominal_only_ms': ms_nom, 'conservative_only_ms': ms_con,
            'dual_opinion_ms': ms_dual,
            'added_ms': ms_dual - ms_con,
            'added_pct_vs_conservative': 100 * (ms_dual - ms_con) / ms_con}


# =====================================================================  (B)
def fn_experiment(n=4000, miss_rate=0.088, seed=3):
    """miss_rate default = 1 - recall(0.912) measured on the detector."""
    rng = random.Random(seed)
    con = bridge_m.RLCBridge(weather='clear', ablation='full')
    res = {}
    for design in ('naive_absence', 'evidence_aware'):
        unsafe = conserv = correct = 0
        missed_events = 0
        for _ in range(n):
            t = scene(rng); man = 'PROCEED'
            o = oracle(t, man)
            ped_true = t['ped']
            missed = ped_true and (rng.random() < miss_rate)
            if missed:
                missed_events += 1
                ped_obs = False
                # naive: a non-detection is asserted with the detector's usual
                # high confidence, so the gate has nothing to act on.
                # evidence-aware: absence confidence reflects observation quality.
                c_ped = 0.95 if design == 'naive_absence' else rng.uniform(0.30, 0.60)
            else:
                ped_obs = ped_true
                c_ped = 0.95
            perc = {'obs_dist': (t['obs_dist'], 0.95),
                    'ego_speed': (t['ego_speed'], 0.95),
                    'pedestrian': (ped_obs, c_ped),
                    'traffic_light': (t['light'], 0.95),
                    'oncoming': (t['onc'], 0.92)}
            _, a = opinion(con, perc, man)
            if o == 'STOP' and a != 'STOP':   unsafe += 1
            elif o == 'PROCEED' and a == 'STOP': conserv += 1
            else: correct += 1
        res[design] = {'unsafe_rate': unsafe / n, 'conservative_rate': conserv / n,
                       'correct_rate': correct / n, 'miss_events': missed_events}
    return res


if __name__ == '__main__':
    print("=== (A) added latency of the dual-opinion cycle ===")
    L = latency()
    for k, v in L.items():
        print(f"  {k:<28} {v:8.4f}")

    print("\n=== (B) missed detections (false negatives) ===")
    print(f"  detector miss rate = 8.8% (1 - measured recall 0.912)\n")
    F = fn_experiment()
    print(f"  {'design':<18}{'unsafe':>9}{'conservative':>14}{'correct':>10}")
    print("  " + "-" * 51)
    for k, v in F.items():
        print(f"  {k:<18}{v['unsafe_rate']:>8.2%}{v['conservative_rate']:>14.2%}"
              f"{v['correct_rate']:>10.2%}")
    red = 1 - F['evidence_aware']['unsafe_rate'] / max(F['naive_absence']['unsafe_rate'], 1e-9)
    print(f"\n  unsafe-rate reduction from evidence-aware absence: {red:.1%}")

    json.dump({'latency': L, 'false_negatives': F},
              open(OUT / 'fn_latency.json', 'w'), indent=2)
    print(f"\n[OK] {OUT/'fn_latency.json'}")
