"""
28_second_opinion.py
====================
The experiment the second-opinion framing requires but does not yet have.

For each sampled TRUE scene we compute, from the SAME perception evidence:

  nominal opinion    Pi_N, a_N   -- scene estimates used at face value (no gating)
  conservative       Pi_C, a_C   -- after calibrated gating + fail-safe substitution

and then the disagreement quantities that the framing makes central:

  Delta_perm = Pi_N \\ Pi_C      permissions granted only by the optimistic path
  Delta_act  = 1[a_N not in Pi_C]  the nominal candidate is blocked  -> OVERRIDE

An oracle computes the correct action from the true scene, which lets every
arbitration event be scored:

  interception (TP)   nominal unsafe, second opinion overrode it      <- the win
  missed unsafe (FN)  nominal unsafe, second opinion let it through   <- the failure
  false override (FP) nominal safe,   second opinion overrode anyway  <- the cost
  correct accept (TN) nominal safe,   second opinion accepted

Reported metrics
  disagreement rate, override rate,
  unsafe-action interception recall = TP/(TP+FN),
  override precision                = TP/(TP+FP),
  false-override rate               = FP/(FP+TN),
  residual unsafe rate after arbitration.

Outputs
  results/second_opinion.json
  results/fig_second_opinion.png/.pdf
  results/second_opinion_table.tex
"""
import json, random, importlib.util
from pathlib import Path

SRC = Path(__file__).resolve().parent
OUT = SRC.parent / 'results'
OUT.mkdir(exist_ok=True)


def _load(name, path):
    spec = importlib.util.spec_from_file_location(name, str(path))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


risk_m = _load('risk', SRC / '11_risk_assessor.py')
leg_m = _load('leg', SRC / '12_legality_assessor.py')
bridge_m = _load('bridge', SRC / '13_rlc_bridge.py')

R_HIGH = 0.70
SPEED_LIMIT = 50.0
RSS_MIN = 15.0
ORDER = ['PROCEED', 'TURN_LEFT', 'TURN_RIGHT',
         'LANE_CHANGE_L', 'LANE_CHANGE_R', 'STOP']


# --------------------------------------------------------------- ground truth
def oracle(true_s, maneuver):
    R, _ = risk_m.compute_risk(true_s['obs_dist'], true_s['ego_speed'])
    v = leg_m.assess_legality(
        traffic_light=true_s['light'], ego_speed=true_s['ego_speed'],
        speed_limit=SPEED_LIMIT, rss_distance=true_s['obs_dist'],
        rss_min=RSS_MIN, pedestrian_crossing=true_s['ped'],
        oncoming=true_s['onc'])
    unsafe = R >= R_HIGH
    illegal = v[maneuver][0] == 'ILLEGAL'
    if unsafe and illegal: return 'STOP', 'both'
    if unsafe:             return 'STOP', 'risk'
    if illegal:            return 'STOP', 'legality'
    return 'PROCEED', 'none'


# ------------------------------------------------------------------ evidence
def perceive(true_s, rng, degrade):
    base = 0.96 - 0.55 * degrade
    jit = lambda c: max(0.05, min(0.99, rng.gauss(c, 0.05 + 0.10 * degrade)))
    d = max(0.5, true_s['obs_dist'] * rng.gauss(1.0, 0.03 + 0.15 * degrade))
    pf = 0.02 + 0.35 * degrade
    ped = true_s['ped'] ^ (rng.random() < pf)
    onc = true_s['onc'] ^ (rng.random() < pf)
    light = true_s['light']
    if rng.random() < pf * 0.6:
        light = rng.choice([-1, 0, 1, 2])
    return {'obs_dist': (d, jit(base)), 'ego_speed': (true_s['ego_speed'], 0.95),
            'pedestrian': (ped, jit(base)), 'traffic_light': (light, jit(base)),
            'oncoming': (onc, jit(base - 0.03))}


def opinion(bridge, perc, maneuver):
    """Return (permission set, candidate action, tier) from a bridge config."""
    out = bridge.process(perc, {'speed_limit': SPEED_LIMIT})
    ram = out['ram']
    perms = {a for i, a in enumerate(ORDER) if ram['LegalMask'] & (1 << i)}
    tier = ram['RiskTier']
    if tier >= 2:                      # physical risk removes progress actions
        perms = perms - {'PROCEED', 'TURN_LEFT', 'TURN_RIGHT',
                         'LANE_CHANGE_L', 'LANE_CHANGE_R'}
    act = maneuver if maneuver in perms else 'STOP'
    return perms, act, tier


def sample_scene(rng):
    return {'obs_dist': rng.choice([rng.uniform(5, 20), rng.uniform(20, 60), 100.0]),
            'ego_speed': rng.uniform(15, 60),
            'light': rng.choice([-1, 0, 1, 2]),
            'ped': rng.random() < 0.30,
            'onc': rng.random() < 0.30}


def run(n=4000, degrade=0.0, seed=1):
    rng = random.Random(seed)
    nominal = bridge_m.RLCBridge(weather='clear', ablation='no_gate')
    conserv = bridge_m.RLCBridge(weather='clear', ablation='full')

    TP = FN = FP = TN = 0
    disagree = override = 0
    delta_sizes = []
    causes = {}
    residual_unsafe = 0

    for _ in range(n):
        true_s = sample_scene(rng)
        man = rng.choice(['PROCEED', 'TURN_LEFT'])
        o_act, o_cause = oracle(true_s, man)
        perc = perceive(true_s, rng, degrade)

        piN, aN, _ = opinion(nominal, perc, man)
        piC, aC, _ = opinion(conserv, perc, man)

        d_perm = piN - piC
        d_act = aN not in piC
        if d_perm:
            disagree += 1
            delta_sizes.append(len(d_perm))
        if d_act:
            override += 1

        # would the NOMINAL action have been unsafe?
        nominal_unsafe = (o_act == 'STOP' and aN != 'STOP')
        if nominal_unsafe and d_act:      TP += 1     # intercepted
        elif nominal_unsafe and not d_act: FN += 1    # missed
        elif (not nominal_unsafe) and d_act: FP += 1  # unnecessary override
        else: TN += 1

        # what actually executed under the arbiter
        a_exec = aN if not d_act else aC
        if o_act == 'STOP' and a_exec != 'STOP':
            residual_unsafe += 1
        if d_act:
            causes[o_cause] = causes.get(o_cause, 0) + 1

    tot = TP + FN + FP + TN
    return {
        'degrade': degrade, 'n': tot,
        'disagreement_rate': disagree / tot,
        'override_rate': override / tot,
        'mean_delta_size': (sum(delta_sizes) / len(delta_sizes)) if delta_sizes else 0.0,
        'TP_intercepted': TP, 'FN_missed': FN,
        'FP_false_override': FP, 'TN_correct_accept': TN,
        'interception_recall': TP / (TP + FN) if (TP + FN) else float('nan'),
        'override_precision': TP / (TP + FP) if (TP + FP) else float('nan'),
        'false_override_rate': FP / (FP + TN) if (FP + TN) else float('nan'),
        'nominal_unsafe_rate': (TP + FN) / tot,
        'residual_unsafe_rate': residual_unsafe / tot,
        'override_causes': causes,
    }


if __name__ == '__main__':
    res = [run(degrade=d) for d in (0.0, 0.2, 0.4, 0.6, 0.8, 1.0)]
    hdr = f"{'degr':>5} {'disag':>7} {'overr':>7} {'nomUnsf':>8} {'recall':>7} {'prec':>7} {'FOR':>7} {'resid':>7}"
    print(hdr); print('-' * len(hdr))
    for r in res:
        print(f"{r['degrade']:>5.1f} {r['disagreement_rate']:>7.1%} "
              f"{r['override_rate']:>7.1%} {r['nominal_unsafe_rate']:>8.2%} "
              f"{r['interception_recall']:>7.1%} {r['override_precision']:>7.1%} "
              f"{r['false_override_rate']:>7.1%} {r['residual_unsafe_rate']:>7.2%}")
    (OUT / 'second_opinion.json').write_text(json.dumps(res, indent=2))
    print(f"\n[OK] {OUT/'second_opinion.json'}")
