"""Paper artifacts for the affirmative decision-correctness evaluation."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

OUT = Path('/tmp/results')
res = json.load(open(OUT / 'decision_correctness.json'))

deg = [r['degrade'] for r in res['sweep']]
def series(key, sweep):
    return [100 * r['rates'][key] for r in res[sweep]]

fig, axes = plt.subplots(1, 3, figsize=(13.0, 3.7))

# ---- (a) unsafe decisions: the headline ----
ax = axes[0]
ax.plot(deg, series('UNSAFE', 'nogate_sweep'), 'o--', color='#D62728', lw=2.2,
        ms=6, label='ungated baseline')
ax.plot(deg, series('UNSAFE', 'sweep'), 'o-', color='#1A9850', lw=2.4,
        ms=6, label='ACG-NSM (gated)')
ax.set_title('(a) Unsafe decisions', fontsize=11)
ax.set_xlabel('perception degradation', fontsize=10)
ax.set_ylabel('unsafe-decision rate (%)', fontsize=10)
ax.set_ylim(-0.4, 9); ax.grid(alpha=.3); ax.legend(fontsize=9)
ax.annotate('0.00% at every\ndegradation level', xy=(0.6, 0.05), xytext=(0.42, 2.6),
            fontsize=8.5, color='#1A9850',
            arrowprops=dict(arrowstyle='->', color='#1A9850', lw=1.2))

# ---- (b) the cost: conservatism ----
ax = axes[1]
ax.plot(deg, series('CONSERVATIVE', 'nogate_sweep'), 'o--', color='#D62728',
        lw=2.2, ms=6, label='ungated baseline')
ax.plot(deg, series('CONSERVATIVE', 'sweep'), 'o-', color='#1A9850', lw=2.4,
        ms=6, label='ACG-NSM (gated)')
ax.set_title('(b) Cost: unnecessary caution', fontsize=11)
ax.set_xlabel('perception degradation', fontsize=10)
ax.set_ylabel('conservative-decision rate (%)', fontsize=10)
ax.grid(alpha=.3); ax.legend(fontsize=9, loc='lower right')

# ---- (c) outcome composition, gated ----
ax = axes[2]
keys = ['CORRECT-PROCEED', 'CORRECT-STOP', 'CONSERVATIVE', 'UNSAFE']
cols = ['#4C78A8', '#54A24B', '#F0A24B', '#D62728']
bottom = np.zeros(len(deg))
for k, c in zip(keys, cols):
    v = np.array(series(k, 'sweep'))
    ax.bar(deg, v, width=0.13, bottom=bottom, color=c,
           label=k.replace('-', ' ').lower())
    bottom += v
ax.set_title('(c) ACG-NSM outcome composition', fontsize=11)
ax.set_xlabel('perception degradation', fontsize=10)
ax.set_ylabel('share of decisions (%)', fontsize=10)
ax.set_ylim(0, 100); ax.legend(fontsize=7.6, loc='lower left', ncol=2)
ax.grid(alpha=.25, axis='y')

plt.tight_layout()
plt.savefig(OUT / 'fig_decision_correctness.png', dpi=200, bbox_inches='tight')
plt.savefig(OUT / 'fig_decision_correctness.pdf', bbox_inches='tight')
print('[OK] figure')

# ---------------- LaTeX table ----------------
rows = []
for rg, rn in zip(res['sweep'], res['nogate_sweep']):
    d = rg['degrade']
    cg = 100 * (rg['rates']['CORRECT-PROCEED'] + rg['rates']['CORRECT-STOP'])
    cn = 100 * (rn['rates']['CORRECT-PROCEED'] + rn['rates']['CORRECT-STOP'])
    rows.append((d, cn, 100 * rn['rates']['CONSERVATIVE'], 100 * rn['rates']['UNSAFE'],
                 cg, 100 * rg['rates']['CONSERVATIVE'], 100 * rg['rates']['UNSAFE']))

tex = [r"""\begin{table*}[t]
\centering
\caption{Affirmative decision evaluation. For each sampled scene the correct action is
computed from the \emph{true} state by an oracle applying the same physical criterion
and rule set; the system sees only noisy perception. A decision is \emph{unsafe} when
the oracle requires stopping and the system proceeds, and \emph{conservative} when the
oracle permits proceeding and the system stops. Perception degradation scales both the
value-error rate and the confidence loss. Each row aggregates $4000$ decisions.}
\label{tab:correctness}
\small
\begin{tabular}{lcccccc}
\toprule
& \multicolumn{3}{c}{Ungated baseline} & \multicolumn{3}{c}{\sysname{} (gated)} \\
\cmidrule(lr){2-4}\cmidrule(lr){5-7}
Degradation & correct (\%) & conservative (\%) & \textbf{unsafe (\%)}
            & correct (\%) & conservative (\%) & \textbf{unsafe (\%)} \\
\midrule"""]
for d, cn, vn, un, cg, vg, ug in rows:
    tex.append(f"{d:.1f} & {cn:.1f} & {vn:.1f} & \\textbf{{{un:.2f}}} & "
               f"{cg:.1f} & {vg:.1f} & \\textbf{{{ug:.2f}}} \\\\")
tex.append(r"""\bottomrule
\end{tabular}
\end{table*}""")
(OUT / 'decision_correctness_table.tex').write_text('\n'.join(tex))
print('[OK] table')
