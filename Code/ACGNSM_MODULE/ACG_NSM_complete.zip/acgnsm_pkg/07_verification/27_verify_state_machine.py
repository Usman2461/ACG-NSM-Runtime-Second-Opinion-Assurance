"""
27_verify_state_machine.py
==========================
Exhaustive verification of the compiled decision state machine.

The machine is finite (8 states, 10 events, 26 transitions), so its entire
reachable behaviour can be enumerated. We therefore perform genuine exhaustive
model checking rather than testing: complete reachability analysis, then
evaluation of temporal safety and liveness properties over every reachable
state and every finite path prefix up to the diameter of the state graph.

We additionally perform TRANSLATION VALIDATION: the compiled C artifact
(libstm.so) is executed against an independent reference model derived from the
transition table, over every reachable (state, event) pair, and the two are
required to agree on both the successor state and the emitted action. This is
what licenses the claim that the deployed artifact realises the verified model.

Outputs
    results/stm_verification.json
    results/stm_properties_table.tex
"""
import json, itertools, ctypes
from pathlib import Path
from collections import deque

OUT = Path(__file__).resolve().parent.parent / 'results'
OUT.mkdir(exist_ok=True)

STATES = {0: 'INIT', 1: 'APPROACH', 2: 'BRAKE_HOLD', 3: 'ASSESS_YIELD',
          4: 'YIELD_WAIT', 5: 'TURNING', 6: 'SLOW_FAULT', 7: 'FAULT_EXIT'}
EVENTS = {0: 'EV_START', 1: 'EV_STOPLINE_REACH', 2: 'EV_SIG_RED',
          3: 'EV_SIG_GREEN_LT', 4: 'EV_SIG_YELLOW', 5: 'EV_YIELD_BLOCK',
          6: 'EV_YIELD_CLEAR', 7: 'EV_TMR_EXPIRED', 8: 'EV_TMR_LOW',
          9: 'EV_INTSEC_EXIT'}

# ------------------------------------------------------------------ the model
# (src, event) -> (dst, actions, guard)   extracted from the generated C
T = {
    (0, 0): (1, ['InitAll'], None),
    (1, 1): (2, ['Brake', 'StartSigTmr'], None),
    (1, 2): (1, ['SlowDown'], None),
    (2, 2): (2, ['Hold'], None),
    (3, 2): (2, ['Brake'], None),
    (4, 2): (4, ['Hold'], None),
    (6, 2): (2, [], None),
    (2, 3): (3, ['StartSafetyTmr', 'StartYldChk'], None),
    (4, 3): (4, ['RecheckYld'], None),
    (1, 4): (2, ['Brake'], None),
    (3, 4): (5, [], 'PassedLine'),      # else-branch -> BRAKE_HOLD, see T_ELSE
    (4, 4): (5, [], 'PassedLine && !Oncoming && !Pedestrian'),   # P7 repair
    (1, 5): (1, ['SlowDown'], None),
    (3, 5): (4, ['Brake'], None),
    (4, 5): (4, ['Hold'], None),
    (5, 5): (4, ['EmergBrake'], None),
    (3, 6): (5, ['StartTurnTmr', 'SetPassedLine'], None),
    (4, 6): (3, [], None),
    (2, 7): (2, ['RecheckSig'], None),
    (3, 7): (3, ['RecheckAll'], None),
    (4, 7): (4, ['RecheckAll'], None),
    (5, 7): (7, ['WarnFault'], None),
    (6, 7): (2, [], None),
    (3, 8): (6, ['Brake'], None),
    (4, 8): (6, ['Brake'], None),
    (5, 8): (5, ['SlowDown', 'WarnFault'], None),   # P4 repair
    (5, 9): (7, ['Resume'], None),
}

# else-branches of guarded transitions
T_ELSE = {(3, 4): (2, [], 'not PassedLine'),
          (4, 4): (2, ['Brake'], 'guard false')}   # P7 repair

HAZARD_EVENTS = {5, 8}          # yield-block, sensor degradation
SAFE_STATES = {2, 4, 6, 7}      # braked / waiting / slowing / stopped
COMMITTED = {5}                 # TURNING


def successors(s):
    return {e: T[(s, e)] for e in EVENTS if (s, e) in T}


def reachability(init=0):
    seen, order, edges = {init}, [init], []
    q, depth = deque([(init, 0)]), {init: 0}
    while q:
        s, d = q.popleft()
        for e, (dst, acts, g) in successors(s).items():
            edges.append((s, e, dst, tuple(acts), g))
            if dst not in seen:
                seen.add(dst); order.append(dst); depth[dst] = d + 1
                q.append((dst, d + 1))
    return seen, edges, depth


def main():
    reach, edges, depth = reachability()
    unreachable = set(STATES) - reach
    diameter = max(depth.values())

    props = []

    def check(pid, text, ok, witness=None):
        props.append(dict(id=pid, property=text, holds=bool(ok),
                          witness=witness))
        print(f"  {pid}  {'PASS' if ok else 'FAIL'}  {text}")
        if witness and not ok:
            print(f"        counterexample: {witness}")

    # ---- P1 completeness / no deadlock -------------------------------------
    dead = [STATES[s] for s in reach if not successors(s)]
    check('P1', 'No reachable state is a deadlock, except the designated '
                'terminal state FAULT_EXIT',
          set(dead) <= {'FAULT_EXIT'}, dead)

    # ---- P2 red signal never advances toward the maneuver ------------------
    bad = [(STATES[s], STATES[T[(s, 2)][0]]) for s in reach
           if (s, 2) in T and T[(s, 2)][0] in COMMITTED]
    check('P2', 'G(EV_SIG_RED -> next state is not TURNING): a red signal '
                'never advances the machine into the committed maneuver',
          not bad, bad)

    # ---- P3 hazard events always lead to a safe state ----------------------
    MITIGATING = {'Brake', 'Hold', 'SlowDown', 'EmergBrake'}
    bad = []
    for s_ in reach:
        for e in HAZARD_EVENTS:
            if (s_, e) not in T:
                continue
            dst, acts, _ = T[(s_, e)]
            if dst not in SAFE_STATES and not (set(acts) & MITIGATING):
                bad.append((STATES[s_], EVENTS[e], STATES[dst], acts))
    check('P3', 'G(hazard event -> safe state or mitigating action): every '
                'yield-block or sensor-degradation event either moves the '
                'machine to a braked, waiting, slowing or stopped state, or '
                'emits a decelerating action',
          not bad, bad)

    # ---- P4 the committed maneuver is always escapable ---------------------
    undefined = [EVENTS[e] for e in HAZARD_EVENTS if (5, e) not in T]
    check('P4', 'From TURNING every hazard event has a defined response '
                '(the committed maneuver is interruptible)',
          not undefined, undefined)

    # ---- P5 emergency braking is reserved to the committed maneuver --------
    src = [STATES[s] for (s, e), (d, a, g) in T.items() if 'EmergBrake' in a]
    check('P5', 'EmergBrake is emitted only from TURNING',
          src == ['TURNING'], src)

    # ---- P6 terminal state is absorbing ------------------------------------
    check('P6', 'FAULT_EXIT is absorbing (no outgoing transitions)',
          not successors(7), list(successors(7)))

    # ---- P7 TURNING is entered only under an explicit clearance ------------
    # only transitions that ENTER the maneuver from outside it count; a
    # self-loop within TURNING is not an entry.
    entries = [(STATES[s], EVENTS[e], T[(s, e)][2])
               for (s, e), (d, a, g) in T.items() if d == 5 and s != 5]
    unguarded = [(a, b) for a, b, g in entries
                 if b not in ('EV_YIELD_CLEAR',) and g is None]
    check('P7', 'TURNING is entered only via EV_YIELD_CLEAR or a guarded '
                'transition (no unconditional entry into the maneuver)',
          not unguarded, unguarded)

    # ---- P8 a safe state is reachable from everywhere ----------------------
    def can_reach_safe(s):
        seen, q = {s}, deque([s])
        while q:
            u = q.popleft()
            if u in SAFE_STATES:
                return True
            for e, (d, a, g) in successors(u).items():
                if d not in seen:
                    seen.add(d); q.append(d)
        return False
    bad = [STATES[s] for s in reach if not can_reach_safe(s)]
    check('P8', 'From every reachable state, a safe state is reachable',
          not bad, bad)

    # ------------------------------------------------ translation validation
    print("\n  translation validation (compiled C vs reference model)")
    tv = {'checked': 0, 'agree': 0, 'mismatches': []}
    try:
        lib = ctypes.CDLL(str(Path(__file__).resolve().parent / 'libstm.so'))
        lib.stm_init.restype = None
        lib.stm_step.argtypes = [ctypes.c_char_p]
        lib.stm_step.restype = ctypes.c_char_p
        lib.stm_state.restype = ctypes.c_int
        lib.stm_set_ram.argtypes = [ctypes.c_ubyte]*3 + [ctypes.c_uint]
        for s in sorted(reach):
            for e in sorted(EVENTS):
                if (s, e) not in T:
                    continue
                lib.stm_init()
                # drive the compiled machine to state s along a shortest path
                path = shortest_path(0, s)
                if path is None:
                    continue
                for ev in path:
                    lib.stm_step(EVENTS[ev].encode())
                lib.stm_set_ram(1, 0, 0, 100)   # set guard AFTER driving to s
                if lib.stm_state() != s:
                    continue
                lib.stm_step(EVENTS[e].encode())
                got = lib.stm_state()
                exp = T[(s, e)][0]
                tv['checked'] += 1
                if got == exp:
                    tv['agree'] += 1
                else:
                    tv['mismatches'].append(
                        dict(state=STATES[s], event=EVENTS[e],
                             model=STATES[exp], compiled=STATES[got]))
        # guarded transitions: check both branches
        for (s_, e), (dst, acts, g) in T_ELSE.items():
            lib.stm_init()
            for ev in shortest_path(0, s_):
                lib.stm_step(EVENTS[ev].encode())
            lib.stm_set_ram(0, 0, 0, 100)      # guard FALSE
            lib.stm_step(EVENTS[e].encode())
            got = lib.stm_state()
            tv['checked'] += 1
            if got == dst:
                tv['agree'] += 1
            else:
                tv['mismatches'].append(dict(state=STATES[s_], event=EVENTS[e],
                    branch='else', model=STATES[dst], compiled=STATES[got]))
        print(f"    {tv['agree']}/{tv['checked']} (state, event, branch) cases agree")
    except Exception as ex:
        print(f"    [skipped: {ex}]")

    report = dict(
        states=len(STATES), reachable=len(reach),
        unreachable=[STATES[s] for s in unreachable],
        transitions=len(T), diameter=diameter,
        properties=props,
        properties_passed=sum(p['holds'] for p in props),
        properties_total=len(props),
        translation_validation=tv,
    )
    (OUT / 'stm_verification.json').write_text(json.dumps(report, indent=2))
    print(f"\n[OK] {OUT/'stm_verification.json'}")
    return report


def shortest_path(src, dst):
    if src == dst:
        return []
    prev, q = {src: None}, deque([src])
    while q:
        u = q.popleft()
        for e in EVENTS:
            if (u, e) not in T:
                continue
            v = T[(u, e)][0]
            if v not in prev:
                prev[v] = (u, e); q.append(v)
                if v == dst:
                    path, cur = [], v
                    while prev[cur] is not None:
                        p, ev = prev[cur]; path.append(ev); cur = p
                    return list(reversed(path))
    return None


if __name__ == '__main__':
    main()
