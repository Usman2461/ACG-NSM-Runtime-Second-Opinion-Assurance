import json
from pathlib import Path
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
OUT=Path('/tmp/results'); d=json.load(open(OUT/'fn_latency.json'))
F=d['false_negatives']; L=d['latency']
fig,ax=plt.subplots(1,2,figsize=(9.6,3.6))
# (a) FN outcome comparison
designs=['naive_absence','evidence_aware']
labels=['naive absence\n(non-detection asserted\nwith high confidence)','evidence-aware absence\n(absence confidence reflects\nobservation quality)']
uns=[100*F[k]['unsafe_rate'] for k in designs]
con=[100*F[k]['conservative_rate'] for k in designs]
x=np.arange(2); w=0.34
b1=ax[0].bar(x-w/2,uns,w,color='#D62728',label='unsafe')
b2=ax[0].bar(x+w/2,con,w,color='#F0A24B',label='conservative')
for b,v in zip(b1,uns): ax[0].text(b.get_x()+b.get_width()/2,v+0.06,f'{v:.2f}%',ha='center',fontsize=9,fontweight='bold')
for b,v in zip(b2,con): ax[0].text(b.get_x()+b.get_width()/2,v+0.06,f'{v:.2f}%',ha='center',fontsize=9)
ax[0].set_xticks(x); ax[0].set_xticklabels(labels,fontsize=8.2)
ax[0].set_ylabel('rate (%)',fontsize=10); ax[0].set_ylim(0,2.6)
ax[0].set_title('(a) Decisions under an 8.8% detector miss rate',fontsize=10.5)
ax[0].legend(fontsize=9); ax[0].grid(alpha=.25,axis='y')
# (b) latency
ks=['nominal_only_ms','conservative_only_ms','dual_opinion_ms']
lb=['nominal\nopinion only','conservative\nopinion only','dual opinion\n+ arbitration']
vs=[L[k] for k in ks]
bars=ax[1].bar(lb,vs,color=['#4C78A8','#54A24B','#8B5CF6'],width=0.55)
for b,v in zip(bars,vs): ax[1].text(b.get_x()+b.get_width()/2,v+0.0012,f'{v:.3f} ms',ha='center',fontsize=9)
ax[1].set_ylabel('mean decision latency (ms)',fontsize=10)
ax[1].set_title('(b) Cost of computing two opinions',fontsize=10.5)
ax[1].grid(alpha=.25,axis='y'); ax[1].tick_params(labelsize=8.5)
ax[1].set_ylim(0,max(vs)*1.25)
plt.tight_layout(); plt.savefig(OUT/'fig_false_negative.png',dpi=200,bbox_inches='tight')
plt.savefig(OUT/'fig_false_negative.pdf',bbox_inches='tight'); print('[OK] figure')
