"""
61_merge_split.py
=================
Merges the clear-daytime corpus with the weather/night supplement, regenerates
labels at a chosen photometric threshold, and writes a train/val split that
holds out whole time blocks rather than individual frames.

Why each of those three things is necessary
-------------------------------------------
MERGE. The supplement is collected as a separate run so the validated 10k does
not have to be thrown away. Training consumes the union, so the union is what
needs a single coherent split and a single dataset.yaml.

REGENERATE. 60_collect_town1213.py writes, for every candidate box it
considered, the photometric statistics behind the keep/drop decision --
including for boxes it dropped. The threshold is therefore a post-processing
choice, not a collection choice. If the first setting proves too aggressive
(pedestrians vanishing at dusk) or too lax (boxes over black), re-run this
script with different numbers instead of re-running CARLA for hours.

BLOCK-SPLIT. Frames are 0.2 s apart. A random 90/10 split puts images that are
one fifth of a second apart on opposite sides of it, and the resulting
validation recall is close to a training recall. That would be an ordinary
methodological flaw in most projects; here it is a safety-argument flaw,
because the absence-confidence posterior is calibrated on the detector's
measured miss rate. An inflated recall becomes an understated miss rate becomes
a conservative channel that is too sure nothing is there. Whole blocks --
weather segments where available, contiguous index runs otherwise -- are held
out so validation frames are never near-duplicates of training frames.

Usage
    python src/61_merge_split.py \
        --src /mnt/d/NSTM_Project/data/town10_train_latest \
        --src /mnt/d/NSTM_Project/data/town10_weather \
        --out /mnt/d/NSTM_Project/data/town10_union \
        --min_rms 3.0 --min_contrast 0.06 --min_peak 8.0 --val_frac 0.12

Then train against  <out>/dataset.yaml
"""
import argparse, json, random, shutil
from collections import Counter, defaultdict
from pathlib import Path

CLASSES = ['pedestrian', 'vehicle', 'light_red', 'light_yellow',
           'light_green', 'cyclist', 'traffic_sign']
CID = {n: i for i, n in enumerate(CLASSES)}


def regenerate(src, args):
    """Rewrite src/labels from src/meta at the requested thresholds.

    The original labels are preserved once, on first run, in src/labels_raw so
    that repeated threshold sweeps always start from the collector's output
    rather than from a previously filtered version.
    """
    meta_dir, lab_dir = src / 'meta', src / 'labels'
    if not meta_dir.is_dir():
        return None
    raw = src / 'labels_raw'
    if not raw.exists():
        shutil.copytree(lab_dir, raw)
        print(f'  [{src.name}] original labels backed up -> labels_raw/')

    kept, dropped = Counter(), Counter()
    for mf in sorted(meta_dir.glob('*.json')):
        try:
            m = json.load(open(mf))
        except Exception:
            continue
        rows = []
        for c in m.get('candidates', []):
            rms, mich = c.get('rms'), c.get('mich')
            peak, delta = c.get('peak'), c.get('delta')
            if None in (rms, mich, peak, delta):
                ok = bool(c.get('photo_ok'))
            else:
                ok = (peak >= args.min_peak
                      and (rms >= args.min_rms
                           or (mich >= args.min_contrast
                               and delta >= args.min_delta)))
            name = c['cls']
            if not ok:
                dropped[name] += 1
                continue
            x1, y1, x2, y2 = c['box']
            W, H = args.width, args.height
            bw, bh = x2 - x1, y2 - y1
            if bw <= 0 or bh <= 0:
                continue
            rows.append(f'{CID[name]} {(x1+x2)/2.0/W:.6f} {(y1+y2)/2.0/H:.6f} '
                        f'{bw/W:.6f} {bh/H:.6f}')
            kept[name] += 1
        (lab_dir / f"{m['stem']}.txt").write_text('\n'.join(rows))
    return kept, dropped


def blocks_for(src, args):
    """Group a source's frames into hold-out units.

    Weather segments where the collector recorded them; otherwise contiguous
    runs of --block frames, which for a single continuous autopilot drive is
    the same idea expressed through the frame index.
    """
    stems = sorted(p.stem for p in (src / 'images').glob('*.jpg'))
    groups = defaultdict(list)
    meta_dir = src / 'meta'
    if meta_dir.is_dir():
        ok = True
        for s in stems:
            f = meta_dir / f'{s}.json'
            if not f.is_file():
                ok = False
                break
            try:
                m = json.load(open(f))
            except Exception:
                ok = False
                break
            groups[(m.get('weather', '?'), m.get('segment', 0))].append(s)
        if ok and groups:
            return dict(groups)
        groups = defaultdict(list)
    for i, s in enumerate(stems):
        groups[('unlabelled-weather', i // args.block)].append(s)
    return dict(groups)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--src', action='append', required=True)
    p.add_argument('--out', required=True)
    p.add_argument('--width', type=int, default=1024)
    p.add_argument('--height', type=int, default=256)
    p.add_argument('--min_peak', type=float, default=8.0)
    p.add_argument('--min_rms', type=float, default=3.0)
    p.add_argument('--min_contrast', type=float, default=0.06)
    p.add_argument('--min_delta', type=float, default=4.0)
    p.add_argument('--no_regen', action='store_true',
                   help='use labels as collected; skip threshold re-filtering')
    p.add_argument('--block', type=int, default=200,
                   help='hold-out block size for sources without weather '
                        'segments')
    p.add_argument('--val_frac', type=float, default=0.12)
    p.add_argument('--seed', type=int, default=0)
    a = p.parse_args()

    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    rng = random.Random(a.seed)

    train, val = [], []
    per_src = {}
    for s in a.src:
        src = Path(s)
        if not (src / 'images').is_dir():
            raise SystemExit(f'{src} has no images/ directory')
        print(f'[{src.name}]')
        if not a.no_regen:
            r = regenerate(src, a)
            if r is None:
                print('  no meta/ sidecars -- labels used as collected '
                      '(this is expected for the pre-revision-2 corpus)')
            else:
                kept, dropped = r
                tot_d = sum(dropped.values())
                print(f'  regenerated: {sum(kept.values())} kept, '
                      f'{tot_d} dropped by photometry')
                if tot_d:
                    print(f'    dropped by class: {dict(dropped)}')

        groups = blocks_for(src, a)
        by_wx = defaultdict(list)
        for (wx, seg) in groups:
            by_wx[wx].append((wx, seg))
        # Hold out within each weather so validation covers every condition;
        # a globally random choice of blocks can leave a condition unmeasured.
        chosen = set()
        for wx, keys in sorted(by_wx.items()):
            keys = sorted(keys)
            rng.shuffle(keys)
            k = max(1, round(a.val_frac * len(keys))) if len(keys) > 1 else 0
            chosen.update(keys[:k])

        n_t = n_v = 0
        for key, stems in sorted(groups.items()):
            paths = [str((src / 'images' / f'{x}.jpg').resolve()) for x in stems]
            if key in chosen:
                val += paths
                n_v += len(paths)
            else:
                train += paths
                n_t += len(paths)
        per_src[src.name] = {'blocks': len(groups), 'val_blocks': len(chosen),
                             'train_frames': n_t, 'val_frames': n_v}
        print(f'  {len(groups)} blocks -> {n_t} train / {n_v} val frames')

    (out / 'train.txt').write_text('\n'.join(train) + '\n')
    (out / 'val.txt').write_text('\n'.join(val) + '\n')
    (out / 'dataset.yaml').write_text(
        f"path: {out.resolve()}\ntrain: train.txt\nval: val.txt\n"
        f"nc: {len(CLASSES)}\nnames: {CLASSES}\n")

    # final balance, counted from the labels that will actually be trained on
    def tally(paths):
        c = Counter()
        for ip in paths:
            lp = Path(ip.replace('/images/', '/labels/')).with_suffix('.txt')
            if not lp.is_file():
                continue
            for line in lp.read_text().splitlines():
                if line.strip():
                    c[CLASSES[int(line.split()[0])]] += 1
        return c

    ct, cv = tally(train), tally(val)
    tt = sum(ct.values()) or 1
    print(f'\n[OK] {len(train)} train / {len(val)} val frames -> {out}')
    print('     class balance (train):')
    for c in CLASSES:
        print(f'       {c:>14}: {ct[c]:7d}  ({100.0*ct[c]/tt:.1f}%)   '
              f'val {cv[c]}')
    if cv[CLASSES[0]] < 50:
        print('\n[warn] fewer than 50 pedestrians in val. Pedestrian recall is '
              'the number the absence model is calibrated on; below this it is '
              'too noisy to trust. Raise --val_frac or collect more.')

    json.dump({'sources': per_src,
               'thresholds': {'min_peak': a.min_peak, 'min_rms': a.min_rms,
                              'min_contrast': a.min_contrast,
                              'min_delta': a.min_delta,
                              'regenerated': not a.no_regen},
               'train_frames': len(train), 'val_frames': len(val),
               'train_instances': dict(ct), 'val_instances': dict(cv),
               'seed': a.seed},
              open(out / 'merge_stats.json', 'w'), indent=2)


if __name__ == '__main__':
    main()
