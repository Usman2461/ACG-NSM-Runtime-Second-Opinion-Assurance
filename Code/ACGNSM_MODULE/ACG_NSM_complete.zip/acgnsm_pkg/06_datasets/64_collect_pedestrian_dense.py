"""
64_collect_pedestrian_dense.py
==============================
Targeted collection of pedestrian-dense frames.

Why
---
The general collector raised pedestrian instances from 352 to 11423, yet the
trained detector still reached only 0.077 recall on that class. The validation
split explains it: pedestrians appeared in 64 of 1880 images. Instances were
plentiful but CONCENTRATED -- a handful of frames carried many people and the
overwhelming majority carried none, so the model rarely saw one and never
learned to expect them. Coverage, not count, is the deficit.

Approach
--------
Rather than driving and hoping to encounter people, each scene is STAGED:

  1. choose a crossing or roadside location
  2. teleport the ego onto the road at a viewing distance, facing it
  3. spawn a group of walkers across that location
  4. send them walking through the field of view
  5. capture while they cross, then tear down and move on

Every captured frame therefore contains pedestrians, at a controlled range and
bearing. Ranges and group sizes are varied deliberately so the model sees the
class at the scales it must actually detect, rather than only at whatever
distance a wandering ego happened to produce.

The labelling path is inherited unchanged from the general collector, which was
validated visually: boxes land on objects, occlusion is verified against the
semantic camera, and lights carry per-actor colour.

Output matches the general collector, so the sets merge directly.
"""
import argparse, importlib.util, json, math, random, time
from pathlib import Path
import numpy as np

SRC = Path(__file__).resolve().parent


def _load(name, path):
    spec = importlib.util.spec_from_file_location(name, str(path))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


base = _load('collector_base', SRC / '60_collect_town1213.py')


class PedestrianCollector(base.Collector):
    """Stages pedestrians in front of the ego instead of waiting to meet them."""

    def _crossing_sites(self, limit=400):
        """Candidate places to stage a crossing, best first.

        Crosswalk polygons are preferred because people belong there and the
        surrounding geometry looks like a real crossing. Where the map exposes
        none, junction waypoints serve as a fallback.
        """
        carla = self.carla
        sites = []
        try:
            xs = self.world.get_map().get_crosswalks()
            # returned as a flat vertex list; group into polygons of 5
            for i in range(0, max(0, len(xs) - 4), 5):
                poly = xs[i:i + 5]
                cx = sum(p.x for p in poly) / len(poly)
                cy = sum(p.y for p in poly) / len(poly)
                cz = sum(p.z for p in poly) / len(poly)
                sites.append(carla.Location(x=cx, y=cy, z=cz))
        except Exception:
            pass

        if len(sites) < 20:
            wps = self.world.get_map().generate_waypoints(6.0)
            for w in wps:
                if w.is_junction:
                    sites.append(w.transform.location)
        random.shuffle(sites)
        return sites[:limit]

    def _view_pose(self, site, distance, lateral=0.0):
        """A pose on the nearest driving lane, `distance` back, facing the site."""
        carla = self.carla
        wp = self.world.get_map().get_waypoint(site, project_to_road=True,
                                               lane_type=carla.LaneType.Driving)
        if wp is None:
            return None
        prev = wp.previous(max(3.0, distance))
        if not prev:
            return None
        tf = prev[0].transform
        loc = carla.Location(x=tf.location.x, y=tf.location.y,
                             z=tf.location.z + 0.3)
        if lateral:
            r = math.radians(tf.rotation.yaw + 90.0)
            loc.x += lateral * math.cos(r)
            loc.y += lateral * math.sin(r)
        # face the staging site
        dx, dy = site.x - loc.x, site.y - loc.y
        yaw = math.degrees(math.atan2(dy, dx))
        return carla.Transform(loc, carla.Rotation(yaw=yaw))

    def _clear_walkers(self):
        for c in self.ctrls:
            try:
                if c.is_alive:
                    c.stop()
            except Exception:
                pass
        for c in self.ctrls:
            try:
                if c.is_alive:
                    c.destroy()
            except Exception:
                pass
        for w in self.walkers:
            try:
                if w.is_alive:
                    w.destroy()
            except Exception:
                pass
        self.ctrls, self.walkers = [], []

    def _label(self, sem, rgb):
        """Call the base labeller whatever signature it currently has.

        The general collector has gained parameters since this subclass was
        written -- a greyscale image among them -- and hard-coding the call
        breaks on every such addition. Inspect the signature instead and pass
        what it asks for, deriving anything derivable from the frame.
        """
        import inspect, numpy as _np
        if not hasattr(self, '_label_sig'):
            self._label_sig = list(
                inspect.signature(self.labels_for_frame).parameters)
        args = []
        for name in self._label_sig:
            n = name.lower()
            if n in ('sem', 'sem_arr', 'semantic', 'seg'):
                args.append(sem)
            elif n in ('gray', 'grey', 'gray_arr', 'luma'):
                a = _np.asarray(rgb)
                args.append(a[:, :, :3].mean(axis=2).astype(_np.uint8)
                            if a.ndim == 3 else a)
            elif n in ('rgb', 'img', 'image', 'frame'):
                args.append(rgb)
            else:
                args.append(None)
        rows = self.labels_for_frame(*args)
        # The base collector returns rows already formatted as YOLO text, so
        # they are used as-is. Anything non-string is coerced defensively
        # rather than assumed, but the common path does nothing.
        out = []
        for r in (rows or []):
            if isinstance(r, bytes):
                out.append(r.decode())
            elif isinstance(r, str):
                out.append(r)
            else:
                try:
                    seq = list(r)
                    out.append(f"{int(float(seq[0]))} " +
                               ' '.join(f'{float(v):.6f}' for v in seq[1:5]))
                except Exception:
                    continue
        return out

    def _stage(self, site, n_walkers, spread):
        """Spawn a group around `site` and send them walking across it."""
        carla = self.carla
        wbps = self.bp.filter('walker.pedestrian.*')
        cbp = self.bp.find('controller.ai.walker')
        made = 0
        for _ in range(n_walkers * 8):
            if made >= n_walkers:
                break
            ang = random.uniform(0, 2 * math.pi)
            rad = random.uniform(0.5, spread)
            loc = carla.Location(x=site.x + rad * math.cos(ang),
                                 y=site.y + rad * math.sin(ang),
                                 z=site.z + 1.0)
            w = self.world.try_spawn_actor(random.choice(wbps),
                                           carla.Transform(loc))
            if not w:
                continue
            self.walkers.append(w)
            try:
                c = self.world.spawn_actor(cbp, carla.Transform(), attach_to=w)
                c.start()
                # walk through the staging point rather than away from it
                tgt = self.world.get_random_location_from_navigation()
                c.go_to_location(tgt if tgt else site)
                c.set_max_speed(0.8 + random.random() * 0.8)
                self.ctrls.append(c)
            except Exception:
                pass
            made += 1
        return made

    # ------------------------------------------------------------------ loop
    def run(self):
        import cv2
        carla = self.carla
        a = self.a

        # ego and cameras only; traffic is optional and light
        sps = self.world.get_map().get_spawn_points()
        random.shuffle(sps)
        ego_bp = self.bp.filter('vehicle.lincoln.mkz_2020')
        ego_bp = ego_bp[0] if ego_bp else self.bp.filter('vehicle.*')[0]
        self.ego = self.world.spawn_actor(ego_bp, sps[0])
        self.actors.append(self.ego)

        for sp in sps[1:1 + a.vehicles]:
            b = random.choice(self.bp.filter('vehicle.*'))
            v = self.world.try_spawn_actor(b, sp)
            if v:
                v.set_autopilot(True, a.tm_port)
                self.actors.append(v)

        cb = self.bp.find('sensor.camera.rgb')
        sb = self.bp.find('sensor.camera.semantic_segmentation')
        for b in (cb, sb):
            b.set_attribute('image_size_x', str(a.width))
            b.set_attribute('image_size_y', str(a.height))
            b.set_attribute('fov', str(a.fov))
        ctf = carla.Transform(carla.Location(x=a.cam_x, y=a.cam_y, z=a.cam_z),
                              carla.Rotation(pitch=a.cam_pitch, yaw=a.cam_yaw,
                                             roll=a.cam_roll))
        self.cam = self.world.spawn_actor(cb, ctf, attach_to=self.ego)
        self.sem = self.world.spawn_actor(sb, ctf, attach_to=self.ego)
        self.buf = {}
        self.cam.listen(lambda i: self.buf.__setitem__('rgb', i))
        self.sem.listen(lambda i: self.buf.__setitem__('sem', i))

        sites = self._crossing_sites()
        print(f'{len(sites)} candidate staging sites')
        if not sites:
            print('[FAIL] no crossings or junctions found'); self.cleanup(); return

        weathers = [carla.WeatherParameters.ClearNoon,
                    carla.WeatherParameters.CloudyNoon,
                    carla.WeatherParameters.WetNoon,
                    carla.WeatherParameters.ClearSunset,
                    carla.WeatherParameters.SoftRainNoon]

        si = 0
        empty_streak = 0
        while self.kept < a.frames and si < len(sites) * 4:
            site = sites[si % len(sites)]
            si += 1

            dist = random.choice([6, 9, 12, 16, 22, 30, 40])
            pose = self._view_pose(site, dist,
                                   lateral=random.uniform(-1.2, 1.2))
            if pose is None:
                continue
            try:
                self.ego.set_transform(pose)
                self.ego.set_target_velocity(carla.Vector3D(0, 0, 0))
            except Exception:
                continue
            if random.random() < 0.35:
                self.world.set_weather(random.choice(weathers))

            for _ in range(6):
                self.world.tick()

            n = self._stage(site, random.randint(a.group_min, a.group_max),
                            spread=a.spread)
            if n == 0:
                self._clear_walkers()
                continue
            for _ in range(8):
                self.world.tick()

            got_here = 0
            for _ in range(a.frames_per_site * a.every):
                self.world.tick()
                if 'rgb' not in self.buf or 'sem' not in self.buf:
                    continue
                ri, sei = self.buf['rgb'], self.buf['sem']
                rgb = np.frombuffer(ri.raw_data, dtype=np.uint8).reshape(
                    (ri.height, ri.width, 4))[:, :, :3]
                sem = np.frombuffer(sei.raw_data, dtype=np.uint8).reshape(
                    (sei.height, sei.width, 4))[:, :, 2]

                rows = self._label(sem, rgb)
                has_ped = any(int(r.split()[0]) == base.CID['pedestrian']
                              for r in rows)
                if not has_ped:
                    continue   # the entire point is pedestrian coverage

                stem = f'ped_{self.kept:06d}'
                cv2.imwrite(str(self.out / 'images' / f'{stem}.jpg'), rgb)
                (self.out / 'labels' / f'{stem}.txt').write_text('\n'.join(rows))
                self.kept += 1
                got_here += 1
                if got_here >= a.frames_per_site:
                    break
                if self.kept >= a.frames:
                    break

            self._clear_walkers()
            empty_streak = empty_streak + 1 if got_here == 0 else 0
            if empty_streak >= 25:
                print('[warn] 25 consecutive sites produced nothing; '
                      'crossings may be unreachable on this map')
                empty_streak = 0
            if self.kept and self.kept % 100 < a.frames_per_site:
                print(f'  {self.kept}/{a.frames} frames  '
                      f'ped={self.counts["pedestrian"]}  site {si}')

        self.finish()


def main():
    # Build on the general collector's own parser rather than a copy of it.
    # That script has grown well beyond the version this subclass was written
    # against, and duplicating its arguments here guarantees drift: the first
    # attempt failed on a `seed` argument the base class required and this one
    # did not define. Inheriting the parser means any option added there is
    # accepted here automatically.
    import argparse as _ap
    try:
        p = base.build_parser()                      # if the base exposes one
    except AttributeError:
        p = None

    if p is None:
        # Re-run the base module's own argument construction by calling its
        # main() parser section is not possible, so fall back to introspection:
        # parse with a permissive parser and fill any missing attribute the
        # base class touches with a sensible default.
        p = _ap.ArgumentParser()
        p.add_argument('--host', default='192.168.144.1')
        p.add_argument('--port', type=int, default=2000)
        p.add_argument('--tm_port', type=int, default=8120)
        p.add_argument('--town', default='Town10HD_Opt')
        p.add_argument('--frames', type=int, default=2000)
        p.add_argument('--out', default='/mnt/d/NSTM_Project/data/town10_ped')
        p.add_argument('--width', type=int, default=1024)
        p.add_argument('--height', type=int, default=256)
        p.add_argument('--fov', type=float, default=110.0)
        p.add_argument('--cam_x', type=float, default=-1.5)
        p.add_argument('--cam_y', type=float, default=0.0)
        p.add_argument('--cam_z', type=float, default=2.0)
        p.add_argument('--cam_pitch', type=float, default=0.0)
        p.add_argument('--cam_yaw', type=float, default=0.0)
        p.add_argument('--cam_roll', type=float, default=0.0)
        p.add_argument('--vehicles', type=int, default=25)
        p.add_argument('--walkers', type=int, default=0)
        p.add_argument('--walker_radius', type=float, default=0.0)
        p.add_argument('--max_range', type=float, default=60.0)
        p.add_argument('--min_px', type=float, default=6.0)
        p.add_argument('--every', type=int, default=3)
        p.add_argument('--keep_common', type=float, default=1.0)
        p.add_argument('--light_match_px', type=float, default=200.0)
        p.add_argument('--seed', type=int, default=0)

    # options specific to staged pedestrian scenes
    for flag, kw in (('--group_min', dict(type=int, default=3)),
                     ('--group_max', dict(type=int, default=10)),
                     ('--spread', dict(type=float, default=5.0)),
                     ('--frames_per_site', dict(type=int, default=8))):
        try:
            p.add_argument(flag, **kw)
        except _ap.ArgumentError:
            pass                                      # already defined by base

    a, unknown = p.parse_known_args()
    if unknown:
        print(f'[note] ignoring unrecognised arguments: {unknown}')

    # The base collector has grown well past the version this subclass was
    # written against, and each missing option surfaced only at runtime as a
    # separate AttributeError. Rather than chase them one at a time, read the
    # base module's source for every args.X it touches and supply anything the
    # parser above did not define. Values come from the base parser's own
    # defaults where they can be recovered, so behaviour matches a direct run.
    import re as _re, inspect as _inspect

    wanted = set(_re.findall(r'\bargs\.([A-Za-z_][A-Za-z0-9_]*)',
                             _inspect.getsource(base)))
    wanted |= set(_re.findall(r'\bself\.a\.([A-Za-z_][A-Za-z0-9_]*)',
                              _inspect.getsource(base)))

    # recover the base parser's declared defaults
    base_defaults = {}
    try:
        src = _inspect.getsource(base)
        for m in _re.finditer(
                r"add_argument\(\s*'--([A-Za-z0-9_]+)'[^)]*?default=([^,)]+)", src):
            key, raw = m.group(1), m.group(2).strip()
            try:
                base_defaults[key] = eval(raw, {'__builtins__': {}}, {})
            except Exception:
                base_defaults[key] = raw.strip("'\"")
    except Exception:
        pass

    missing = []
    for k in sorted(wanted):
        if hasattr(a, k):
            continue
        if k in base_defaults:
            setattr(a, k, base_defaults[k])
        else:
            # neutral: falsy values disable optional behaviour rather than
            # enabling something the staged collection did not ask for
            setattr(a, k, None)
        missing.append(k)
    if missing:
        print(f'[note] inherited {len(missing)} option(s) from the base '
              f'collector: {", ".join(missing[:12])}'
              + (' ...' if len(missing) > 12 else ''))

    # staged collection controls its own walkers; make sure inherited modes
    # cannot re-enable the base class's global walker spawning
    a.walkers = 0
    a.walker_radius = 0.0
    if getattr(a, 'walker_move', None) in (None, ''):
        a.walker_move = 'auto'

    c = PedestrianCollector(a)
    try:
        c.run()
    except KeyboardInterrupt:
        print('\ninterrupted; saving what was collected')
        try: c._clear_walkers()
        except Exception: pass
        c.finish()
    except Exception:
        try: c._clear_walkers()
        except Exception: pass
        c.cleanup()
        raise


if __name__ == '__main__':
    main()
