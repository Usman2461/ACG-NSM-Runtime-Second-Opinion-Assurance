"""
06_collect_pedestrians.py  (v2 - navmesh spawning)
=========================
FIX: spawn pedestrians at VALID navigation-mesh points near+ahead of ego,
so they physically render instead of being culled.

Also: ego drives slowly and we pick a spawn where the road ahead has sidewalks.
"""
import sys, glob, os, random, math, json, time, argparse
from pathlib import Path
from queue import Queue, Empty
import numpy as np
import carla
print("[OK] carla imported (pip)")

TICKS = 200
DT = 0.1
IMG_W, IMG_H, FOV = 800, 600, 90.0
CLASS_PED, CLASS_VEH, CLASS_TL, CLASS_CYC, CLASS_SIGN = 0,1,2,3,4


def build_intrinsics():
    f = IMG_W/(2.0*math.tan(FOV*math.pi/360.0))
    return np.array([[f,0,IMG_W/2.0],[0,f,IMG_H/2.0],[0,0,1.0]])

def actor_class(a):
    t=a.type_id
    if t.startswith('walker.pedestrian'): return CLASS_PED
    if t.startswith('vehicle'):
        if any(k in t for k in ['bike','cycle','omafiets','crossbike']): return CLASS_CYC
        return CLASS_VEH
    if t.startswith('traffic.traffic_light'): return CLASS_TL
    if t.startswith('traffic.'): return CLASS_SIGN
    return None

def get_obs_dist(ego, world, mr=80.0):
    el=ego.get_location(); ef=ego.get_transform().get_forward_vector(); best=mr
    for a in world.get_actors():
        if a.id==ego.id: continue
        if not (a.type_id.startswith('vehicle') or a.type_id.startswith('walker')): continue
        loc=a.get_location(); d=loc.distance(el)
        if d>=mr: continue
        dx,dy=loc.x-el.x,loc.y-el.y; n=max(math.sqrt(dx*dx+dy*dy),1e-6)
        if ef.x*(dx/n)+ef.y*(dy/n)>0.65: best=min(best,d)
    return round(best,2) if best<mr else -1.0

def get_speed(ego):
    v=ego.get_velocity(); return round(3.6*math.sqrt(v.x**2+v.y**2+v.z**2),2)

def get_ped(ego, world):
    el=ego.get_location()
    for a in world.get_actors():
        if a.type_id.startswith('walker.pedestrian') and a.get_location().distance(el)<20: return 1
    return 0

def get_oncoming(ego, world):
    el=ego.get_location(); ef=ego.get_transform().get_forward_vector()
    for a in world.get_actors():
        if a.id==ego.id or not a.type_id.startswith('vehicle'): continue
        if a.get_location().distance(el)>50: continue
        v=a.get_velocity(); s=math.sqrt(v.x**2+v.y**2)
        if s<0.5: continue
        if ef.x*(v.x/s)+ef.y*(v.y/s)<-0.55: return 1
    return 0

def get_tl(ego):
    t=ego.get_traffic_light()
    if t is None: return -1
    st=t.get_state()
    return {carla.TrafficLightState.Red:0,carla.TrafficLightState.Green:1,carla.TrafficLightState.Yellow:2}.get(st,-1)

def dist_tier(d):
    if d<0: return 0
    if d>50: return 1
    if d>20: return 2
    return 3
def spd_tier(s):
    if s==0: return 0
    if s<=30: return 1
    if s<=60: return 2
    return 3

def get_actor_bboxes(world, ego, mr=80.0):
    out=[]; el=ego.get_location()
    for a in world.get_actors():
        if a.id==ego.id: continue
        cls=actor_class(a)
        if cls is None: continue
        loc=a.get_location()
        if loc.distance(el)>mr: continue
        # IMPORTANT: only log walkers that are actually alive & on ground
        if cls==CLASS_PED and loc.z < -5:  # culled walkers sink
            continue
        try:
            bb=a.bounding_box; tf=a.get_transform()
            out.append({"id":a.id,"class":cls,"loc":[loc.x,loc.y,loc.z],
                "extent":[bb.extent.x,bb.extent.y,bb.extent.z],
                "bb_loc":[bb.location.x,bb.location.y,bb.location.z],
                "yaw":tf.rotation.yaw,"pitch":tf.rotation.pitch,"roll":tf.rotation.roll})
        except: pass
    return out

def attach_sensors(world, bl, ego):
    sensors,queues={},{}
    cam_bp=bl.find('sensor.camera.rgb')
    cam_bp.set_attribute('image_size_x',str(IMG_W)); cam_bp.set_attribute('image_size_y',str(IMG_H))
    cam_bp.set_attribute('fov',str(FOV))
    cam=world.spawn_actor(cam_bp,carla.Transform(carla.Location(x=1.5,z=2.0)),attach_to=ego)
    q=Queue(); cam.listen(lambda d:q.put(d)); sensors['rgb']=cam; queues['rgb']=q
    li_bp=bl.find('sensor.lidar.ray_cast')
    li_bp.set_attribute('channels','32'); li_bp.set_attribute('range','80')
    li_bp.set_attribute('points_per_second','300000'); li_bp.set_attribute('rotation_frequency','10')
    li=world.spawn_actor(li_bp,carla.Transform(carla.Location(x=0.0,z=2.4)),attach_to=ego)
    q2=Queue(); li.listen(lambda d:q2.put(d)); sensors['lidar']=li; queues['lidar']=q2
    gn=world.spawn_actor(bl.find('sensor.other.gnss'),carla.Transform(),attach_to=ego)
    q3=Queue(); gn.listen(lambda d:q3.put(d)); sensors['gnss']=gn; queues['gnss']=q3
    return sensors,queues

def save_rgb(image,path):
    import cv2
    arr=np.frombuffer(image.raw_data,dtype=np.uint8).reshape((image.height,image.width,4))[:,:,:3]
    cv2.imwrite(str(path),arr)
def save_lidar(points,path):
    np.save(str(path),np.frombuffer(points.raw_data,dtype=np.float32).reshape((-1,4)))


def spawn_walkers_navmesh(world, bl, client, ego, n=20):
    """
    Spawn walkers at valid navmesh points within 40m AHEAD of ego.
    Uses get_random_location_from_navigation so they actually render.
    """
    ego_tf = ego.get_transform()
    ego_loc = ego_tf.location
    fwd = ego_tf.get_forward_vector()

    walker_bps = bl.filter('walker.pedestrian.*')
    spawn_tfs = []
    attempts = 0
    while len(spawn_tfs) < n and attempts < n*20:
        attempts += 1
        nav = world.get_random_location_from_navigation()
        if nav is None:
            continue
        # vector from ego to nav point
        dx, dy = nav.x - ego_loc.x, nav.y - ego_loc.y
        dist = math.hypot(dx, dy)
        if dist < 6 or dist > 30:
            continue
        # must be ahead of ego (dot with forward > 0.4)
        if (fwd.x*dx + fwd.y*dy)/max(dist,1e-6) < 0.4:
            continue
        spawn_tfs.append(carla.Transform(carla.Location(x=nav.x, y=nav.y, z=nav.z+1.0)))

    # batch spawn walkers
    walkers = []
    controllers = []
    for tf in spawn_tfs:
        bp = random.choice(walker_bps)
        if bp.has_attribute('is_invincible'):
            bp.set_attribute('is_invincible', 'false')
        w = world.try_spawn_actor(bp, tf)
        if w:
            walkers.append(w)

    world.tick()  # let them settle

    # attach AI controllers
    wc_bp = bl.find('controller.ai.walker')
    for w in walkers:
        wc = world.try_spawn_actor(wc_bp, carla.Transform(), attach_to=w)
        if wc:
            controllers.append(wc)

    world.tick()

    for wc in controllers:
        wc.start()
        dest = world.get_random_location_from_navigation()
        if dest:
            wc.go_to_location(dest)
        wc.set_max_speed(0.8 + random.random()*0.8)

    return walkers + controllers, len(walkers)


def run_episode(client, world, ep_id, out_dir, scenario='ped_navmesh'):
    bl=world.get_blueprint_library()
    tm=client.get_trafficmanager(8000); tm.set_synchronous_mode(True)
    cfg=world.get_settings(); cfg.synchronous_mode=True; cfg.fixed_delta_seconds=DT
    world.apply_settings(cfg)
    world.set_weather(carla.WeatherParameters.ClearNoon)

    sps=world.get_map().get_spawn_points()
    ebp=bl.filter('vehicle.tesla.model3')[0]
    ego=None
    for _ in range(30):
        ego=world.try_spawn_actor(ebp,random.choice(sps))
        if ego: break
    if ego is None: raise RuntimeError("Cannot spawn ego")
    ego.set_autopilot(True,tm.get_port())
    tm.vehicle_percentage_speed_difference(ego,60)  # slow

    # CRITICAL: tick so ego position updates before spawning walkers around it
    world.tick()

    npcs=[]
    for _ in range(3):
        bp=random.choice(bl.filter('vehicle.*'))
        npc=world.try_spawn_actor(bp,random.choice(sps))
        if npc: npc.set_autopilot(True,tm.get_port()); npcs.append(npc)

    walkers, n_walkers = spawn_walkers_navmesh(world, bl, client, ego, n=20)
    npcs.extend(walkers)

    sensors,queues=attach_sensors(world,bl,ego)
    cam=sensors['rgb']

    ep_dir=Path(out_dir)/scenario/("episode_%04d"%ep_id)
    (ep_dir/"rgb").mkdir(parents=True,exist_ok=True)
    (ep_dir/"lidar").mkdir(parents=True,exist_ok=True)
    K=build_intrinsics()
    json.dump({"K":K.tolist(),"img_w":IMG_W,"img_h":IMG_H,"fov":FOV,
               "cam_x":1.5,"cam_z":2.0,"lidar_z":2.4}, open(str(ep_dir/"calib.json"),'w'),indent=2)

    records=[]; gnss_records=[]
    for _ in range(5):
        world.tick()
        for q in queues.values():
            try: q.get(timeout=2.0)
            except Empty: pass

    try:
        for tick in range(TICKS):
            world.tick()
            try: save_rgb(queues['rgb'].get(timeout=2.0), ep_dir/"rgb"/("%03d.jpg"%tick))
            except Empty: pass
            try: save_lidar(queues['lidar'].get(timeout=2.0), ep_dir/"lidar"/("%03d.npy"%tick))
            except Empty: pass
            glat=glon=galt=0.0
            try:
                g=queues['gnss'].get(timeout=2.0); glat,glon,galt=g.latitude,g.longitude,g.altitude
            except Empty: pass

            d=get_obs_dist(ego,world); s=get_speed(ego)
            loc=ego.get_location(); tf=ego.get_transform()
            cam_matrix=np.array(cam.get_transform().get_matrix())
            records.append({
                "episode_id":ep_id,"scenario":scenario,"tick":tick,"timestamp_s":round(tick*DT,1),
                "ego_x":round(loc.x,2),"ego_y":round(loc.y,2),"ego_yaw":round(tf.rotation.yaw,2),
                "ObsDist_gt":d,"EgoSpd_gt":s,"Pedestrian_gt":get_ped(ego,world),
                "Oncoming_gt":get_oncoming(ego,world),"TrafficLight_gt":get_tl(ego),
                "DistTier_gt":dist_tier(d),"SpdTier_gt":spd_tier(s),
                "rgb":"rgb/%03d.jpg"%tick,"lidar":"lidar/%03d.npy"%tick,
                "cam_to_world":cam_matrix.tolist(),"actors":get_actor_bboxes(world,ego)})
            gnss_records.append({"tick":tick,"lat":glat,"lon":glon,"alt":galt})
    finally:
        for sv in sensors.values():
            try: sv.stop(); sv.destroy()
            except: pass
        for a in npcs:
            try: a.destroy()
            except: pass
        try: ego.destroy()
        except: pass
        try: world.tick()
        except: pass
        cfg.synchronous_mode=False; cfg.fixed_delta_seconds=0.0
        try: world.apply_settings(cfg)
        except: pass

    json.dump(records,open(str(ep_dir/"meta.json"),'w'),indent=2)
    json.dump(gnss_records,open(str(ep_dir/"gnss.json"),'w'),indent=2)
    return len(records), n_walkers


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--host',default='192.168.144.1')
    p.add_argument('--port',type=int,default=2000)
    p.add_argument('--episodes',type=int,default=30)
    p.add_argument('--out',default='/mnt/d/NSTM_Project/data/enriched_nstm')
    args=p.parse_args()

    print("Connecting to %s:%d"%(args.host,args.port))
    client=carla.Client(args.host,args.port); client.set_timeout(60.0)
    client.get_server_version(); print("[OK] connected")
    world=client.get_world(); time.sleep(2)
    print("[OK] world: %s"%world.get_map().name)

    total=0
    print("\n=== ped_navmesh (%d episodes) ==="%args.episodes)
    for ep in range(args.episodes):
        print("Episode %d/%d ..."%(ep+1,args.episodes),end=' ',flush=True)
        try:
            n, nw=run_episode(client,world,ep,args.out)
            total+=n; print("[OK] %d ticks, %d walkers spawned"%(n,nw))
        except Exception as e:
            import traceback; print("[ERR] %s"%e); traceback.print_exc()
    print("\nDone! Total ticks: %d"%total)


if __name__=='__main__':
    main()
