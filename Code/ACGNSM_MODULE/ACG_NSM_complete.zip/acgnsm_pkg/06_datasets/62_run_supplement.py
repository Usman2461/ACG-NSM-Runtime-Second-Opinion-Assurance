"""
62_run_supplement.py
====================
Runs the weather/night supplement end to end, unattended: a short validation
collection, an automatic check of its statistics, then -- only if the check
passes -- the full run and the merge into the union training set.

Why a gate rather than just launching the full run
--------------------------------------------------
Every short run so far has surfaced a defect that would have been expensive to
discover five thousand frames in: teleports that silently did not apply, a
walker census reading pre-tick positions, a walker/controller list desync that
made the recycler destroy unrelated actors, weather and route changes opening
one empty segment each. None of those raised an exception. They all showed up
as numbers that did not add up, in output nobody was watching.

So the checks below assert on the numbers rather than on the exit code. If the
validation run reports zero validation frames, or pedestrians frozen at zero,
or a photometric gate that never fired, the full run does not start.

Usage
    python src/62_run_supplement.py                      # gate, then full run
    python src/62_run_supplement.py --skip_validate      # straight to full run
    python src/62_run_supplement.py --validate_only      # gate only
"""
import argparse, json, subprocess, sys, time
from pathlib import Path

CLASSES = ['pedestrian', 'vehicle', 'light_red', 'light_yellow',
           'light_green', 'cyclist', 'traffic_sign']


def run(cmd, log_path):
    """Run a collection, echoing output while also keeping a full log.

    CARLA writes navigation and actor-teardown complaints straight to stderr
    from C++; they are noisy, harmless, and drown the lines that matter, so
    they are kept in the log file but filtered from the console.
    """
    noisy = ('ERROR: failed to destroy actor', 'WARNING: NAV:')
    print(f'\n$ {" ".join(cmd)}\n', flush=True)
    with open(log_path, 'w') as log:
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT, text=True,
                             bufsize=1)
        for line in p.stdout:
            log.write(line)
            if not any(line.startswith(n) for n in noisy):
                sys.stdout.write(line)
                sys.stdout.flush()
        p.wait()
    return p.returncode


def check(stats, want_frames):
    """Assert on the numbers. Returns (ok, [(name, passed, detail), ...])."""
    out = []
    inst = stats.get('instances', {})
    tot = sum(inst.values()) or 1
    frames = stats.get('frames', 0)
    split = stats.get('split', {})
    segs = stats.get('segments', {})
    dens = stats.get('segment_density', {})
    photo = stats.get('rejected_by_photometry', {})

    def add(name, ok, detail):
        out.append((name, bool(ok), detail))

    add('collected the requested frames',
        frames >= 0.95 * want_frames,
        f'{frames}/{want_frames}')

    add('validation set is non-empty',
        split.get('val_frames', 0) > 0,
        f"{split.get('val_frames', 0)} val frames "
        f"/ {split.get('train_frames', 0)} train")

    ped = inst.get('pedestrian', 0)
    add('pedestrians present',
        ped > 60,
        f'{ped} instances ({100.0*ped/tot:.1f}%)')

    add('pedestrian share is not a crowd',
        ped / tot < 0.32,
        f'{100.0*ped/tot:.1f}% (a crowd reads ~40% and occludes itself)')

    add('several segments collected',
        len(segs) >= 6,
        f'{len(segs)} segments')

    add('density actually varied',
        len(set(dens.values())) >= 2,
        f'tiers seen: {sorted(set(dens.values()))}')

    add('photometric gate fired',
        sum(photo.values()) > 0,
        f'{sum(photo.values())} boxes dropped for lack of evidence')

    lights = sum(inst.get(k, 0) for k in
                 ('light_red', 'light_yellow', 'light_green'))
    add('traffic lights still represented',
        lights / tot > 0.05,
        f'{100.0*lights/tot:.1f}% of instances')

    return all(ok for _, ok, _ in out), out


def report(results):
    print('\n' + '=' * 68)
    print('VALIDATION')
    print('=' * 68)
    for name, ok, detail in results:
        print(f'  [{"PASS" if ok else "FAIL"}]  {name:<38} {detail}')
    print('=' * 68 + '\n')


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', default='/mnt/d/NSTM_Project')
    p.add_argument('--host', default='192.168.144.1')
    p.add_argument('--tm_port', type=int, default=8100)
    p.add_argument('--town', default='Town10HD_Opt')
    p.add_argument('--validate_frames', type=int, default=400)
    p.add_argument('--full_frames', type=int, default=5000)
    p.add_argument('--vehicles', type=int, default=65)
    p.add_argument('--walkers', type=int, default=100)
    p.add_argument('--skip_validate', action='store_true')
    p.add_argument('--validate_only', action='store_true')
    p.add_argument('--no_merge', action='store_true')
    p.add_argument('--prior', default='data/town10_train_latest',
                   help='the existing clear-daytime corpus to merge with')
    a = p.parse_args()

    root = Path(a.root)
    src = root / 'src' / '60_collect_town1213.py'
    if not src.is_file():
        sys.exit(f'collector not found at {src}')

    def collect_cmd(frames, out):
        return [sys.executable, str(src),
                '--host', a.host, '--town', a.town, '--tm_port', str(a.tm_port),
                '--frames', str(frames), '--vehicles', str(a.vehicles),
                '--walkers', str(a.walkers), '--min_px', '6',
                '--weather', 'cycle', '--weather_every', '40',
                '--walker_refresh', '8', '--ego_relocate_every', '50',
                '--junction_bias', '0.6', '--out', str(out)]

    logs = root / 'logs'
    logs.mkdir(exist_ok=True)

    if not a.skip_validate:
        vout = root / 'data' / 'wx_validate'
        rc = run(collect_cmd(a.validate_frames, vout), logs / 'validate.log')
        sfile = vout / 'collection_stats.json'
        if not sfile.is_file():
            sys.exit(f'\n[STOP] no collection_stats.json (exit {rc}). The run '
                     f'did not reach finish(); see {logs/"validate.log"}')
        ok, results = check(json.load(open(sfile)), a.validate_frames)
        report(results)
        if not ok:
            sys.exit('[STOP] validation failed; full run not started. '
                     'The failing lines above say what to look at.')
        print('[OK] validation passed.\n')
        if a.validate_only:
            return

    fout = root / 'data' / 'town10_weather'
    print(f'[*] full collection: {a.full_frames} frames -> {fout}')
    print('    this is the long one; it is safe to leave unattended.\n')
    t0 = time.time()
    rc = run(collect_cmd(a.full_frames, fout), logs / 'full.log')
    mins = (time.time() - t0) / 60.0

    sfile = fout / 'collection_stats.json'
    if not sfile.is_file():
        sys.exit(f'\n[STOP] full run produced no collection_stats.json '
                 f'(exit {rc}) after {mins:.0f} min; see {logs/"full.log"}')
    stats = json.load(open(sfile))
    ok, results = check(stats, a.full_frames)
    report(results)
    print(f'[*] full collection finished in {mins:.0f} min')

    inst = stats.get('instances', {})
    tot = sum(inst.values()) or 1
    print('\n    class balance:')
    for c in CLASSES:
        print(f'      {c:>14}: {inst.get(c,0):7d}  ({100.0*inst.get(c,0)/tot:.1f}%)')

    if a.no_merge:
        return
    merge = root / 'src' / '61_merge_split.py'
    if not merge.is_file():
        print(f'\n[skip] merge script not found at {merge}')
        return
    prior = root / a.prior
    if not (prior / 'images').is_dir():
        print(f'\n[skip] prior corpus not found at {prior}; '
              f'train on {fout}/dataset.yaml alone')
        return
    union = root / 'data' / 'town10_union'
    print(f'\n[*] merging with {prior.name} -> {union}')
    rc = run([sys.executable, str(merge),
              '--src', str(prior), '--src', str(fout),
              '--out', str(union), '--val_frac', '0.12'],
             logs / 'merge.log')
    if rc == 0:
        print(f'\n[DONE] train against {union}/dataset.yaml')


if __name__ == '__main__':
    main()
