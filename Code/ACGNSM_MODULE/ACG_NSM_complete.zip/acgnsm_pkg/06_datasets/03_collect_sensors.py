"""
03_collect_sensors.py
=====================
Phase 2: Collect synchronized sensor data (camera + LiDAR + GNSS) + ground truth.

Runs in WSL, connects to CARLA server on Windows.

USAGE (smoke test, 40 episodes):
  python 03_collect_sensors.py --host 192.168.144.1 --episodes 40 \
      --out /mnt/d/NSTM_Project/data/sensor_nstm

OUTPUT per episode (folder episode_XXXX/):
  meta.json              all ground-truth labels per tick (same fields as before)
  rgb/000.jpg ... 199.jpg    front camera frames
  lidar/000.npy ... 199.npy  LiDAR point clouds (N x 4: x,y,z,intensity)
  gnss.json              per-tick noisy GPS (lat, lon, alt) for SLAM
"""

import sys
import glob
import os
import random
import math
import json
import time
import argparse
import weakref
from pathlib import Path
from queue import Queue, Empty

import numpy as np

# CARLA from pip (Python 3.10) - no egg needed in WSL
import carla
print("[OK] carla imported (pip)")

SCENARIOS = ["left_turn_signalized", "pedestrian_crossing", "highway_cutin", "adverse_weather"]
TICKS = 200
DT = 0.1
IMG_W = 800
IMG_H = 600


# ---------- Ground-truth helpers (same as Phase 1) ----------
def get_obs_dist(ego, world, max_range=80.0):
    el = ego.get_location()
    ef = ego.get_transform().get_forward_vector()
    best = max_range
    for a in world.get_actors():
        if a.id == ego.id:
            continue
        if not (a.type_id.startswith('vehicle') or a.type_id.startswith('walker')):
            continue
        loc = a.get_location()
        d = loc.distance(el)
        if d >= max_range:
            continue
        dx, dy = loc.x - el.x, loc.y - el.y
        n = max(math.sqrt(dx * dx + dy * dy), 1e-6)
        if ef.x * (dx / n) + ef.y * (dy / n) > 0.65:
            best = min(best, d)
    return round(best, 2) if best < max_range else -1.0


def get_speed(ego):
    v = ego.get_velocity()
    return round(3.6 * math.sqrt(v.x**2 + v.y**2 + v.z**2), 2)


def get_ped(ego, world):
    el = ego.get_location()
    for a in world.get_actors():
        if a.type_id.startswith('walker.pedestrian') and a.get_location().distance(el) < 20:
            return 1
    return 0


def get_oncoming(ego, world):
    el = ego.get_location()
    ef = ego.get_transform().get_forward_vector()
    for a in world.get_actors():
        if a.id == ego.id or not a.type_id.startswith('vehicle'):
            continue
        if a.get_location().distance(el) > 50:
            continue
        v = a.get_velocity()
        s = math.sqrt(v.x**2 + v.y**2)
        if s < 0.5:
            continue
        if ef.x * (v.x / s) + ef.y * (v.y / s) < -0.55:
            return 1
    return 0


def get_tl(ego):
    t = ego.get_traffic_light()
    if t is None:
        return -1
    st = t.get_state()
    if st == carla.TrafficLightState.Red:
        return 0
    if st == carla.TrafficLightState.Green:
        return 1
    if st == carla.TrafficLightState.Yellow:
        return 2
    return -1


def dist_tier(d):
    if d < 0: return 0
    if d > 50: return 1
    if d > 20: return 2
    return 3


def spd_tier(s):
    if s == 0: return 0
    if s <= 30: return 1
    if s <= 60: return 2
    return 3


def set_weather(world, preset='clear'):
    presets = {
        'clear': carla.WeatherParameters.ClearNoon,
        'rain':  carla.WeatherParameters(cloudiness=80, precipitation=70,
                                          precipitation_deposits=50, wetness=80),
        'fog':   carla.WeatherParameters(cloudiness=90, fog_density=50, fog_distance=15),
    }
    world.set_weather(presets.get(preset, presets['clear']))


# ---------- Sensor setup ----------
def attach_sensors(world, bl, ego):
    """Attach RGB camera, LiDAR, GNSS. Returns (sensors, queues)."""
    sensors = {}
    queues = {}

    # RGB camera (front-facing)
    cam_bp = bl.find('sensor.camera.rgb')
    cam_bp.set_attribute('image_size_x', str(IMG_W))
    cam_bp.set_attribute('image_size_y', str(IMG_H))
    cam_bp.set_attribute('fov', '90')
    cam_tf = carla.Transform(carla.Location(x=1.5, z=2.0))
    cam = world.spawn_actor(cam_bp, cam_tf, attach_to=ego)
    q_cam = Queue()
    cam.listen(lambda data: q_cam.put(data))
    sensors['rgb'] = cam
    queues['rgb'] = q_cam

    # LiDAR (32-channel, nuScenes-like)
    lidar_bp = bl.find('sensor.lidar.ray_cast')
    lidar_bp.set_attribute('channels', '32')
    lidar_bp.set_attribute('range', '80')
    lidar_bp.set_attribute('points_per_second', '300000')
    lidar_bp.set_attribute('rotation_frequency', '10')
    lidar_tf = carla.Transform(carla.Location(x=0.0, z=2.4))
    lidar = world.spawn_actor(lidar_bp, lidar_tf, attach_to=ego)
    q_lidar = Queue()
    lidar.listen(lambda data: q_lidar.put(data))
    sensors['lidar'] = lidar
    queues['lidar'] = q_lidar

    # GNSS
    gnss_bp = bl.find('sensor.other.gnss')
    gnss = world.spawn_actor(gnss_bp, carla.Transform(), attach_to=ego)
    q_gnss = Queue()
    gnss.listen(lambda data: q_gnss.put(data))
    sensors['gnss'] = gnss
    queues['gnss'] = q_gnss

    return sensors, queues


def save_rgb(image, path):
    arr = np.frombuffer(image.raw_data, dtype=np.uint8)
    arr = arr.reshape((image.height, image.width, 4))  # BGRA
    arr = arr[:, :, :3]  # drop alpha -> BGR
    import cv2
    cv2.imwrite(str(path), arr)


def save_lidar(points, path):
    arr = np.frombuffer(points.raw_data, dtype=np.float32)
    arr = arr.reshape((-1, 4))  # x, y, z, intensity
    np.save(str(path), arr)


def run_episode(client, world, scenario, ep_id, out_dir):
    bl = world.get_blueprint_library()
    tm = client.get_trafficmanager(8000)
    tm.set_synchronous_mode(True)

    cfg = world.get_settings()
    cfg.synchronous_mode = True
    cfg.fixed_delta_seconds = DT
    world.apply_settings(cfg)

    if scenario == 'highway_cutin':
        set_weather(world, 'clear')
    elif scenario == 'adverse_weather':
        set_weather(world, random.choice(['rain', 'fog']))
    else:
        set_weather(world, 'clear')

    # spawn ego
    sps = world.get_map().get_spawn_points()
    ebp = bl.filter('vehicle.tesla.model3')[0]
    ego = None
    for _ in range(30):
        ego = world.try_spawn_actor(ebp, random.choice(sps))
        if ego:
            break
    if ego is None:
        raise RuntimeError("Cannot spawn ego")
    ego.set_autopilot(True, tm.get_port())
    if scenario == 'highway_cutin':
        tm.vehicle_percentage_speed_difference(ego, -40)

    # spawn NPCs
    npcs = []
    for _ in range(6):
        bp = random.choice(bl.filter('vehicle.*'))
        npc = world.try_spawn_actor(bp, random.choice(sps))
        if npc:
            npc.set_autopilot(True, tm.get_port())
            npcs.append(npc)

    # pedestrians for crossing scenarios
    if scenario in ('left_turn_signalized', 'pedestrian_crossing'):
        for _ in range(5):
            wbp = random.choice(bl.filter('walker.pedestrian.*'))
            wloc = random.choice(sps).location
            wloc.z += 0.5
            walker = world.try_spawn_actor(wbp, carla.Transform(wloc))
            if walker:
                wc_bp = bl.find('controller.ai.walker')
                wc = world.try_spawn_actor(wc_bp, carla.Transform(), attach_to=walker)
                if wc:
                    world.tick()
                    wc.start()
                    dest = world.get_random_location_from_navigation()
                    if dest:
                        wc.go_to_location(dest)
                    wc.set_max_speed(1.0 + random.random())
                    npcs.append(wc)
                npcs.append(walker)

    # attach sensors
    sensors, queues = attach_sensors(world, bl, ego)

    # output dirs
    ep_dir = Path(out_dir) / scenario / ("episode_%04d" % ep_id)
    (ep_dir / "rgb").mkdir(parents=True, exist_ok=True)
    (ep_dir / "lidar").mkdir(parents=True, exist_ok=True)

    records = []
    gnss_records = []

    # warm-up ticks so sensors start producing
    for _ in range(5):
        world.tick()
        for q in queues.values():
            try: q.get(timeout=2.0)
            except Empty: pass

    try:
        for tick in range(TICKS):
            world.tick()

            # collect sensor frames (with timeout)
            try:
                img = queues['rgb'].get(timeout=2.0)
                save_rgb(img, ep_dir / "rgb" / ("%03d.jpg" % tick))
            except Empty:
                pass
            try:
                pts = queues['lidar'].get(timeout=2.0)
                save_lidar(pts, ep_dir / "lidar" / ("%03d.npy" % tick))
            except Empty:
                pass
            gnss_lat, gnss_lon, gnss_alt = 0.0, 0.0, 0.0
            try:
                g = queues['gnss'].get(timeout=2.0)
                gnss_lat, gnss_lon, gnss_alt = g.latitude, g.longitude, g.altitude
            except Empty:
                pass

            # ground truth
            d = get_obs_dist(ego, world)
            s = get_speed(ego)
            loc = ego.get_location()
            tf = ego.get_transform()

            records.append({
                "episode_id": ep_id, "scenario": scenario, "tick": tick,
                "timestamp_s": round(tick * DT, 1),
                "ego_x": round(loc.x, 2), "ego_y": round(loc.y, 2),
                "ego_yaw": round(tf.rotation.yaw, 2),
                "ObsDist_gt": d, "EgoSpd_gt": s,
                "Pedestrian_gt": get_ped(ego, world),
                "Oncoming_gt": get_oncoming(ego, world),
                "TrafficLight_gt": get_tl(ego),
                "DistTier_gt": dist_tier(d), "SpdTier_gt": spd_tier(s),
                "rgb": "rgb/%03d.jpg" % tick,
                "lidar": "lidar/%03d.npy" % tick,
            })
            gnss_records.append({
                "tick": tick, "lat": gnss_lat, "lon": gnss_lon, "alt": gnss_alt
            })

    finally:
        for s in sensors.values():
            try:
                s.stop()
                s.destroy()
            except: pass
        for a in npcs:
            try: a.destroy()
            except: pass
        try: ego.destroy()
        except: pass
        try: world.tick()
        except: pass
        cfg.synchronous_mode = False
        cfg.fixed_delta_seconds = 0.0
        try: world.apply_settings(cfg)
        except: pass

    with open(str(ep_dir / "meta.json"), 'w') as f:
        json.dump(records, f, indent=2)
    with open(str(ep_dir / "gnss.json"), 'w') as f:
        json.dump(gnss_records, f, indent=2)
    return len(records)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--host', default='192.168.144.1')
    p.add_argument('--port', type=int, default=2000)
    p.add_argument('--episodes', type=int, default=40)
    p.add_argument('--out', default='/mnt/d/NSTM_Project/data/sensor_nstm')
    args = p.parse_args()

    print("Connecting to %s:%d" % (args.host, args.port))
    client = carla.Client(args.host, args.port)
    client.set_timeout(60.0)
    client.get_server_version()
    print("[OK] connected")

    world = client.get_world()
    time.sleep(2)
    print("[OK] world: %s" % world.get_map().name)
    print("[OK] %d spawn points" % len(world.get_map().get_spawn_points()))

    per = max(1, args.episodes // len(SCENARIOS))
    total = 0
    for scenario in SCENARIOS:
        print("\n=== %s (%d episodes) ===" % (scenario, per))
        for ep in range(per):
            print("Episode %d/%d ..." % (ep + 1, per), end=' ', flush=True)
            try:
                n = run_episode(client, world, scenario, ep, args.out)
                total += n
                print("[OK] %d ticks + sensors saved" % n)
            except Exception as e:
                import traceback
                print("[ERR] %s" % e)
                traceback.print_exc()

    print("\nDone! Total ticks with sensors: %d" % total)
    print("Saved to: %s" % args.out)


if __name__ == '__main__':
    main()
