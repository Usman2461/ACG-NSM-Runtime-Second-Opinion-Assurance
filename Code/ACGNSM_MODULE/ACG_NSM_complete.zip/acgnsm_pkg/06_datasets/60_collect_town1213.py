"""
60_collect_town1213.py
======================
Collects a detection dataset on the leaderboard towns, through the exact camera
rig TransFuser++ uses, with automatic labels projected from CARLA ground truth.

Why this exists
---------------
The detector fine-tuned on Town10 does not transfer. Measured on a Town12 frame
it returns almost exclusively traffic signs: no pedestrians, no traffic lights,
one vehicle only below a 0.01 confidence floor. The three fields the
conservative channel actually consumes are precisely the ones it cannot supply.
Two causes compound. The training distribution was severely imbalanced --
pedestrians were 352 instances, 1.0% of the corpus -- and the inference rig is a
1024x256 image at 110 degrees, roughly 4:1, whereas training used a conventional
aspect ratio.

What this changes relative to the previous dataset
--------------------------------------------------
1. Capture uses the planner's own camera geometry, read from its config, so the
   detector is trained on the images it will actually see.
2. Traffic lights are split by state. The previous single traffic_light class
   carried no colour, which is why the legality assessor could never evaluate
   signal compliance. Splitting them makes that channel live.
3. Pedestrians and cyclists are deliberately oversampled: walkers are spawned
   densely around the ego and frames containing them are retained
   preferentially, so the class that matters most is no longer the rarest.
4. Visibility is verified against a semantic-segmentation camera rather than
   assumed from geometry, so heavily occluded objects are dropped instead of
   being labelled as though they were plainly visible.

Classes
    0 pedestrian   1 vehicle   2 light_red   3 light_yellow
    4 light_green  5 cyclist   6 traffic_sign

Usage
    python src/60_collect_town1213.py --host 192.168.144.1 --town Town12 \
        --frames 4000 --out /mnt/d/NSTM_Project/data/town1213
"""
import argparse, json, math, os, random, time
from pathlib import Path
import numpy as np

CLASSES = ['pedestrian', 'vehicle', 'light_red', 'light_yellow',
           'light_green', 'cyclist', 'traffic_sign']
CID = {n: i for i, n in enumerate(CLASSES)}

# CityScapes-style semantic tags used by CARLA for the visibility check
SEM = {'pedestrian': 12, 'rider': 13, 'vehicle': 14, 'truck': 15, 'bus': 16,
       'traffic_light': 7, 'traffic_sign': 8, 'bicycle': 19, 'motorcycle': 18}


# ----------------------------------------------------------------- geometry
def build_K(w, h, fov):
    f = w / (2.0 * math.tan(math.radians(fov) / 2.0))
    return np.array([[f, 0, w / 2.0], [0, f, h / 2.0], [0, 0, 1.0]])


def world_to_cam(pts, cam_tf):
    """pts: (N,3) world. Returns (N,3) in camera coords (x right, y down, z fwd)."""
    inv = np.array(cam_tf.get_inverse_matrix())
    hom = np.concatenate([pts, np.ones((pts.shape[0], 1))], axis=1)
    c = (inv @ hom.T).T[:, :3]
    # CARLA: x forward, y right, z up  ->  vision: x right, y down, z forward
    return np.stack([c[:, 1], -c[:, 2], c[:, 0]], axis=1)


def project(pts_cam, K):
    z = pts_cam[:, 2]
    ok = z > 0.2
    uv = (K @ pts_cam[ok].T).T
    uv = uv[:, :2] / uv[:, 2:3]
    return uv, ok


def bbox_corners(bb, tf=None):
    import carla
    c = bb.extent
    o = np.array([[x, y, z] for x in (-c.x, c.x)
                  for y in (-c.y, c.y) for z in (-c.z, c.z)])
    m = np.array((tf or carla.Transform(bb.location, bb.rotation)).get_matrix())
    if tf is not None:
        o = o + np.array([bb.location.x, bb.location.y, bb.location.z])
    hom = np.concatenate([o, np.ones((8, 1))], axis=1)
    return (m @ hom.T).T[:, :3]


# ------------------------------------------------------------------ capture
class Collector:
    def __init__(self, args):
        import carla
        self.carla = carla
        self.a = args
        self.client = carla.Client(args.host, args.port)
        self.client.set_timeout(60.0)
        if args.town and args.town not in self.client.get_world().get_map().name:
            print(f'loading {args.town} ...')
            self.client.load_world(args.town)
            time.sleep(5.0)
        self.world = self.client.get_world()
        self.bp = self.world.get_blueprint_library()

        s = self.world.get_settings()
        s.synchronous_mode = True
        s.fixed_delta_seconds = 0.05
        self.world.apply_settings(s)
        self.tm = self.client.get_trafficmanager(args.tm_port)
        self.tm.set_synchronous_mode(True)

        self.out = Path(args.out)
        (self.out / 'images').mkdir(parents=True, exist_ok=True)
        (self.out / 'labels').mkdir(parents=True, exist_ok=True)
        self.K = build_K(args.width, args.height, args.fov)
        self.actors, self.walkers, self.ctrls = [], [], []
        self.counts = {c: 0 for c in CLASSES}
        self.rejected = {c: 0 for c in CLASSES}   # seen but dropped
        self.kept = 0

    # -------------------------------------------------------------- scene
    def spawn(self):
        carla = self.carla
        sps = self.world.get_map().get_spawn_points()
        random.shuffle(sps)

        ego_bp = self.bp.filter('vehicle.lincoln.mkz_2020')
        ego_bp = ego_bp[0] if ego_bp else self.bp.filter('vehicle.*')[0]
        self.ego = self.world.spawn_actor(ego_bp, sps[0])
        self.ego.set_autopilot(True, self.a.tm_port)
        self.actors.append(self.ego)

        # traffic
        for sp in sps[1:1 + self.a.vehicles]:
            b = random.choice(self.bp.filter('vehicle.*'))
            v = self.world.try_spawn_actor(b, sp)
            if v:
                v.set_autopilot(True, self.a.tm_port)
                self.actors.append(v)

        # walkers, concentrated near the ego so they appear in frame often
        wbps = self.bp.filter('walker.pedestrian.*')
        cbp = self.bp.find('controller.ai.walker')
        spawned = 0
        tries = 0
        while spawned < self.a.walkers and tries < self.a.walkers * 30:
            tries += 1
            loc = self.world.get_random_location_from_navigation()
            if loc is None:
                continue
            if self.a.walker_radius > 0:
                et = self.ego.get_transform()
                e = et.location
                if loc.distance(e) > self.a.walker_radius:
                    continue
                # Random navigation points scatter across the whole map, so an
                # ego on autopilot rarely shares a frame with them: the first
                # run spawned 40 walkers and labelled none. Keep points that
                # are roughly ahead of the vehicle.
                fwd = et.get_forward_vector()
                dx, dy = loc.x - e.x, loc.y - e.y
                if (dx * fwd.x + dy * fwd.y) < -5.0:
                    continue
            w = self.world.try_spawn_actor(random.choice(wbps),
                                           carla.Transform(loc))
            if not w:
                continue
            self.walkers.append(w)
            c = self.world.spawn_actor(cbp, carla.Transform(), attach_to=w)
            c.start()
            c.go_to_location(self.world.get_random_location_from_navigation())
            c.set_max_speed(1.2 + random.random())
            self.ctrls.append(c)
            spawned += 1
        print(f'spawned: {len(self.actors)-1} vehicles, {spawned} walkers')

        # cameras: rgb for the image, semantic for the visibility test
        cb = self.bp.find('sensor.camera.rgb')
        sb = self.bp.find('sensor.camera.semantic_segmentation')
        for b in (cb, sb):
            b.set_attribute('image_size_x', str(self.a.width))
            b.set_attribute('image_size_y', str(self.a.height))
            b.set_attribute('fov', str(self.a.fov))
        tf = carla.Transform(
            carla.Location(x=self.a.cam_x, y=self.a.cam_y, z=self.a.cam_z),
            carla.Rotation(pitch=self.a.cam_pitch, yaw=self.a.cam_yaw,
                           roll=self.a.cam_roll))
        self.cam = self.world.spawn_actor(cb, tf, attach_to=self.ego)
        self.sem = self.world.spawn_actor(sb, tf, attach_to=self.ego)
        self.buf = {}
        self.cam.listen(lambda i: self.buf.__setitem__('rgb', i))
        self.sem.listen(lambda i: self.buf.__setitem__('sem', i))

    # -------------------------------------------------------------- labels
    def probe_tags(self, sem_arr, box, top=4):
        """Which semantic tags actually occupy a box. Diagnostic only."""
        x1, y1, x2, y2 = [int(v) for v in box]
        x1, y1 = max(0, x1), max(0, y1)
        x2 = min(sem_arr.shape[1] - 1, x2); y2 = min(sem_arr.shape[0] - 1, y2)
        if x2 <= x1 or y2 <= y1:
            return []
        patch = sem_arr[y1:y2, x1:x2]
        if patch.size == 0:
            return []
        u, c = np.unique(patch, return_counts=True)
        order = np.argsort(-c)[:top]
        return [(int(u[i]), round(float(c[i]) / patch.size, 3)) for i in order]

    def boxes_from_segmentation(self, sem_arr, tag, min_px=6, max_boxes=12):
        """Derive boxes from pixels that actually belong to the class.

        Projecting the traffic-light actor pose put boxes on whatever lay
        behind the lamp: measured tag content inside those boxes was ~43%
        vehicle and ~55% building, with almost no traffic-light pixels, so all
        264 were correctly rejected by the visibility test. Segmentation labels
        the lamp pixels directly, so the box is where the object appears and
        occlusion is handled implicitly.
        """
        import cv2 as _cv
        mask = (sem_arr == tag).astype(np.uint8)
        if int(mask.sum()) < min_px:
            return []
        n, lab, stats, _ = _cv.connectedComponentsWithStats(mask, 8)
        out = []
        for i in range(1, n):
            x, y, w, h, area = stats[i]
            if area < min_px or w < 3 or h < 3:
                continue
            out.append((float(x), float(y), float(x + w), float(y + h)))
        out.sort(key=lambda b: -(b[2] - b[0]) * (b[3] - b[1]))
        return out[:max_boxes]

    def _visible(self, sem_arr, box, tags, min_frac=0.10):
        x1, y1, x2, y2 = [int(v) for v in box]
        x1, y1 = max(0, x1), max(0, y1)
        x2 = min(sem_arr.shape[1] - 1, x2)
        y2 = min(sem_arr.shape[0] - 1, y2)
        if x2 <= x1 or y2 <= y1:
            return False
        patch = sem_arr[y1:y2, x1:x2]
        if patch.size == 0:
            return False
        hit = np.isin(patch, tags).mean()
        return hit >= min_frac

    def labels_for_frame(self, sem_arr):
        carla = self.carla
        cam_tf = self.cam.get_transform()
        W, H = self.a.width, self.a.height
        rows = []

        def emit(cls_name, corners_world, tags):
            cam = world_to_cam(corners_world, cam_tf)
            # A box with corners on both sides of the image plane projects to a
            # meaningless extent: corners behind the camera are dropped and the
            # min/max over survivors spans far too much of the frame. This was
            # producing a large spurious box over the ego bonnet.
            if (cam[:, 2] <= 0.5).any():
                return
            uv, ok = project(cam, self.K)
            if ok.sum() < 8 or uv.shape[0] == 0:
                return
            x1, y1 = uv[:, 0].min(), uv[:, 1].min()
            x2, y2 = uv[:, 0].max(), uv[:, 1].max()
            if x2 < 0 or y2 < 0 or x1 > W or y1 > H:
                return
            x1, y1 = max(0.0, x1), max(0.0, y1)
            x2, y2 = min(float(W), x2), min(float(H), y2)
            bw, bh = x2 - x1, y2 - y1
            if bw < self.a.min_px or bh < self.a.min_px:
                return
            if not self._visible(sem_arr, (x1, y1, x2, y2), tags):
                self.rejected[cls_name] += 1
                return
            cx, cy = (x1 + x2) / 2.0 / W, (y1 + y2) / 2.0 / H
            rows.append(f'{CID[cls_name]} {cx:.6f} {cy:.6f} '
                        f'{bw/W:.6f} {bh/H:.6f}')
            self.counts[cls_name] += 1

        ego_loc = self.ego.get_location()

        for w in self.world.get_actors().filter('walker.pedestrian.*'):
            if w.get_location().distance(ego_loc) > self.a.max_range:
                continue
            emit('pedestrian', bbox_corners(w.bounding_box, w.get_transform()),
                 [SEM['pedestrian'], SEM['rider']])

        for v in self.world.get_actors().filter('vehicle.*'):
            if v.id == self.ego.id:
                continue
            if v.get_location().distance(ego_loc) > self.a.max_range:
                continue
            n = 'cyclist' if int(v.attributes.get('number_of_wheels', 4)) == 2 \
                else 'vehicle'
            tags = [SEM['bicycle'], SEM['motorcycle'], SEM['rider']] if n == 'cyclist' \
                else [SEM['vehicle'], SEM['truck'], SEM['bus']]
            emit(n, bbox_corners(v.bounding_box, v.get_transform()), tags)

        # Traffic lights: the BOX comes from segmentation (the lamp pixels),
        # the COLOUR from the actor state. Note the approximation: the dominant
        # state among nearby lights is assigned to every box, so at an
        # intersection showing red one way and green the other some boxes carry
        # the wrong colour. Per-blob matching to the nearest projected actor is
        # the correct fix and is needed before the final dataset.
        lights = [t for t in self.world.get_actors().filter('traffic.traffic_light')
                  if t.get_location().distance(ego_loc) <= self.a.max_range]
        if lights:
            # Project each light actor to a pixel and keep its own state. The
            # actor pose need not land on the lamp: it only has to be closer to
            # its own lamp than to any other, which lets each segmented blob
            # take the colour of the light it actually belongs to.
            # A global vote over nearby lights was tried first and mislabelled
            # amber lamps as red whenever red was locally dominant, which would
            # have trained the detector never to report amber and disabled the
            # dilemma-zone handling that depends on it.
            STATE_NAME = {carla.TrafficLightState.Red: 'light_red',
                          carla.TrafficLightState.Yellow: 'light_yellow',
                          carla.TrafficLightState.Green: 'light_green'}
            proj = []
            for t in lights:
                lo = t.get_transform().location
                pc = world_to_cam(np.array([[lo.x, lo.y, lo.z]]), cam_tf)
                if pc[0, 2] <= 0.5:
                    continue
                q = (self.K @ pc.T).T
                proj.append((float(q[0, 0] / q[0, 2]),
                             float(q[0, 1] / q[0, 2]),
                             t.get_state()))

            for (bx1, by1, bx2, by2) in self.boxes_from_segmentation(
                    sem_arr, SEM['traffic_light']):
                bw, bh = bx2 - bx1, by2 - by1
                if bw < self.a.min_px or bh < self.a.min_px:
                    continue
                if not proj:
                    continue
                cx, cy = (bx1 + bx2) / 2.0, (by1 + by2) / 2.0
                u, v, st = min(proj, key=lambda q: (q[0] - cx) ** 2
                                                   + (q[1] - cy) ** 2)
                # a blob whose nearest light is implausibly far is not a signal
                if ((u - cx) ** 2 + (v - cy) ** 2) ** 0.5 > self.a.light_match_px:
                    self.rejected['light_red'] = self.rejected.get('light_red', 0) + 1
                    continue
                name = STATE_NAME.get(st)
                if name is None:
                    continue
                rows.append(f'{CID[name]} {cx/W:.6f} {cy/H:.6f} '
                            f'{bw/W:.6f} {bh/H:.6f}')
                self.counts[name] += 1

        # Signs: same reasoning as lights -- derive the box from sign pixels.
        for (bx1, by1, bx2, by2) in self.boxes_from_segmentation(
                sem_arr, SEM['traffic_sign']):
            bw, bh = bx2 - bx1, by2 - by1
            if bw < self.a.min_px or bh < self.a.min_px:
                continue
            rows.append(f"{CID['traffic_sign']} {(bx1+bx2)/2.0/W:.6f} "
                        f"{(by1+by2)/2.0/H:.6f} {bw/W:.6f} {bh/H:.6f}")
            self.counts['traffic_sign'] += 1
        return rows

    # ---------------------------------------------------------------- loop
    def run(self):
        import cv2
        self.spawn()
        for _ in range(40):
            self.world.tick()

        frame = 0
        skipped = 0
        while self.kept < self.a.frames:
            self.world.tick()
            frame += 1
            if frame % self.a.every:
                continue
            if 'rgb' not in self.buf or 'sem' not in self.buf:
                continue
            rgb_i, sem_i = self.buf['rgb'], self.buf['sem']
            rgb = np.frombuffer(rgb_i.raw_data, dtype=np.uint8).reshape(
                (rgb_i.height, rgb_i.width, 4))[:, :, :3]
            sem = np.frombuffer(sem_i.raw_data, dtype=np.uint8).reshape(
                (sem_i.height, sem_i.width, 4))[:, :, 2]

            rows = self.labels_for_frame(sem)
            has_rare = any(int(r.split()[0]) in
                           (CID['pedestrian'], CID['cyclist'],
                            CID['light_red'], CID['light_yellow'])
                           for r in rows)
            # keep every frame containing a rare class; subsample the rest
            if not rows or (not has_rare and random.random() > self.a.keep_common):
                skipped += 1
                continue

            stem = f'{self.a.town.lower()}_{self.kept:06d}'
            cv2.imwrite(str(self.out / 'images' / f'{stem}.jpg'), rgb)
            (self.out / 'labels' / f'{stem}.txt').write_text('\n'.join(rows))
            self.kept += 1
            if self.kept % 100 == 0:
                print(f'  {self.kept}/{self.a.frames} kept ({skipped} skipped)')
                print(f'      labelled: {self.counts}')
                print(f'      rejected by visibility test: {self.rejected}')
        self.finish()

    def finish(self):
        (self.out / 'dataset.yaml').write_text(
            f"path: {self.out}\ntrain: images\nval: images\n"
            f"nc: {len(CLASSES)}\nnames: {CLASSES}\n")
        json.dump({'frames': self.kept, 'instances': self.counts,
                   'rejected_by_visibility': self.rejected,
                   'tags_inside_rejected': {k: v[:5] for k, v
                                            in self.tag_evidence.items()},
                   'rejected_by_visibility': self.rejected,
                   'town': self.a.town, 'rig': {'w': self.a.width,
                                                'h': self.a.height,
                                                'fov': self.a.fov}},
                  open(self.out / 'collection_stats.json', 'w'), indent=2)
        print(f'\n[OK] {self.kept} frames -> {self.out}')
        print(f'     instances: {self.counts}')
        self.cleanup()

    def cleanup(self):
        try:
            self.cam.stop(); self.sem.stop()
            self.cam.destroy(); self.sem.destroy()
        except Exception:
            pass
        for c in self.ctrls:
            try:
                if c.is_alive: c.stop()
            except Exception: pass
        for c in self.ctrls:
            try:
                if c.is_alive: c.destroy()
            except Exception: pass
        for w in self.walkers:
            try:
                if w.is_alive: w.destroy()
            except Exception: pass
        for a in self.actors:
            try: a.destroy()
            except Exception: pass
        s = self.world.get_settings()
        s.synchronous_mode = False
        s.fixed_delta_seconds = None
        self.world.apply_settings(s)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--host', default='192.168.144.1')
    p.add_argument('--port', type=int, default=2000)
    p.add_argument('--tm_port', type=int, default=8000)
    p.add_argument('--town', default='Town12')
    p.add_argument('--frames', type=int, default=4000)
    p.add_argument('--out', default='/mnt/d/NSTM_Project/data/town1213')
    # TransFuser++ rig, overridable
    p.add_argument('--width', type=int, default=1024)
    p.add_argument('--height', type=int, default=256)
    p.add_argument('--fov', type=float, default=110.0)
    p.add_argument('--cam_x', type=float, default=-1.5)
    p.add_argument('--cam_y', type=float, default=0.0)
    p.add_argument('--cam_z', type=float, default=2.0)
    p.add_argument('--cam_pitch', type=float, default=0.0)
    p.add_argument('--cam_yaw', type=float, default=0.0)
    p.add_argument('--cam_roll', type=float, default=0.0)
    p.add_argument('--vehicles', type=int, default=80)
    p.add_argument('--walkers', type=int, default=120)
    p.add_argument('--walker_radius', type=float, default=120.0)
    p.add_argument('--max_range', type=float, default=60.0)
    p.add_argument('--min_px', type=float, default=8.0)
    p.add_argument('--light_match_px', type=float, default=200.0,
                   help='max pixel distance from a blob to its light actor')
    p.add_argument('--every', type=int, default=4)
    p.add_argument('--keep_common', type=float, default=0.25)
    a = p.parse_args()

    c = Collector(a)
    try:
        c.run()
    except KeyboardInterrupt:
        print('\ninterrupted; saving what was collected')
        c.finish()
    except Exception:
        c.cleanup()
        raise


if __name__ == '__main__':
    main()
