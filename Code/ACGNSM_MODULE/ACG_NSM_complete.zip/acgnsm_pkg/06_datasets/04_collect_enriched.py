"""
04_collect_enriched.py
======================
Phase 3a: Enriched collection for YOLO fine-tuning + LiDAR projection.

Adds over Phase 2:
  - camera intrinsic matrix K (saved once per episode in calib.json)
  - camera-to-world transform per tick
  - every actor's 3D bbox + type + world transform per tick
  These let us auto-derive 2D YOLO bounding-box labels and project LiDAR.

5 classes: 0=pedestrian 1=vehicle 2=traffic_light 3=cyclist 4=traffic_sign

USAGE (60 episodes, 15 per scenario):
  python 04_collect_enriched.py --host 192.168.144.1 --episodes 60 \
      --out /mnt/d/NSTM_Project/data/enriched_nstm
"""

import sys, glob, os, random, math, json, time, argparse
from pathlib import Path
from queue import Queue, Empty
import numpy as np
import carla
print("[OK] carla imported (pip)")

SCENARIOS = ["left_turn_signalized", "pedestrian_crossing", "highway_cutin", "adverse_weather"]
TICKS = 200
DT = 0.1
IMG_W = 800
IMG_H = 600
FOV = 90.0

# class mapping
CLASS_PED = 0
CLASS_VEH = 1
CLASS_TL = 2
CLASS_CYC = 3
CLASS_SIGN = 4


# ---------- camera intrinsics ----------
def build_intrinsics():
    f = IMG_W / (2.0 * math.tan(FOV * math.pi / 360.0))
    K = np.array([[f, 0, IMG_W / 2.0],
                  [0, f, IMG_H / 2.0],
                  [0, 0, 1.0]])
    return K


def actor_class(actor):
    tid = actor.type_id
    if tid.startswith('walker.pedestrian'):
        return CLASS_PED
    if tid.startswith('vehicle'):
        # crude cyclist detection
        if 'bike' in tid or 'cycle' in tid or 'omafiets' in tid or 'crossbike' in tid:
            return CLASS_CYC
        return CLASS_VEH
    if tid.startswith('traffic.traffic_light'):
        return CLASS_TL
    if tid.startswith('traffic.') and 'traffic_light' not in tid:
        return CLASS_SIGN
    return None


# ---------- GT label helpers (same as before) ----------
def get_obs_dist(ego, world, max_range=80.0):
    el = ego.get_location(); ef = ego.get_transform().get_forward_vector()
    best = max_range
    for a in world.get_actors():
        if a.id == ego.id: continue
        if not (a.type_id.startswith('vehicle') or a.type_id.startswith('walker')): continue
        loc = a.get_location(); d = loc.distance(el)
        if d >= max_range: continue
        dx, dy = loc.x-el.x, loc.y-el.y; n = max(math.sqrt(dx*dx+dy*dy), 1e-6)
        if ef.x*(dx/n)+ef.y*(dy/n) > 0.65: best = min(best, d)
    return round(best, 2) if best < max_range else -1.0

def get_speed(ego):
    v = ego.get_velocity(); return round(3.6*math.sqrt(v.x**2+v.y**2+v.z**2), 2)

def get_ped(ego, world):
    el = ego.get_location()
    for a in world.get_actors():
        if a.type_id.startswith('walker.pedestrian') and a.get_location().distance(el) < 20: return 1
    return 0

def get_oncoming(ego, world):
    el = ego.get_location(); ef = ego.get_transform().get_forward_vector()
    for a in world.get_actors():
        if a.id == ego.id or not a.type_id.startswith('vehicle'): continue
        if a.get_location().distance(el) > 50: continue
        v = a.get_velocity(); s = math.sqrt(v.x**2+v.y**2)
        if s < 0.5: continue
        if ef.x*(v.x/s)+ef.y*(v.y/s) < -0.55: return 1
    return 0

def get_tl(ego):
    t = ego.get_traffic_light()
    if t is None: return -1
    st = t.get_state()
    if st == carla.TrafficLightState.Red: return 0
    if st == carla.TrafficLightState.Green: return 1
    if st == carla.TrafficLightState.Yellow: return 2
    return -1

def dist_tier(d):
    if d < 0: return 0
    if d > 50: return 1
    if d > 20: return 2
    return 3

def spd_tier(s):
    if s == 0: return 0
    if s <= 30: return 1
    if s <= 60: return 2
    return 3

def set_weather(world, preset='clear'):
    presets = {'clear': carla.WeatherParameters.ClearNoon,
               'rain': carla.WeatherParameters(cloudiness=80, precipitation=70, precipitation_deposits=50, wetness=80),
               'fog': carla.WeatherParameters(cloudiness=90, fog_density=50, fog_distance=15)}
    world.set_weather(presets.get(preset, presets['clear']))


def get_actor_bboxes(world, ego, max_range=80.0):
    """Return list of actor 3D bbox info for labeling."""
    out = []
    el = ego.get_location()
    for a in world.get_actors():
        if a.id == ego.id: continue
        cls = actor_class(a)
        if cls is None: continue
        loc = a.get_location()
        if loc.distance(el) > max_range: continue
        try:
            bb = a.bounding_box
            tf = a.get_transform()
            out.append({
                "id": a.id, "class": cls,
                "loc": [loc.x, loc.y, loc.z],
                "extent": [bb.extent.x, bb.extent.y, bb.extent.z],
                "bb_loc": [bb.location.x, bb.location.y, bb.location.z],
                "yaw": tf.rotation.yaw,
                "pitch": tf.rotation.pitch,
                "roll": tf.rotation.roll,
            })
        except Exception:
            pass
    return out


def attach_sensors(world, bl, ego):
    sensors, queues = {}, {}
    cam_bp = bl.find('sensor.camera.rgb')
    cam_bp.set_attribute('image_size_x', str(IMG_W))
    cam_bp.set_attribute('image_size_y', str(IMG_H))
    cam_bp.set_attribute('fov', str(FOV))
    cam_tf = carla.Transform(carla.Location(x=1.5, z=2.0))
    cam = world.spawn_actor(cam_bp, cam_tf, attach_to=ego)
    q_cam = Queue(); cam.listen(lambda d: q_cam.put(d))
    sensors['rgb'] = cam; queues['rgb'] = q_cam

    lidar_bp = bl.find('sensor.lidar.ray_cast')
    lidar_bp.set_attribute('channels', '32')
    lidar_bp.set_attribute('range', '80')
    lidar_bp.set_attribute('points_per_second', '300000')
    lidar_bp.set_attribute('rotation_frequency', '10')
    lidar_tf = carla.Transform(carla.Location(x=0.0, z=2.4))
    lidar = world.spawn_actor(lidar_bp, lidar_tf, attach_to=ego)
    q_lidar = Queue(); lidar.listen(lambda d: q_lidar.put(d))
    sensors['lidar'] = lidar; queues['lidar'] = q_lidar

    gnss_bp = bl.find('sensor.other.gnss')
    gnss = world.spawn_actor(gnss_bp, carla.Transform(), attach_to=ego)
    q_gnss = Queue(); gnss.listen(lambda d: q_gnss.put(d))
    sensors['gnss'] = gnss; queues['gnss'] = q_gnss

    return sensors, queues


def save_rgb(image, path):
    import cv2
    arr = np.frombuffer(image.raw_data, dtype=np.uint8).reshape((image.height, image.width, 4))[:, :, :3]
    cv2.imwrite(str(path), arr)


def save_lidar(points, path):
    arr = np.frombuffer(points.raw_data, dtype=np.float32).reshape((-1, 4))
    np.save(str(path), arr)


def run_episode(client, world, scenario, ep_id, out_dir):
    bl = world.get_blueprint_library()
    tm = client.get_trafficmanager(8000); tm.set_synchronous_mode(True)
    cfg = world.get_settings(); cfg.synchronous_mode = True; cfg.fixed_delta_seconds = DT
    world.apply_settings(cfg)

    if scenario == 'highway_cutin': set_weather(world, 'clear')
    elif scenario == 'adverse_weather': set_weather(world, random.choice(['rain', 'fog']))
    else: set_weather(world, 'clear')

    sps = world.get_map().get_spawn_points()
    ebp = bl.filter('vehicle.tesla.model3')[0]
    ego = None
    for _ in range(30):
        ego = world.try_spawn_actor(ebp, random.choice(sps))
        if ego: break
    if ego is None: raise RuntimeError("Cannot spawn ego")
    ego.set_autopilot(True, tm.get_port())
    if scenario == 'highway_cutin': tm.vehicle_percentage_speed_difference(ego, -40)

    npcs = []
    for _ in range(8):
        bp = random.choice(bl.filter('vehicle.*'))
        npc = world.try_spawn_actor(bp, random.choice(sps))
        if npc:
            npc.set_autopilot(True, tm.get_port()); npcs.append(npc)

    if scenario in ('left_turn_signalized', 'pedestrian_crossing'):
        for _ in range(6):
            wbp = random.choice(bl.filter('walker.pedestrian.*'))
            wloc = random.choice(sps).location; wloc.z += 0.5
            walker = world.try_spawn_actor(wbp, carla.Transform(wloc))
            if walker:
                wc_bp = bl.find('controller.ai.walker')
                wc = world.try_spawn_actor(wc_bp, carla.Transform(), attach_to=walker)
                if wc:
                    world.tick(); wc.start()
                    dest = world.get_random_location_from_navigation()
                    if dest: wc.go_to_location(dest)
                    wc.set_max_speed(1.0 + random.random())
                    npcs.append(wc)
                npcs.append(walker)

    sensors, queues = attach_sensors(world, bl, ego)
    cam = sensors['rgb']

    ep_dir = Path(out_dir) / scenario / ("episode_%04d" % ep_id)
    (ep_dir / "rgb").mkdir(parents=True, exist_ok=True)
    (ep_dir / "lidar").mkdir(parents=True, exist_ok=True)

    # save camera intrinsics once
    K = build_intrinsics()
    with open(str(ep_dir / "calib.json"), 'w') as f:
        json.dump({"K": K.tolist(), "img_w": IMG_W, "img_h": IMG_H, "fov": FOV,
                   "cam_x": 1.5, "cam_z": 2.0, "lidar_z": 2.4}, f, indent=2)

    records = []
    gnss_records = []

    for _ in range(5):
        world.tick()
        for q in queues.values():
            try: q.get(timeout=2.0)
            except Empty: pass

    try:
        for tick in range(TICKS):
            world.tick()
            try:
                img = queues['rgb'].get(timeout=2.0)
                save_rgb(img, ep_dir / "rgb" / ("%03d.jpg" % tick))
            except Empty: pass
            try:
                pts = queues['lidar'].get(timeout=2.0)
                save_lidar(pts, ep_dir / "lidar" / ("%03d.npy" % tick))
            except Empty: pass
            glat = glon = galt = 0.0
            try:
                g = queues['gnss'].get(timeout=2.0)
                glat, glon, galt = g.latitude, g.longitude, g.altitude
            except Empty: pass

            d = get_obs_dist(ego, world); s = get_speed(ego)
            loc = ego.get_location(); tf = ego.get_transform()
            cam_tf = cam.get_transform()
            cam_matrix = np.array(cam_tf.get_matrix())  # cam-to-world

            actors = get_actor_bboxes(world, ego)

            records.append({
                "episode_id": ep_id, "scenario": scenario, "tick": tick,
                "timestamp_s": round(tick*DT, 1),
                "ego_x": round(loc.x, 2), "ego_y": round(loc.y, 2),
                "ego_yaw": round(tf.rotation.yaw, 2),
                "ObsDist_gt": d, "EgoSpd_gt": s,
                "Pedestrian_gt": get_ped(ego, world),
                "Oncoming_gt": get_oncoming(ego, world),
                "TrafficLight_gt": get_tl(ego),
                "DistTier_gt": dist_tier(d), "SpdTier_gt": spd_tier(s),
                "rgb": "rgb/%03d.jpg" % tick,
                "lidar": "lidar/%03d.npy" % tick,
                "cam_to_world": cam_matrix.tolist(),
                "actors": actors,
            })
            gnss_records.append({"tick": tick, "lat": glat, "lon": glon, "alt": galt})

    finally:
        for sv in sensors.values():
            try: sv.stop(); sv.destroy()
            except: pass
        for a in npcs:
            try: a.destroy()
            except: pass
        try: ego.destroy()
        except: pass
        try: world.tick()
        except: pass
        cfg.synchronous_mode = False; cfg.fixed_delta_seconds = 0.0
        try: world.apply_settings(cfg)
        except: pass

    with open(str(ep_dir / "meta.json"), 'w') as f:
        json.dump(records, f, indent=2)
    with open(str(ep_dir / "gnss.json"), 'w') as f:
        json.dump(gnss_records, f, indent=2)
    return len(records)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--host', default='192.168.144.1')
    p.add_argument('--port', type=int, default=2000)
    p.add_argument('--episodes', type=int, default=60)
    p.add_argument('--out', default='/mnt/d/NSTM_Project/data/enriched_nstm')
    args = p.parse_args()

    print("Connecting to %s:%d" % (args.host, args.port))
    client = carla.Client(args.host, args.port); client.set_timeout(60.0)
    client.get_server_version(); print("[OK] connected")
    world = client.get_world(); time.sleep(2)
    print("[OK] world: %s" % world.get_map().name)
    print("[OK] %d spawn points" % len(world.get_map().get_spawn_points()))

    per = max(1, args.episodes // len(SCENARIOS))
    total = 0
    for scenario in SCENARIOS:
        print("\n=== %s (%d episodes) ===" % (scenario, per))
        for ep in range(per):
            print("Episode %d/%d ..." % (ep+1, per), end=' ', flush=True)
            try:
                n = run_episode(client, world, scenario, ep, args.out)
                total += n; print("[OK] %d ticks" % n)
            except Exception as e:
                import traceback; print("[ERR] %s" % e); traceback.print_exc()

    print("\nDone! Total ticks: %d" % total)
    print("Saved to: %s" % args.out)


if __name__ == '__main__':
    main()
