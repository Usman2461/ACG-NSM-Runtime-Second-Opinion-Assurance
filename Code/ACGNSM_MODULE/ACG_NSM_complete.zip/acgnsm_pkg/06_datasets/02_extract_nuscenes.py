import sys
import os
import json
import math
import argparse
from pathlib import Path

try:
    from nuscenes.nuscenes import NuScenes
    import numpy as np
    from pyquaternion import Quaternion
    print("[OK] nuscenes-devkit imported")
except ImportError as e:
    print("[ERROR]", e)
    print("Run: pip install nuscenes-devkit pyquaternion numpy")
    sys.exit(1)


def get_ego_speed(nusc, sample):
    lidar_token = sample['data']['LIDAR_TOP']
    lidar_data = nusc.get('sample_data', lidar_token)
    ego_pose = nusc.get('ego_pose', lidar_data['ego_pose_token'])
    x = ego_pose['translation'][0]
    y = ego_pose['translation'][1]
    speed_kmh = 0.0
    if lidar_data['prev']:
        prev_data = nusc.get('sample_data', lidar_data['prev'])
        prev_pose = nusc.get('ego_pose', prev_data['ego_pose_token'])
        dt = (lidar_data['timestamp'] - prev_data['timestamp']) / 1e6
        if dt > 0:
            dx = x - prev_pose['translation'][0]
            dy = y - prev_pose['translation'][1]
            speed_kmh = round(math.sqrt(dx * dx + dy * dy) / dt * 3.6, 2)
    return round(x, 2), round(y, 2), speed_kmh


def get_annotations(nusc, sample, ego_x, ego_y):
    lidar_token = sample['data']['LIDAR_TOP']
    lidar_data = nusc.get('sample_data', lidar_token)
    ego_pose = nusc.get('ego_pose', lidar_data['ego_pose_token'])
    ego_q = Quaternion(ego_pose['rotation'])
    ego_fwd = ego_q.rotate([1, 0, 0])

    obs_dist = -1.0
    pedestrian = 0
    oncoming = 0

    for ann_token in sample['anns']:
        ann = nusc.get('sample_annotation', ann_token)
        cat = ann['category_name']
        ax = ann['translation'][0]
        ay = ann['translation'][1]
        dx = ax - ego_x
        dy = ay - ego_y
        dist = math.sqrt(dx * dx + dy * dy)

        if 'pedestrian' in cat and dist < 20.0:
            pedestrian = 1

        if dist < 80.0 and ('vehicle' in cat or 'pedestrian' in cat):
            if dist > 0:
                dot = ego_fwd[0] * (dx / dist) + ego_fwd[1] * (dy / dist)
                if dot > 0.65:
                    if obs_dist < 0 or dist < obs_dist:
                        obs_dist = round(dist, 2)

        if 'vehicle' in cat and dist < 40.0:
            vel = ann.get('velocity', [0, 0])
            if vel is None:
                vel = [0, 0]
            speed = math.sqrt(vel[0] ** 2 + vel[1] ** 2)
            if speed > 0.5 and dist > 0:
                vx_n = vel[0] / speed
                vy_n = vel[1] / speed
                dot = ego_fwd[0] * vx_n + ego_fwd[1] * vy_n
                if dot < -0.55:
                    oncoming = 1

    return obs_dist, pedestrian, oncoming


def dist_tier(d):
    if d < 0:
        return 0
    if d > 50:
        return 1
    if d > 20:
        return 2
    return 3


def spd_tier(s):
    if s == 0:
        return 0
    if s <= 30:
        return 1
    if s <= 60:
        return 2
    return 3


def extract_scene(nusc, scene):
    records = []
    sample_token = scene['first_sample_token']
    tick = 0
    while sample_token:
        sample = nusc.get('sample', sample_token)
        ego_x, ego_y, ego_speed = get_ego_speed(nusc, sample)
        obs_dist, pedestrian, oncoming = get_annotations(nusc, sample, ego_x, ego_y)
        traffic_light = -1

        records.append({
            "scene_token": scene['token'],
            "sample_token": sample_token,
            "tick": tick,
            "timestamp_us": sample['timestamp'],
            "ego_x": ego_x,
            "ego_y": ego_y,
            "ObsDist_gt": obs_dist,
            "EgoSpd_gt": ego_speed,
            "Pedestrian_gt": pedestrian,
            "Oncoming_gt": oncoming,
            "TrafficLight_gt": traffic_light,
            "DistTier_gt": dist_tier(obs_dist),
            "SpdTier_gt": spd_tier(ego_speed),
            "ObsDist_pred": None,
            "EgoSpd_pred": None,
            "Pedestrian_pred": None,
            "Oncoming_pred": None,
            "TrafficLight_pred": None,
            "conf_label": {
                "ObsDist": None,
                "EgoSpd": None,
                "Pedestrian": None,
                "Oncoming": None,
                "TrafficLight": None
            }
        })
        sample_token = sample['next']
        tick += 1
    return records


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--nuscenes', default=r'D:\Datasets\nuscenes')
    parser.add_argument('--version', default='v1.0-mini')
    parser.add_argument('--out', default=r'data\nuscenes_tokens')
    args = parser.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    print("Loading nuScenes " + args.version + " from " + args.nuscenes)
    print("This may take 30-60 seconds...")

    try:
        nusc = NuScenes(version=args.version, dataroot=args.nuscenes, verbose=True)
    except Exception as e:
        print("[ERROR] Cannot load nuScenes: " + str(e))
        print("Check that " + args.nuscenes + " contains the nuScenes files.")
        sys.exit(1)

    n_scenes = len(nusc.scene)
    print("[OK] Loaded " + str(n_scenes) + " scenes.")

    if 'mini' in args.version:
        train_scenes = nusc.scene[:8]
        val_scenes = nusc.scene[8:]
        print("Mini split: " + str(len(train_scenes)) + " train / " + str(len(val_scenes)) + " val")
    else:
        train_scenes = nusc.scene[:700]
        val_scenes = nusc.scene[700:]
        print("Full split: " + str(len(train_scenes)) + " train / " + str(len(val_scenes)) + " val")

    print("\nExtracting " + str(len(train_scenes)) + " training scenes...")
    train_records = []
    for i, scene in enumerate(train_scenes):
        recs = extract_scene(nusc, scene)
        train_records.extend(recs)
        print("  Scene " + str(i + 1) + "/" + str(len(train_scenes)) + ": " + scene['name'] + " — " + str(len(recs)) + " samples")

    train_path = out_dir / 'tokens_train.json'
    with open(str(train_path), 'w') as f:
        json.dump(train_records, f, indent=2)
    print("[OK] Saved " + str(len(train_records)) + " train records -> " + str(train_path))

    print("\nExtracting " + str(len(val_scenes)) + " validation scenes...")
    val_records = []
    for i, scene in enumerate(val_scenes):
        recs = extract_scene(nusc, scene)
        val_records.extend(recs)
        print("  Scene " + str(i + 1) + "/" + str(len(val_scenes)) + ": " + scene['name'] + " — " + str(len(recs)) + " samples")

    val_path = out_dir / 'tokens_val.json'
    with open(str(val_path), 'w') as f:
        json.dump(val_records, f, indent=2)
    print("[OK] Saved " + str(len(val_records)) + " val records -> " + str(val_path))

    print("\n" + "=" * 50)
    print("nuScenes extraction complete!")
    print("  Train records : " + str(len(train_records)))
    print("  Val records   : " + str(len(val_records)))
    print("  Output folder : " + str(out_dir.resolve()))

    obs_present = sum(1 for r in train_records if r['ObsDist_gt'] > 0)
    ped_present = sum(1 for r in train_records if r['Pedestrian_gt'] == 1)
    onc_present = sum(1 for r in train_records if r['Oncoming_gt'] == 1)
    print("\nTrain statistics:")
    print("  Ticks with obstacle  : " + str(obs_present) + " / " + str(len(train_records)))
    print("  Ticks with pedestrian: " + str(ped_present))
    print("  Ticks with oncoming  : " + str(onc_present))
    print("\nNext: run src\\03_train_spt.py")


if __name__ == '__main__':
    main()
