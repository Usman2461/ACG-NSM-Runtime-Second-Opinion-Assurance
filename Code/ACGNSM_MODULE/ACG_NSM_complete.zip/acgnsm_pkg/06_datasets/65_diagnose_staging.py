"""
65_diagnose_staging.py
======================
Why staged pedestrian scenes produce no labels.

The staged collector reaches its capture loop and spawns walkers, yet no frame
contains a pedestrian label. Four causes are plausible and they need different
fixes, so this measures rather than assumes:

  1. the ego teleport silently fails, leaving the camera elsewhere
  2. walkers spawn behind the camera or outside its field of view
  3. walkers are beyond the labeller's range filter
  4. the visibility test rejects them

One staged scene is run with every intermediate quantity printed.
"""
import argparse, importlib.util, math, random
from pathlib import Path
import numpy as np

SRC = Path(__file__).resolve().parent


def _load(n, p):
    s = importlib.util.spec_from_file_location(n, str(p))
    m = importlib.util.module_from_spec(s); s.loader.exec_module(m); return m


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--host', default='192.168.144.1')
    ap.add_argument('--port', type=int, default=2000)
    ap.add_argument('--dist', type=float, default=12.0)
    a = ap.parse_args()

    import carla
    cl = carla.Client(a.host, a.port); cl.set_timeout(60.0)
    w = cl.get_world(); bp = w.get_blueprint_library()
    s = w.get_settings(); s.synchronous_mode = True; s.fixed_delta_seconds = 0.05
    w.apply_settings(s)

    try:
        # --- pick a staging site the same way the collector does ---
        sites = []
        try:
            xs = w.get_map().get_crosswalks()
            for i in range(0, max(0, len(xs) - 4), 5):
                poly = xs[i:i+5]
                sites.append(carla.Location(
                    x=sum(p.x for p in poly)/len(poly),
                    y=sum(p.y for p in poly)/len(poly),
                    z=sum(p.z for p in poly)/len(poly)))
        except Exception as e:
            print('get_crosswalks failed:', e)
        print(f'crosswalk sites: {len(sites)}')
        if not sites:
            for wp in w.get_map().generate_waypoints(6.0):
                if wp.is_junction:
                    sites.append(wp.transform.location)
            print(f'junction fallback sites: {len(sites)}')
        site = sites[len(sites)//2]
        print(f'site: ({site.x:.1f}, {site.y:.1f}, {site.z:.1f})')

        # --- ego, teleported to view the site ---
        ego = w.spawn_actor(bp.filter('vehicle.*')[0],
                            w.get_map().get_spawn_points()[0])
        wp = w.get_map().get_waypoint(site, project_to_road=True,
                                      lane_type=carla.LaneType.Driving)
        print('waypoint found:', wp is not None)
        prev = wp.previous(a.dist) if wp else []
        print('previous() returned:', len(prev))
        if not prev:
            print('[CAUSE] no lane point behind the site; view pose unavailable')
            ego.destroy(); return
        tf = prev[0].transform
        yaw = math.degrees(math.atan2(site.y - tf.location.y,
                                      site.x - tf.location.x))
        pose = carla.Transform(
            carla.Location(tf.location.x, tf.location.y, tf.location.z + 0.3),
            carla.Rotation(yaw=yaw))
        ego.set_transform(pose)
        for _ in range(10): w.tick()
        got = ego.get_transform()
        moved = got.location.distance(pose.location)
        print(f'teleport requested ({pose.location.x:.1f},{pose.location.y:.1f}) '
              f'actual ({got.location.x:.1f},{got.location.y:.1f}) '
              f'error {moved:.2f} m')
        if moved > 3.0:
            print('[CAUSE 1] teleport did not take effect')
        print(f'ego -> site distance: {got.location.distance(site):.1f} m')

        # --- camera ---
        cb = bp.find('sensor.camera.rgb')
        sb = bp.find('sensor.camera.semantic_segmentation')
        for b in (cb, sb):
            b.set_attribute('image_size_x','1024'); b.set_attribute('image_size_y','256')
            b.set_attribute('fov','110')
        ctf = carla.Transform(carla.Location(x=-1.5, z=2.0))
        cam = w.spawn_actor(cb, ctf, attach_to=ego)
        sem = w.spawn_actor(sb, ctf, attach_to=ego)
        buf = {}
        cam.listen(lambda i: buf.__setitem__('rgb', i))
        sem.listen(lambda i: buf.__setitem__('sem', i))

        # --- walkers around the site ---
        wbps = bp.filter('walker.pedestrian.*')
        made, walkers = 0, []
        for _ in range(60):
            if made >= 8: break
            ang, rad = random.uniform(0, 6.28), random.uniform(0.5, 5.0)
            loc = carla.Location(site.x + rad*math.cos(ang),
                                 site.y + rad*math.sin(ang), site.z + 1.0)
            ww = w.try_spawn_actor(random.choice(wbps), carla.Transform(loc))
            if ww: walkers.append(ww); made += 1
        print(f'walkers spawned: {made}')
        if made == 0:
            print('[CAUSE] walkers cannot spawn at this site')

        for _ in range(15): w.tick()

        # --- where are they relative to the camera? ---
        ctf_world = cam.get_transform()
        fwd = ctf_world.get_forward_vector()
        inframe = 0
        for ww in walkers:
            d = ww.get_location() - ctf_world.location
            ahead = d.x*fwd.x + d.y*fwd.y
            dist = (d.x**2 + d.y**2)**0.5
            ang = math.degrees(math.acos(max(-1,min(1, ahead/max(dist,1e-6)))))
            mark = 'in view' if (ahead > 0 and ang < 55) else 'OUT'
            if mark == 'in view': inframe += 1
            print(f'   walker  dist {dist:5.1f} m  bearing {ang:5.1f} deg  {mark}')
        print(f'walkers plausibly in frame: {inframe}/{made}')
        if inframe == 0:
            print('[CAUSE 2] walkers are outside the camera field of view')

        # --- does the semantic camera actually see pedestrian pixels? ---
        for _ in range(5): w.tick()
        if 'sem' in buf:
            si = buf['sem']
            arr = np.frombuffer(si.raw_data, dtype=np.uint8).reshape(
                (si.height, si.width, 4))[:, :, 2]
            u, c = np.unique(arr, return_counts=True)
            top = sorted(zip(u.tolist(), c.tolist()), key=lambda x: -x[1])[:8]
            print('semantic tags in frame:', top)
            ped_px = int((arr == 12).sum())
            print(f'pedestrian-tag (12) pixels: {ped_px}')
            if ped_px == 0 and inframe > 0:
                print('[CAUSE] walkers in view but no pedestrian pixels: '
                      'the semantic tag for pedestrians is not 12 on this build')

        cam.stop(); sem.stop(); cam.destroy(); sem.destroy()
        for ww in walkers:
            try: ww.destroy()
            except Exception: pass
        ego.destroy()
    finally:
        s = w.get_settings(); s.synchronous_mode = False
        s.fixed_delta_seconds = None; w.apply_settings(s)


if __name__ == '__main__':
    main()
