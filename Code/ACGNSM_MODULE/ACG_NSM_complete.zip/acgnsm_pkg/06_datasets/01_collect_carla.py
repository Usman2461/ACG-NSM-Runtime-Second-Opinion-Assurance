import sys
import glob
import random
import math
import json
import time
import argparse
import traceback
from pathlib import Path

# Add CARLA egg to path
eggs = glob.glob(r'D:\CARLA_0.9.15\WindowsNoEditor\PythonAPI\carla\dist\*.egg')
if eggs:
    sys.path.insert(0, eggs[0])
    print("[OK] egg loaded:", eggs[0])
else:
    print("[ERROR] No CARLA egg found")
    sys.exit(1)

import carla
print("[OK] carla imported")

SCENARIOS = ["left_turn_signalized", "pedestrian_crossing", "highway_cutin", "adverse_weather"]
TICKS = 200
DT = 0.1


def get_obs_dist(ego, world, max_range=80.0):
    ego_loc = ego.get_location()
    ego_fwd = ego.get_transform().get_forward_vector()
    best = max_range
    for actor in world.get_actors():
        if actor.id == ego.id:
            continue
        if not (actor.type_id.startswith('vehicle') or actor.type_id.startswith('walker')):
            continue
        loc = actor.get_location()
        dist = loc.distance(ego_loc)
        if dist >= max_range:
            continue
        dx = loc.x - ego_loc.x
        dy = loc.y - ego_loc.y
        norm = max(math.sqrt(dx * dx + dy * dy), 1e-6)
        dot = ego_fwd.x * (dx / norm) + ego_fwd.y * (dy / norm)
        if dot > 0.65:
            best = min(best, dist)
    return round(best, 2) if best < max_range else -1.0


def get_speed(ego):
    v = ego.get_velocity()
    return round(3.6 * math.sqrt(v.x**2 + v.y**2 + v.z**2), 2)


def get_ped(ego, world):
    el = ego.get_location()
    for a in world.get_actors():
        if a.type_id.startswith('walker.pedestrian'):
            if a.get_location().distance(el) < 20:
                return 1
    return 0


def get_oncoming(ego, world):
    el = ego.get_location()
    ef = ego.get_transform().get_forward_vector()
    for a in world.get_actors():
        if a.id == ego.id or not a.type_id.startswith('vehicle'):
            continue
        if a.get_location().distance(el) > 50:
            continue
        v = a.get_velocity()
        s = math.sqrt(v.x**2 + v.y**2)
        if s < 0.5:
            continue
        if ef.x * (v.x / s) + ef.y * (v.y / s) < -0.55:
            return 1
    return 0


def get_tl(ego):
    t = ego.get_traffic_light()
    if t is None:
        return -1
    state = t.get_state()
    if state == carla.TrafficLightState.Red:
        return 0
    if state == carla.TrafficLightState.Green:
        return 1
    if state == carla.TrafficLightState.Yellow:
        return 2
    return -1


def dist_tier(d):
    if d < 0:
        return 0
    if d > 50:
        return 1
    if d > 20:
        return 2
    return 3


def spd_tier(s):
    if s == 0:
        return 0
    if s <= 30:
        return 1
    if s <= 60:
        return 2
    return 3


def run_episode(client, world, scenario, ep_id, out_dir):
    print("  [1] blueprint library")
    bl = world.get_blueprint_library()

    print("  [2] traffic manager")
    tm = client.get_trafficmanager(8000)
    tm.set_synchronous_mode(True)

    print("  [3] sync mode on")
    cfg = world.get_settings()
    cfg.synchronous_mode = True
    cfg.fixed_delta_seconds = DT
    world.apply_settings(cfg)

    print("  [4] spawning ego")
    sps = world.get_map().get_spawn_points()
    ebp = bl.filter('vehicle.tesla.model3')[0]
    ego = None
    for _ in range(30):
        ego = world.try_spawn_actor(ebp, random.choice(sps))
        if ego:
            break
    if ego is None:
        raise RuntimeError("Cannot spawn ego after 30 attempts")
    print("  [5] ego id=" + str(ego.id))
    ego.set_autopilot(True, tm.get_port())

    print("  [6] spawning npcs")
    npcs = []
    vbps = bl.filter('vehicle.*')
    for _ in range(6):
        bp = random.choice(vbps)
        npc = world.try_spawn_actor(bp, random.choice(sps))
        if npc:
            npc.set_autopilot(True, tm.get_port())
            npcs.append(npc)
    print("  [7] " + str(len(npcs)) + " npcs ready. Starting ticks...")

    records = []
    try:
        for tick in range(TICKS):
            world.tick()
            if tick % 50 == 0:
                print("  [tick " + str(tick) + "/" + str(TICKS) + "]")

            d = get_obs_dist(ego, world)
            s = get_speed(ego)
            loc = ego.get_location()

            records.append({
                "episode_id": ep_id,
                "scenario": scenario,
                "tick": tick,
                "timestamp_s": round(tick * DT, 1),
                "ego_x": round(loc.x, 2),
                "ego_y": round(loc.y, 2),
                "ObsDist_gt": d,
                "EgoSpd_gt": s,
                "Pedestrian_gt": get_ped(ego, world),
                "Oncoming_gt": get_oncoming(ego, world),
                "TrafficLight_gt": get_tl(ego),
                "DistTier_gt": dist_tier(d),
                "SpdTier_gt": spd_tier(s),
                "ObsDist_pred": None,
                "EgoSpd_pred": None,
                "Pedestrian_pred": None,
                "Oncoming_pred": None,
                "TrafficLight_pred": None,
                "conf_label": {
                    "ObsDist": None,
                    "EgoSpd": None,
                    "Pedestrian": None,
                    "Oncoming": None,
                    "TrafficLight": None
                }
            })


    finally:

        print("  [8] cleanup")
        for a in npcs:
            try:
                a.destroy()
            except Exception:
                pass
        try:
            ego.destroy()
        except Exception:
            pass
        try:
            world.tick()
        except Exception:
            pass
        cfg.synchronous_mode = False
        cfg.fixed_delta_seconds = 0.0
        try:
            world.apply_settings(cfg)
        except Exception:
            pass

    out_path = Path(out_dir) / scenario / ("episode_" + str(ep_id).zfill(4) + ".json")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(str(out_path), 'w') as f:
        json.dump(records, f, indent=2)
    print("  [9] saved -> " + str(out_path))
    return len(records)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--host', default='localhost')
    parser.add_argument('--port', type=int, default=2000)
    parser.add_argument('--episodes', type=int, default=500)
    parser.add_argument('--out', default='data/carla_nstm')
    args = parser.parse_args()

    print("Connecting to " + args.host + ":" + str(args.port))
    client = carla.Client(args.host, args.port)
    client.set_timeout(60.0)
    client.get_server_version()
    print("[OK] connected to CARLA server")

    world = client.get_world()
    time.sleep(2)
    map_name = world.get_map().name
    n_spawns = len(world.get_map().get_spawn_points())
    print("[OK] world: " + map_name)
    print("[OK] " + str(n_spawns) + " spawn points")

    per = max(1, args.episodes // len(SCENARIOS))
    total = 0

    for scenario in SCENARIOS:
        print("\n=== " + scenario + " (" + str(per) + " episodes) ===")
        for ep in range(per):
            print("Episode " + str(ep + 1) + "/" + str(per))
            try:
                n = run_episode(client, world, scenario, ep, args.out)
                total += n
                print("[OK] " + str(n) + " ticks saved")
            except Exception as e:
                print("[ERR] " + str(e))
                traceback.print_exc()

    print("\nDone! Total ticks: " + str(total))


if __name__ == '__main__':
    main()
