"""
13_rlc_bridge.py
================
Phase 5c: The RLC Bridge (Risk-Legality-Confidence Bridge).
THE CORE CONTRIBUTION.

Sits between the learned/physics assessors and the formal ZIPC STM.
Four stages per tick:

  Stage 1 - CONFIDENCE GATE: each perception input checked against theta
            threshold. Untrusted inputs trigger fail-safe behavior.
  Stage 2 - RISK QUANTIZATION: R -> tier -> EV_RISK_* event (with hysteresis).
  Stage 3 - LEGALITY ENCODING: LegalMask -> Param.ram + EV_* events on change.
  Stage 4 - OUTPUT + AUDIT: structured {events, ram, audit} dict.

Output dict (consumed by ZIPC STM adapter in Phase 6):
  {
    'events': ['EV_RISK_MED', 'EV_ILLEGAL_PROCEED', ...],
    'ram':    {'RiskTier': 1, 'RiskScore': 55, 'LegalMask': 0b111100,
               'ViolationArticle': 38, 'RSSMargin': ...},
    'audit':  { full causal record for ISO 26262 }
  }
"""
import sys, math, json
sys.path.insert(0, '/mnt/d/NSTM_Project/src')

# import the two assessors
import importlib.util
def _load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m

risk_mod = _load('risk', '/mnt/d/NSTM_Project/src/11_risk_assessor.py')
legal_mod = _load('legal', '/mnt/d/NSTM_Project/src/12_legality_assessor.py')


# ---- confidence thresholds (theta gate) - base values, adaptable in Phase 7 ----
THETA = {
    'obs_dist':    0.85,
    'ego_speed':   0.80,
    'pedestrian':  0.88,
    'traffic_light': 0.92,
    'oncoming':    0.88,
}
# adverse-weather profile raises thresholds (less trust in degraded conditions)
THETA_ADVERSE = {
    'obs_dist':    0.88, 'ego_speed': 0.80, 'pedestrian': 0.91,
    'traffic_light': 0.94, 'oncoming': 0.91,
}

HOLD_LIMIT = 10        # ticks of untrusted input before EV_SENSOR_FAULT

# event name maps
RISK_EVENT = {'LOW':'EV_RISK_LOW', 'MED':'EV_RISK_MED',
              'HIGH':'EV_RISK_HIGH', 'CRITICAL':'EV_RISK_CRITICAL'}
TIER_CODE = {'LOW':0, 'MED':1, 'HIGH':2, 'CRITICAL':3}
ARTICLE_CODE = {'Art.38':38, 'Art.42':42, 'Art.43':43,
                'Art.44':44, 'Art.47':47, 'Art.82':82, 'Art.90':90, '-':0}


class RLCBridge:
    """Risk-Legality-Confidence Bridge. Stateful across ticks."""

    def __init__(self, weather='clear', ablation='full'):
        self.quantizer = risk_mod.RiskQuantizer()
        self.weather = weather
        self.theta = THETA_ADVERSE if weather in ('rain','fog','adverse') else THETA
        # ablation config: 'full', 'no_gate', 'no_adapt', 'risk_only', 'legality_only'
        self.ablation = ablation
        if ablation == 'no_gate':
            # disable confidence gating: trust everything (set thresholds to 0)
            self.theta = {k: 0.0 for k in self.theta}

        # state for fail-safe and change-detection
        self._last_trusted_tier = 'LOW'
        self._hold_count = 0
        self._prev_mask = None
        self._prev_tier = None
        self._tick = 0

    def _gate(self, field, conf):
        """Return True if input is trusted (conf >= threshold)."""
        return conf >= self.theta.get(field, 0.85)

    def process(self, perception, assessment_inputs):
        """
        perception: dict with confidences, e.g.
            {'obs_dist': (value, conf), 'ego_speed': (value, conf),
             'pedestrian': (bool, conf), 'traffic_light': (state, conf),
             'oncoming': (bool, conf)}
        assessment_inputs: extra legality inputs (speed_limit, rss, lane markings)

        Returns {events, ram, audit}.
        """
        self._tick += 1
        events = []
        audit = {'tick': self._tick, 'gates': {}, 'fail_safe': []}

        # ---------- STAGE 1: confidence gate ----------
        trusted = {}
        any_untrusted = False
        for field, (value, conf) in perception.items():
            ok = self._gate(field, conf)
            trusted[field] = ok
            audit['gates'][field] = {'conf': round(conf,3),
                                     'threshold': self.theta.get(field,0.85),
                                     'trusted': ok, 'value': value}
            if not ok:
                any_untrusted = True

        # extract trusted values (with fail-safe defaults for untrusted)
        obs_dist  = perception['obs_dist'][0]  if trusted.get('obs_dist')  else -2  # -2 = untrusted
        ego_speed = perception['ego_speed'][0] if trusted.get('ego_speed') else None
        # fail-safe: untrusted pedestrian -> assume present
        pedestrian = perception['pedestrian'][0] if trusted.get('pedestrian') else True
        # fail-safe: untrusted light -> treat signal-dependent actions as illegal (red)
        tl = perception['traffic_light'][0] if trusted.get('traffic_light') else 0
        # fail-safe: untrusted oncoming -> assume present
        oncoming = perception['oncoming'][0] if trusted.get('oncoming') else True

        if not trusted.get('pedestrian'):
            audit['fail_safe'].append('pedestrian_assumed_present')
        if not trusted.get('traffic_light'):
            audit['fail_safe'].append('signal_assumed_red')
        if not trusted.get('oncoming'):
            audit['fail_safe'].append('oncoming_assumed_present')

        # hold-count for sensor fault
        if any_untrusted:
            self._hold_count += 1
        else:
            self._hold_count = 0
        if self._hold_count >= HOLD_LIMIT:
            events.append('EV_SENSOR_FAULT')
            audit['fail_safe'].append('SENSOR_FAULT_persistent_untrusted')

        # ---------- STAGE 2: risk quantization ----------
        if ego_speed is None or obs_dist == -2:
            # risk input untrusted: FREEZE last trusted tier
            tier = self._last_trusted_tier
            R = None
            audit['fail_safe'].append('risk_frozen_last_tier')
            audit['risk'] = {'frozen': True, 'tier': tier}
        else:
            R, comp = risk_mod.compute_risk(obs_dist, ego_speed, mu=self._mu())
            tier = self.quantizer.update(R)
            self._last_trusted_tier = tier
            audit['risk'] = {'R': R, 'tier': tier, 'components': comp}

        # emit risk event on tier change (CRITICAL always emits)
        if tier != self._prev_tier or tier == 'CRITICAL':
            events.append(RISK_EVENT[tier])
        self._prev_tier = tier

        # ---------- STAGE 3: legality encoding ----------
        rss = assessment_inputs.get('rss_distance', -1)
        rss_min = assessment_inputs.get('rss_min', 10)
        verdicts = legal_mod.assess_legality(
            traffic_light=tl, ego_speed=(ego_speed or 0),
            speed_limit=assessment_inputs.get('speed_limit', 50),
            rss_distance=rss, rss_min=rss_min,
            lane_marking_left=assessment_inputs.get('lane_left','dashed'),
            lane_marking_right=assessment_inputs.get('lane_right','dashed'),
            pedestrian_crossing=pedestrian, oncoming=oncoming)

        mask, order = legal_mod.legal_action_mask(verdicts)
        art, reason = legal_mod.most_severe_violation(verdicts)

        # events on mask change
        if self._prev_mask is not None and mask != self._prev_mask:
            events.append('EV_LEGAL_UPDATE')
            # specifically detect PROCEED bit clearing (red light / ped)
            if (self._prev_mask & 1) and not (mask & 1):
                events.append('EV_ILLEGAL_PROCEED')
            # detect a previously-illegal action becoming legal
            if (~self._prev_mask & mask) & 0b111111:
                events.append('EV_LEGAL_CLEAR')
        self._prev_mask = mask

        # RSS warning event
        if 0 <= rss < rss_min:
            events.append('EV_RSS_WARNING')

        audit['legality'] = {
            'verdicts': {a: v[0] for a,v in verdicts.items()},
            'mask': format(mask,'06b'),
            'violation_article': art,
        }

        # ---------- ABLATION OVERRIDES ----------
        risk_tier_out = TIER_CODE[tier]
        legal_mask_out = mask
        article_out = ARTICLE_CODE.get(art, 0) if art else 0

        if self.ablation == 'legality_only':
            # disable the risk layer: force risk to LOW, drop risk-driven events
            risk_tier_out = 0
            events = [e for e in events if not e.startswith('EV_RISK')]
            # re-add a LOW so STM has a risk signal
            events.append('EV_RISK_LOW')
        elif self.ablation == 'risk_only':
            # disable the legality layer: everything legal, no article, no legal events
            legal_mask_out = 0b111111
            article_out = 0
            events = [e for e in events if e not in
                      ('EV_ILLEGAL_PROCEED','EV_LEGAL_UPDATE','EV_LEGAL_CLEAR','EV_RSS_WARNING')]

        # ---------- STAGE 4: assemble RAM + output ----------
        ram = {
            'RiskTier': risk_tier_out,
            'RiskScore': int(R*100) if R is not None else -1,
            'LegalMask': legal_mask_out,
            'ViolationArticle': article_out,
            'RSSMargin': round(rss - rss_min, 1) if rss >= 0 else 999,
            'WeatherProfile': 1 if self.weather in ('rain','fog','adverse') else 0,
        }

        return {'events': events, 'ram': ram, 'audit': audit}

    def _mu(self):
        """Friction coefficient: lower in adverse weather."""
        return 0.4 if self.weather in ('rain','fog','adverse') else 0.7

    def reset(self):
        self.quantizer.reset()
        self._last_trusted_tier = 'LOW'
        self._hold_count = 0
        self._prev_mask = None
        self._prev_tier = None
        self._tick = 0


# ---- self-test ----
if __name__ == '__main__':
    print("="*64)
    print("RLC Bridge — self test")
    print("="*64)

    bridge = RLCBridge(weather='clear')

    scenarios = [
        ("Clear, green, no obstacle, all trusted",
         {'obs_dist': (-1, 0.95), 'ego_speed': (40, 0.95),
          'pedestrian': (False, 0.95), 'traffic_light': (1, 0.95), 'oncoming': (False, 0.95)},
         {'speed_limit': 50}),
        ("Vehicle approaching, mid risk, green",
         {'obs_dist': (35, 0.92), 'ego_speed': (45, 0.93),
          'pedestrian': (False, 0.93), 'traffic_light': (1, 0.95), 'oncoming': (False, 0.92)},
         {'speed_limit': 50}),
        ("Near + fast = critical risk",
         {'obs_dist': (12, 0.90), 'ego_speed': (70, 0.92),
          'pedestrian': (False, 0.93), 'traffic_light': (1, 0.95), 'oncoming': (False, 0.92)},
         {'speed_limit': 60}),
        ("Red light (legal block)",
         {'obs_dist': (40, 0.92), 'ego_speed': (30, 0.93),
          'pedestrian': (False, 0.93), 'traffic_light': (0, 0.95), 'oncoming': (False, 0.92)},
         {'speed_limit': 50}),
        ("Pedestrian detected, LOW confidence (fail-safe)",
         {'obs_dist': (40, 0.92), 'ego_speed': (30, 0.93),
          'pedestrian': (False, 0.40), 'traffic_light': (1, 0.95), 'oncoming': (False, 0.92)},
         {'speed_limit': 50}),
        ("Traffic light UNTRUSTED (fail-safe -> red)",
         {'obs_dist': (40, 0.92), 'ego_speed': (30, 0.93),
          'pedestrian': (False, 0.93), 'traffic_light': (1, 0.50), 'oncoming': (False, 0.92)},
         {'speed_limit': 50}),
    ]

    for name, perc, inp in scenarios:
        out = bridge.process(perc, inp)
        print(f"\n--- {name} ---")
        print(f"  Events: {out['events']}")
        print(f"  RAM: RiskTier={out['ram']['RiskTier']} RiskScore={out['ram']['RiskScore']} "
              f"LegalMask={out['ram']['LegalMask']:06b} ViolationArt={out['ram']['ViolationArticle']}")
        if out['audit']['fail_safe']:
            print(f"  Fail-safe: {out['audit']['fail_safe']}")
