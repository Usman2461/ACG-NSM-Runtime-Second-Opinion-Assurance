"""
15_adaptation.py
================
Phase 7: Bounded Online Adaptation. NOVELTY CLAIM 2.

Adapts bridge parameters online to improve performance, but EVERY parameter
has hard bounds it can never cross, and the CRITICAL risk boundary NEVER adapts.
This gives the provable property:

  "The adapted system, at its most permissive, is never less safe than the
   static system at its most conservative configuration."

Two adaptation drivers:
  1. CONTEXT PROFILES: weather/road type set baseline shifts (preset, bounded)
  2. ONLINE FEEDBACK: false-alarm rate and outcome feedback tune within bounds

Adapts:
  - confidence thresholds theta  (base ± 0.05)
  - risk LOW/MED boundary        [0.25, 0.40]
  - risk MED/HIGH boundary       [0.60, 0.72]
  - risk CRITICAL boundary       FIXED 0.90 (never adapts) <-- safety floor

Every change is logged with (param, old, new, trigger, bound_check).
"""
import json
from copy import deepcopy


# ---- HARD BOUNDS (the safety guarantee) ----
BOUNDS = {
    'theta_obs_dist':    (0.80, 0.90),
    'theta_ego_speed':   (0.75, 0.85),
    'theta_pedestrian':  (0.83, 0.93),
    'theta_traffic_light': (0.87, 0.97),
    'theta_oncoming':    (0.83, 0.93),
    'r_low_med':         (0.25, 0.40),
    'r_med_high':        (0.60, 0.72),
    # r_critical intentionally absent -> cannot be adapted
}

R_CRITICAL_FIXED = 0.90       # NEVER changes

# ---- base values ----
BASE = {
    'theta_obs_dist': 0.85, 'theta_ego_speed': 0.80, 'theta_pedestrian': 0.88,
    'theta_traffic_light': 0.92, 'theta_oncoming': 0.88,
    'r_low_med': 0.30, 'r_med_high': 0.70,
}

# ---- context profiles (preset baseline shifts, already within bounds) ----
CONTEXT_PROFILES = {
    'clear':   {},  # use base
    'rain':    {'theta_obs_dist': +0.03, 'theta_pedestrian': +0.03,
                'theta_traffic_light': +0.02, 'theta_oncoming': +0.03,
                'r_low_med': -0.03, 'r_med_high': -0.05},
    'fog':     {'theta_obs_dist': +0.05, 'theta_pedestrian': +0.05,
                'theta_traffic_light': +0.04, 'theta_oncoming': +0.05,
                'r_low_med': -0.05, 'r_med_high': -0.08},
    'highway': {'r_med_high': +0.02},   # higher speeds, slightly more tolerant mid
    'urban':   {'r_low_med': -0.02},    # tighter in dense urban
}

MAX_STEP = 0.01           # max change per online update (gradual)


class BoundedAdaptation:
    """Manages adaptive bridge parameters with hard-bound enforcement + audit."""

    def __init__(self, weather='clear', road='urban'):
        self.params = dict(BASE)
        self.params['r_critical'] = R_CRITICAL_FIXED
        self.weather = weather
        self.road = road
        self.audit_log = []
        self._tick = 0

        # online feedback accumulators
        self._false_alarms = 0
        self._true_alarms = 0
        self._updates_applied = 0

        # apply context profile at init
        self._apply_context()

    # parameters that may NEVER be adapted (no entry in BOUNDS = immutable)
    IMMUTABLE = {'r_critical'}

    def _clamp(self, key, value):
        """Enforce hard bound. Returns (clamped_value, was_clamped).
        A key with no BOUNDS entry is IMMUTABLE: the change is rejected
        and the current value is returned unchanged. This is the safety
        floor mechanism - CRITICAL and any unlisted param cannot move."""
        if key not in BOUNDS:
            # immutable: reject change, keep current value
            return self.params.get(key, value), True
        lo, hi = BOUNDS[key]
        clamped = max(lo, min(hi, value))
        return clamped, (clamped != value)

    def _log(self, param, old, new, trigger):
        lo, hi = BOUNDS.get(param, (None, None))
        # immutable params are "within bounds" iff unchanged from fixed value
        if param not in BOUNDS:
            within = (param == 'r_critical' and new == R_CRITICAL_FIXED)
        else:
            within = (lo <= new <= hi)
        self.audit_log.append({
            'tick': self._tick, 'param': param,
            'old': round(old, 4), 'new': round(new, 4),
            'trigger': trigger,
            'bound_lo': lo, 'bound_hi': hi,
            'within_bounds': within,
        })

    def _apply_context(self):
        """Apply weather + road context profile shifts (bounded)."""
        for profile_key in (self.weather, self.road):
            shifts = CONTEXT_PROFILES.get(profile_key, {})
            for param, delta in shifts.items():
                old = self.params[param]
                proposed = BASE[param] + delta
                new, clamped = self._clamp(param, proposed)
                if new != old:
                    self.params[param] = new
                    self._log(param, old, new,
                              f'context:{profile_key}' + ('(clamped)' if clamped else ''))

    def set_context(self, weather=None, road=None):
        """Change context -> re-apply profiles."""
        self._tick += 1
        if weather: self.weather = weather
        if road: self.road = road
        # reset to base then re-apply (context is not cumulative)
        for k in BASE:
            self.params[k] = BASE[k]
        self._apply_context()

    def record_outcome(self, was_alarm, was_correct):
        """
        Feed an outcome: did the system raise an alarm (fail-safe/high-risk),
        and was it correct? Drives online false-alarm tuning.
        """
        if was_alarm:
            if was_correct:
                self._true_alarms += 1
            else:
                self._false_alarms += 1

    def online_update(self):
        """
        Apply gradual online adjustment based on accumulated false-alarm rate.
        Only adjusts within hard bounds, max MAX_STEP per call. Called between
        maneuvers (not mid-decision).
        """
        self._tick += 1
        total = self._false_alarms + self._true_alarms
        if total < 10:
            return  # need enough samples

        far = self._false_alarms / total   # false alarm rate

        # high false-alarm rate -> thresholds too sensitive -> relax slightly
        # (raise theta = trust detector more = fewer fail-safe alarms;
        #  raise r_low_med = fewer MED escalations)
        if far > 0.30:
            self._nudge('r_low_med', +MAX_STEP, f'high_false_alarm_rate({far:.2f})')
            self._nudge('theta_pedestrian', -MAX_STEP, f'high_false_alarm_rate({far:.2f})')
        elif far < 0.10:
            # very few false alarms -> can afford to be slightly more cautious
            self._nudge('r_low_med', -MAX_STEP, f'low_false_alarm_rate({far:.2f})')

        # decay accumulators (sliding behaviour)
        self._false_alarms = int(self._false_alarms * 0.5)
        self._true_alarms = int(self._true_alarms * 0.5)
        self._updates_applied += 1

    def _nudge(self, param, delta, trigger):
        # hard refusal for immutable params (e.g. r_critical)
        if param not in BOUNDS:
            self._log(param, self.params.get(param, 0), self.params.get(param, 0),
                      trigger + '(REJECTED:immutable)')
            return
        old = self.params[param]
        new, clamped = self._clamp(param, old + delta)
        if new != old:
            self.params[param] = new
            self._log(param, old, new, trigger + ('(clamped)' if clamped else ''))

    def get_theta(self):
        return {
            'obs_dist': self.params['theta_obs_dist'],
            'ego_speed': self.params['theta_ego_speed'],
            'pedestrian': self.params['theta_pedestrian'],
            'traffic_light': self.params['theta_traffic_light'],
            'oncoming': self.params['theta_oncoming'],
        }

    def get_risk_boundaries(self):
        return {
            'low_med': self.params['r_low_med'],
            'med_high': self.params['r_med_high'],
            'critical': self.params['r_critical'],   # always 0.90
        }

    def verify_safety_invariant(self):
        """
        Check the provable property: every param within bounds, critical fixed.
        Returns (ok, violations).
        """
        violations = []
        for key, (lo, hi) in BOUNDS.items():
            v = self.params[key]
            if not (lo <= v <= hi):
                violations.append(f'{key}={v} outside [{lo},{hi}]')
        if self.params['r_critical'] != R_CRITICAL_FIXED:
            violations.append(f'CRITICAL boundary changed to {self.params["r_critical"]}!')
        return len(violations) == 0, violations

    def save_audit(self, path):
        json.dump({
            'final_params': self.params,
            'bounds': BOUNDS,
            'critical_fixed': R_CRITICAL_FIXED,
            'updates_applied': self._updates_applied,
            'adaptation_log': self.audit_log,
        }, open(path, 'w'), indent=2)


# ---- self-test ----
if __name__ == '__main__':
    print("="*64)
    print("Bounded Adaptation — self test")
    print("="*64)

    ad = BoundedAdaptation(weather='clear', road='urban')
    print(f"\nInitial theta: {ad.get_theta()}")
    print(f"Initial risk boundaries: {ad.get_risk_boundaries()}")

    # 1. context change to fog
    print("\n--- Context: switch to FOG ---")
    ad.set_context(weather='fog')
    print(f"theta after fog: {ad.get_theta()}")
    print(f"risk boundaries: {ad.get_risk_boundaries()}")

    # 2. simulate high false-alarm rate -> online adaptation
    print("\n--- Online: feed 20 outcomes, 8 false alarms (40% FAR) ---")
    ad.set_context(weather='clear')  # back to clear
    for i in range(20):
        ad.record_outcome(was_alarm=True, was_correct=(i % 5 >= 2))  # ~40% false
    before = ad.get_risk_boundaries()['low_med']
    ad.online_update()
    after = ad.get_risk_boundaries()['low_med']
    print(f"r_low_med: {before:.3f} -> {after:.3f}")

    # 3. try to push CRITICAL (should be impossible)
    print("\n--- Attempt to adapt CRITICAL boundary ---")
    ad._nudge('r_critical', +0.05, 'malicious_test')   # not in BOUNDS -> no-op
    print(f"r_critical after attempt: {ad.get_risk_boundaries()['critical']} (should be 0.90)")

    # 4. run many updates and verify bounds never violated
    print("\n--- Stress: 100 online updates with random outcomes ---")
    import random
    for _ in range(100):
        for _ in range(15):
            ad.record_outcome(was_alarm=random.random()<0.5,
                              was_correct=random.random()<0.6)
        ad.online_update()
    ok, violations = ad.verify_safety_invariant()
    print(f"Safety invariant holds: {ok}")
    if violations:
        print(f"VIOLATIONS: {violations}")
    print(f"Total adaptation steps logged: {len(ad.audit_log)}")
    print(f"Final boundaries: {ad.get_risk_boundaries()}")

    ad.save_audit('/mnt/d/NSTM_Project/results/adaptation_audit.json')
    print("\nSaved adaptation audit log.")
    print("\nKey property demonstrated: CRITICAL fixed at 0.90, all params in bounds.")
