"""
50_graded_bridge.py
===================
Confidence-proportional fail-safe substitution for the ACG-NSM conservative
channel.

Why this exists
---------------
The deployed bridge substitutes a hazard-dominating value the instant a field's
confidence drops below its threshold. For a boolean hazard this asserts the
hazard as fact, which renders the intended maneuver ILLEGAL, which removes the
permission outright. Measured on the harness, the conservative channel therefore
refuses the maneuver on 99.8% of ticks under degradation: the second opinion
does not say "proceed more slowly", it says "do not proceed". A nominal planner
supervised by such a channel is overridden essentially always, so nothing of its
behaviour is preserved and no meaningful arbitration can be observed.

The graded fail-safe
--------------------
Distrust becomes a DEPTH rather than a switch:

    delta_i = clamp((theta_i - c_i) / theta_i, 0, 1)

and the system holds a BELIEF that the hazard is present rather than a
substituted fact:

    b_i = 1.0          if the hazard was actually observed
        = delta_i      if it was not observed but the reading is distrusted

The belief is then routed by depth, against a commitment threshold tau:

    b_i >= tau   the evidence is strong enough to ASSERT the hazard. The
                 governing article fires and the permission is removed, exactly
                 as before. Hard legal constraints remain binary.
    b_i <  tau   the hazard is not asserted, but the belief inflates the
                 physical risk continuously, lowering the speed target.

Shallow distrust therefore produces a small speed reduction, deep distrust a
full override, and the region between is continuous -- which is what partial
correction requires.

Monotonicity (the property that keeps this sound)
-------------------------------------------------
b_i is non-decreasing in distrust; risk is non-decreasing in b_i; the speed
target is non-increasing in risk. Uncertainty can therefore only ever slow the
vehicle, never speed it up. Setting tau = 0 recovers the original binary
fail-safe exactly, so the deployed behaviour is a special case of this one.

Caveat worth stating in any writeup: tau trades interception against
blendability, and the trade is real. Section "tau sweep" in the accompanying
experiment measures it rather than assuming a good value exists.
"""
import importlib.util
from pathlib import Path

SRC = Path(__file__).resolve().parent


def _load(name, path):
    spec = importlib.util.spec_from_file_location(name, str(path))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


risk_m = _load('risk', SRC / '11_risk_assessor.py')
leg_m = _load('leg', SRC / '12_legality_assessor.py')

# per-field gate thresholds (deployed values)
THETA = {'obs_dist': 0.85, 'pedestrian': 0.88, 'traffic_light': 0.92,
         'oncoming': 0.88, 'ego_speed': 0.50}

R_LM, R_MH, R_CRIT = 0.30, 0.70, 0.90
ORDER = ['PROCEED', 'TURN_LEFT', 'TURN_RIGHT',
         'LANE_CHANGE_L', 'LANE_CHANGE_R', 'STOP']

# ---------------------------------------------------------------- adaptation
# Gate thresholds are nudged online from the observed false-activation rate,
# inside a dead band so that ordinary fluctuation does not cause drift, and
# clamped to per-field bounds so adaptation cannot disable a gate. Risk-tier
# boundaries are deliberately NOT adaptive: they are the safety envelope, and
# a system that can widen its own definition of acceptable risk has no
# envelope at all.
ALPHA_LO, ALPHA_HI = 0.10, 0.30      # dead band on false-activation rate
ETA = 0.01                           # step size per update
ADAPT_EVERY = 50                     # ticks between updates
THETA_BOUNDS = {                     # (min, max) per field, immutable
    'obs_dist':      (0.70, 0.95),
    'pedestrian':    (0.75, 0.95),
    'traffic_light': (0.80, 0.97),
    'oncoming':      (0.75, 0.95),
    'ego_speed':     (0.40, 0.70),
}


def distrust_depth(theta, conf):
    """delta in [0,1]: how far below its threshold a confidence has fallen."""
    if theta <= 0:
        return 0.0
    return max(0.0, min(1.0, (theta - conf) / theta))


def tier_of(R):
    return 3 if R >= R_CRIT else 2 if R >= R_MH else 1 if R >= R_LM else 0


class GradedBridge:
    """Conservative channel with confidence-proportional fail-safe.

    tau = 0.0  -> identical to the deployed binary bridge
    tau = 1.0  -> hazards are never asserted; distrust only raises risk
    """

    def __init__(self, tau=0.20, w_haz=0.55, speed_limit=50.0,
                 rss_min=15.0, hold_limit=10, theta=None,
                 adapt=True):
        self.tau = tau
        self.w_haz = w_haz
        self.speed_limit = speed_limit
        self.rss_min = rss_min
        self.hold_limit = hold_limit
        self.theta = dict(theta or THETA)
        self._hold = {}
        self._last_trusted_tier = 0
        self._tick = 0
        self.adapt = bool(adapt)
        self._theta0 = dict(self.theta)      # deployed values, for reporting
        self._act = {f: 0 for f in self.theta}    # gate activations
        self._false_act = {f: 0 for f in self.theta}
        self._adapt_log = []

    # ------------------------------------------------------------------
    def process(self, perception, context=None):
        """perception: {field: (value, confidence)}.  Returns a witness dict."""
        self._tick += 1
        ctx = context or {}
        limit = ctx.get('speed_limit', self.speed_limit)

        beliefs, depths, gates = {}, {}, {}
        for field, (value, conf) in perception.items():
            th = self.theta.get(field, 0.0)
            d = distrust_depth(th, conf)
            depths[field] = d
            gates[field] = {'conf': conf, 'theta': th, 'trusted': conf >= th}
            # hold counter for sustained distrust
            self._hold[field] = 0 if conf >= th else self._hold.get(field, 0) + 1

        # ---- hazard beliefs: observed -> 1.0, else proportional to distrust
        def belief(field):
            val, conf = perception[field]
            if bool(val):
                return 1.0
            return depths[field]

        b_ped = belief('pedestrian') if 'pedestrian' in perception else 0.0
        b_onc = belief('oncoming') if 'oncoming' in perception else 0.0

        # signal: red observed -> 1.0, else proportional to distrust
        sig_val = perception.get('traffic_light', (-1, 1.0))[0]
        b_sig = 1.0 if sig_val == 0 else depths.get('traffic_light', 0.0)

        beliefs = {'pedestrian': b_ped, 'oncoming': b_onc, 'traffic_light': b_sig}

        # ---- committed hazards (asserted as fact -> legality may fire) ----
        ped_fact = b_ped >= self.tau
        onc_fact = b_onc >= self.tau
        sig_fact = 0 if b_sig >= self.tau else sig_val

        gap = perception['obs_dist'][0] if 'obs_dist' in perception else 100.0
        ego = perception['ego_speed'][0] if 'ego_speed' in perception else 0.0
        # distrusted distance is treated pessimistically: shrink toward zero
        d_obs = depths.get('obs_dist', 0.0)
        gap_eff = gap * (1.0 - 0.5 * d_obs) if gap > 0 else gap

        verdicts = leg_m.assess_legality(
            traffic_light=sig_fact, ego_speed=ego, speed_limit=limit,
            rss_distance=gap_eff, rss_min=self.rss_min,
            pedestrian_crossing=ped_fact, oncoming=onc_fact)
        mask, order = leg_m.legal_action_mask(verdicts)
        perms = {a for i, a in enumerate(order) if mask & (1 << i)}

        # ---- uncommitted belief inflates physical risk continuously ----
        R, comps = risk_m.compute_risk(gap_eff, ego)
        residual = max([b for b in beliefs.values() if b < self.tau] + [0.0])
        R_graded = min(1.0, R + self.w_haz * residual)
        tier = tier_of(R_graded)

        # risk freeze: distrust must never lower the tier
        if any(self._hold.get(f, 0) > 0 for f in ('obs_dist', 'ego_speed')):
            tier = max(tier, self._last_trusted_tier)
        else:
            self._last_trusted_tier = tier

        sensor_fault = any(v >= self.hold_limit for v in self._hold.values())

        # ---- bounded adaptation -------------------------------------------
        # A gate activation is counted FALSE when the field was distrusted yet
        # the committed hazard did not materialise -- the belief stayed below
        # tau and the risk tier was already benign. Persistently high false
        # activation means the threshold is too eager and is lowered; a rate
        # below the dead band means the gate is barely firing and it is raised.
        for f, d in depths.items():
            if d > 0.0:
                self._act[f] = self._act.get(f, 0) + 1
                b = beliefs.get(f)
                if (b is None or b < self.tau) and tier <= 1:
                    self._false_act[f] = self._false_act.get(f, 0) + 1
        if self.adapt and self._tick % ADAPT_EVERY == 0:
            self._adapt_step()

        return {
            'tick': self._tick,
            'permissions': perms,
            'legal_mask': mask,
            'risk_raw': R,
            'risk_graded': R_graded,
            'risk_tier': tier,
            'beliefs': beliefs,
            'depths': depths,
            'residual_belief': residual,
            'gap_effective': gap_eff,
            'asserted': {'pedestrian': ped_fact, 'oncoming': onc_fact,
                         'signal_red': sig_fact == 0},
            'sensor_fault': sensor_fault,
            'gates': gates,
            'theta': {k: round(v, 4) for k, v in self.theta.items()},
            'article': next((v[1] for v in verdicts.values()
                             if v[0] == 'ILLEGAL'), 0),
        }

    # ------------------------------------------------------------------
    def _adapt_step(self):
        """One bounded update of the gate thresholds.

        Movement is proportional to how far the false-activation rate lies
        outside the dead band, so a rate inside [ALPHA_LO, ALPHA_HI] produces
        no change at all. Each threshold is clamped to its own bounds, so a
        field can be tuned but never switched off, and saturation is recorded
        rather than silently absorbed -- a threshold sitting at its bound is
        evidence that adaptation wanted to go further than it was permitted,
        which is worth reporting rather than hiding.
        """
        rec = {'tick': self._tick, 'moved': {}, 'saturated': []}
        for f, th in list(self.theta.items()):
            n = self._act.get(f, 0)
            if n < 20:                       # too little evidence to act on
                continue
            rate = self._false_act.get(f, 0) / float(n)
            lo, hi = THETA_BOUNDS.get(f, (0.50, 0.99))
            if rate > ALPHA_HI:
                new = th - ETA * (rate - ALPHA_HI) / max(1e-6, 1.0 - ALPHA_HI)
            elif rate < ALPHA_LO:
                new = th + ETA * (ALPHA_LO - rate) / max(1e-6, ALPHA_LO)
            else:
                continue                     # inside the dead band
            new = max(lo, min(hi, new))
            if abs(new - th) > 1e-9:
                self.theta[f] = new
                rec['moved'][f] = [round(th, 4), round(new, 4),
                                   round(rate, 3)]
            if new in (lo, hi):
                rec['saturated'].append(f)
        # decay the counters so the rate reflects recent behaviour
        for f in self._act:
            self._act[f] = int(self._act[f] * 0.5)
            self._false_act[f] = int(self._false_act.get(f, 0) * 0.5)
        if rec['moved'] or rec['saturated']:
            self._adapt_log.append(rec)

    def adaptation_report(self):
        """Deployed thresholds, current thresholds, and what saturated."""
        sat = [f for f, th in self.theta.items()
               if th in THETA_BOUNDS.get(f, (None, None))]
        return {
            'adaptive': self.adapt,
            'theta_deployed': {k: round(v, 4) for k, v in self._theta0.items()},
            'theta_current': {k: round(v, 4) for k, v in self.theta.items()},
            'drift': {k: round(self.theta[k] - self._theta0[k], 4)
                      for k in self.theta},
            'saturated_fields': sat,
            'updates': len(self._adapt_log),
            'dead_band': [ALPHA_LO, ALPHA_HI],
            'risk_boundaries_immutable': [R_LM, R_MH, R_CRIT],
        }

    # ------------------------------------------------------------------
    def target_speed(self, out, maneuver, cruise=None):
        """Conservative target speed (km/h) for an intended maneuver.

        The tier still sets the coarse regime (it is what the state machine
        consumes), but within a regime the CONTINUOUS risk further attenuates
        the speed, so that an inflated-but-uncommitted belief produces a real
        reduction rather than none. Without this the graded fail-safe would
        raise risk and change nothing, because tier boundaries are coarse.
        """
        cruise = cruise if cruise is not None else self.speed_limit
        if maneuver not in out['permissions']:
            return 0.0
        t, gap = out['risk_tier'], out['gap_effective']
        if t >= 3:
            base = 0.0
        elif t == 2:
            base = min(cruise, max(0.0, (gap / 1.5) * 3.6)) if gap > 0 else 8.0
        elif t == 1:
            base = min(cruise, max(0.0, (gap / 1.2) * 3.6)) if gap > 0 else 18.0
        else:
            base = cruise
        # continuous attenuation by the graded risk in [0,1]
        atten = max(0.0, 1.0 - out['risk_graded'])
        return base * atten


if __name__ == '__main__':
    # demonstration: the same distrusted pedestrian at three commitment settings
    print("A distrusted pedestrian reading (conf 0.62 vs theta 0.88):")
    print("  distrust depth =", round(distrust_depth(0.88, 0.62), 3))
    perc = {'obs_dist': (40.0, 0.95), 'ego_speed': (50.0, 0.95),
            'pedestrian': (False, 0.62), 'traffic_light': (1, 0.95),
            'oncoming': (False, 0.92)}
    print(f"\n{'tau':>6}{'asserted':>10}{'PROCEED?':>10}{'tier':>6}"
          f"{'risk':>8}{'speed':>8}")
    print('-' * 48)
    for tau in (0.0, 0.20, 0.30, 0.50, 1.0):
        b = GradedBridge(tau=tau)
        o = b.process(perc)
        print(f"{tau:>6.2f}{str(o['asserted']['pedestrian']):>10}"
              f"{str('PROCEED' in o['permissions']):>10}{o['risk_tier']:>6}"
              f"{o['risk_graded']:>8.3f}{b.target_speed(o,'PROCEED'):>8.1f}")
    print("\ntau=0.00 reproduces the deployed binary fail-safe exactly.")
