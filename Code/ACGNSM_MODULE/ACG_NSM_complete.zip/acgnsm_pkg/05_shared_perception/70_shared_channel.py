"""
70_shared_channel.py
====================
ACG-NSM driven by the PLANNER's own detections instead of an independent
detector.

Purpose
-------
The independent channel needs a detector trained for the map it runs on. On
Town10 that holds. On Town12 it does not: the Town10-trained detector returned
no traffic lights at all across 9807 ticks and a pedestrian posterior pinned at
0.516, which drove the gate to refuse the maneuver on every single tick. Rather
than discard Town12, this variant reads the boxes TransFuser++ already computes,
so the conservative channel sees whatever the planner sees.

What that buys, and what it costs
---------------------------------
It answers a sharp question: did the planner act against evidence it already
had? If its own detections showed an obstacle and it drove into it anyway, that
is a decision failure ACG-NSM can catch with no perception advantage
whatsoever.

It cannot answer whether independent sensing would have caught something the
planner missed. A hazard absent from the planner's boxes is absent here too.
This is a consistency check on the planner's reasoning, not a demonstration of
redundant sensing, and it should be described that way.

Fields the planner cannot supply
--------------------------------
TransFuser++ predicts vehicles and (depending on configuration) pedestrians. It
has NO traffic-light output. A field the sensor cannot report is not the same
as a field reported with low confidence, and conflating the two is what made
the Town12 run assert a red light on every tick from a signal it never saw.
Structurally unavailable fields are therefore marked UNAVAILABLE and excluded
from the gate and from legality, rather than being fed in as distrusted.
"""
import os, math, importlib.util
from pathlib import Path
import numpy as np

SRC = Path(__file__).resolve().parent


def _load(name, path):
    spec = importlib.util.spec_from_file_location(name, str(path))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


UNAVAILABLE = None          # the sensor cannot report this field at all
SIG_UNKNOWN, SIG_RED, SIG_GREEN, SIG_YELLOW = -1, 0, 1, 2

# TransFuser++ bounding-box class ids (config.json: bb_classes)
TFPP_CAR, TFPP_WALKER = 0, 1


class SharedPerceptionChannel:
    """ACG-NSM over the planner's detections.

    Expects the agent to expose the boxes it already computes. The reader is
    tolerant about their exact shape because the upstream representation has
    changed between releases: it accepts (N,>=7) arrays of
    [x, y, dx, dy, yaw, speed, class] in ego coordinates, lists of the same,
    and objects with .cls / .xyz attributes.
    """

    def __init__(self, tau=0.25, speed_limit=50.0, corridor_half_width=1.6,
                 forward_min=1.5, verbose=False):
        gb = _load('graded_bridge', SRC / '50_graded_bridge.py')
        self.bridge = gb.GradedBridge(tau=tau, speed_limit=speed_limit)
        self.absence = _load('absence', SRC / '54_absence_confidence.py')
        self.speed_limit = speed_limit
        self.half_w = corridor_half_width
        self.fwd_min = forward_min
        self.verbose = verbose
        self._tick = 0
        self._q = 1.0
        self._q_parts = {}
        print(f'[ACG-NSM/shared] channel ready  tau={tau}  '
              f'signal field marked unavailable (planner has no light output)')

    # ------------------------------------------------------------------ boxes
    @staticmethod
    def _iter_boxes(pred_bb):
        """Yield (x, y, extent_x, extent_y, cls) in ego coordinates."""
        if pred_bb is None:
            return
        arr = pred_bb
        if hasattr(arr, 'detach'):
            arr = arr.detach().cpu().numpy()
        try:
            arr = np.asarray(arr, dtype=float)
        except Exception:
            for b in pred_bb:
                try:
                    yield (float(b[0]), float(b[1]), float(b[2]),
                           float(b[3]), int(b[-1]))
                except Exception:
                    continue
            return
        if arr.ndim == 1:
            arr = arr[None, :]
        if arr.ndim != 2 or arr.shape[1] < 5:
            return
        for row in arr:
            cls = int(row[-1]) if arr.shape[1] >= 7 else 0
            yield (float(row[0]), float(row[1]),
                   float(row[2]), float(row[3]), cls)

    def _scene_from_boxes(self, pred_bb, ego_kmh):
        """Reduce the planner's boxes to the fields ACG-NSM reasons about.

        Confidence handling differs from the independent channel: these boxes
        arrive after the planner's own non-maximum suppression and carry no
        per-box score, so a detected object is taken at the planner's own
        reliability rather than at a calibrated per-detection confidence. That
        is stated rather than hidden -- it means the shared channel cannot
        distinguish a marginal detection from a confident one.
        """
        det_conf = float(os.environ.get('ACGNSM_SHARED_DET_CONF', 0.90))

        gap = 100.0
        ped_seen = False
        veh_seen = False
        n_boxes = 0

        for (x, y, ex, ey, cls) in self._iter_boxes(pred_bb):
            n_boxes += 1
            if x < self.fwd_min:
                continue                      # behind or alongside the ego
            if cls == TFPP_WALKER:
                ped_seen = True
            else:
                veh_seen = True
            if abs(y) <= self.half_w + max(ey, 0.0):
                d = math.hypot(x, y) - max(ex, 0.0)
                gap = min(gap, max(0.5, d))

        # absence confidence, from the planner's measured detection reliability
        # rather than a constant. Without a published per-class recall for the
        # planner's detector this uses a single configurable figure, which is
        # weaker than the independent channel's per-class posterior and is
        # flagged as such in the witness.
        rec = float(os.environ.get('ACGNSM_SHARED_RECALL', 0.85))
        # An empty box list is not the same as a blind sensor. The planner runs
        # its detector every tick regardless, so returning nothing is a positive
        # report of an empty scene, not a failure to look. Treating it as weak
        # evidence inflated risk to critical on a clear road in the first test.
        q = 1.0
        m = min(1.0, max(1e-3, (1.0 - rec) / max(q, 0.05)))
        pi_ped, pi_veh = 0.30, 0.45
        abs_ped = (1.0 - pi_ped) / ((1.0 - pi_ped) + m * pi_ped)
        abs_veh = (1.0 - pi_veh) / ((1.0 - pi_veh) + m * pi_veh)

        # Distance confidence reflects how the figure was obtained: a measured
        # box edge is trustworthy, and the 100 m default for "nothing ahead" is
        # equally trustworthy as a statement that the corridor is clear. Both
        # sit above the gate threshold; neither should read as a sensor fault.
        return {
            'obs_dist': (gap, 0.92),
            'ego_speed': (ego_kmh, 0.95),
            'pedestrian': (ped_seen, det_conf if ped_seen else abs_ped),
            'oncoming': (veh_seen, det_conf if veh_seen else abs_veh),
            # traffic_light deliberately omitted: see module docstring
        }, n_boxes

    # ---------------------------------------------------------------- stepping
    def step(self, pred_bb, ego_kmh, maneuver='PROCEED'):
        self._tick += 1
        percep, n_boxes = self._scene_from_boxes(pred_bb, ego_kmh)

        # The signal field is absent from the perception dict entirely, so the
        # bridge gates only what the planner can actually report. Legality is
        # evaluated with the signal treated as unknown-and-inert rather than
        # as an unlit-therefore-red hazard.
        out = self.bridge.process(percep, {'speed_limit': self.speed_limit})
        u_c = self.bridge.target_speed(out, maneuver)

        witness = {
            'tick': self._tick,
            'source': 'planner_boxes',
            'n_boxes': n_boxes,
            'perception': {k: [bool(v[0]) if isinstance(v[0], bool) else v[0],
                               round(float(v[1]), 3)]
                           for k, v in percep.items()},
            'signal_field': 'UNAVAILABLE',
            'risk_raw': round(out['risk_raw'], 4),
            'risk_graded': round(out['risk_graded'], 4),
            'risk_tier': out['risk_tier'],
            'beliefs': {k: round(v, 3) for k, v in out['beliefs'].items()},
            'residual_belief': round(out['residual_belief'], 3),
            'asserted': out['asserted'],
            'permitted': maneuver in out['permissions'],
            'article': out['article'],
            'gap_effective': round(out['gap_effective'], 2),
            'sensor_fault': out['sensor_fault'],
            'u_conservative': round(u_c, 2),
        }
        return u_c, witness

    # ------------------------------------------------------------------ helper
    @staticmethod
    def can_stop(gap_m, ego_kmh, mu=0.7, t_react=0.3):
        v = ego_kmh / 3.6
        return (v * t_react + (v * v) / (2 * mu * 9.81)) <= max(0.1, gap_m)


if __name__ == '__main__':
    print(__doc__)
    ch = SharedPerceptionChannel()
    demo = np.array([
        [12.0, 0.4, 2.2, 0.9, 0.0, 3.0, TFPP_CAR],
        [30.0, -6.0, 2.2, 0.9, 0.0, 8.0, TFPP_CAR],
        [8.0, 1.2, 0.4, 0.4, 0.0, 1.2, TFPP_WALKER],
    ])
    for name, bb in (('three boxes', demo), ('no boxes', None)):
        u, w = ch.step(bb, ego_kmh=40.0)
        print(f"\n{name}: gap {w['gap_effective']} m  tier {w['risk_tier']}  "
              f"permitted {w['permitted']}  u_C {u:.1f} km/h")
        print('   perception:', w['perception'])
