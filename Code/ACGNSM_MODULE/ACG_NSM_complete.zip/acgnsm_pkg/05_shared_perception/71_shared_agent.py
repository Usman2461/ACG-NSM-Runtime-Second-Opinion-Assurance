"""
71_shared_agent.py
==================
ACG-NSM-guided TransFuser++ using the PLANNER's own detections.

Identical to the independent guided agent except for where the conservative
channel gets its scene from. TransFuser++ computes bounding boxes internally
but only converts them when debug output is requested, so this forces that
conversion on and reads the result.

    ACGNSM_ARBITRATE=0   observe only; the planner's control is returned
                         untouched and the drive matches the baseline
    ACGNSM_ARBITRATE=1   guided; the suppressed speed is applied

The signal field is unavailable from the planner, so legality cannot evaluate
signal compliance in this configuration. That is a property of the experiment,
not a defect to hide: the shared-perception variant exists to test whether the
planner acted against evidence it already had, and it had no signal evidence.
"""
import os, json, importlib.util, sys
from pathlib import Path

SRC = Path(__file__).resolve().parent
GARAGE = os.environ.get('GARAGE', '/mnt/d/carla_garage')
for p in (str(Path(GARAGE) / 'team_code'),
          str(Path(GARAGE) / 'leaderboard'),
          str(Path(GARAGE) / 'scenario_runner')):
    if p not in sys.path:
        sys.path.insert(0, p)

import carla                                      # noqa: E402
from sensor_agent import SensorAgent              # noqa: E402

MS_TO_KMH = 3.6


def _load(n, p):
    s = importlib.util.spec_from_file_location(n, str(p))
    m = importlib.util.module_from_spec(s); s.loader.exec_module(m); return m


def get_entry_point():
    return 'SharedGuidedAgent'


class SharedGuidedAgent(SensorAgent):

    def setup(self, path_to_conf_file, route_index=None, traffic_manager=None):
        super().setup(path_to_conf_file, route_index, traffic_manager)

        # force the box conversion the planner normally skips
        try:
            self.config.detect_boxes = True
        except Exception:
            pass
        os.environ.setdefault('DEBUG_CHALLENGE', '0')

        self.arbitrate = int(os.environ.get('ACGNSM_ARBITRATE', 0))
        self.log_path = os.environ.get('ACGNSM_LOG', 'shared_witness.jsonl')
        tau = float(os.environ.get('ACGNSM_TAU', 0.25))

        ch = _load('shared_channel', SRC / '70_shared_channel.py')
        ar = _load('arbiter', SRC / '51_suppression_arbiter.py')
        self.channel = ch.SharedPerceptionChannel(tau=tau)
        self.arbiter = ar.SuppressionArbiter()

        self._log = open(self.log_path, 'w')
        self._n = 0
        self._no_box_ticks = 0
        print(f'[ACG-NSM/shared] agent ready  arbitrate={self.arbitrate}  '
              f'lambda={self.arbiter.lam:.3f}  tau={tau}')

    def run_step(self, input_data, timestamp, sensors=None):
        control = super().run_step(input_data, timestamp, sensors)
        self._n += 1
        rec = {'tick': self._n, 'valid': False}
        try:
            dist = getattr(self, '_last_speed_distribution', None)
            scal = getattr(self, '_last_target_speed_scalar', None)
            if dist is None or scal is None:
                rec['warmup'] = True
                self._log.write(json.dumps(rec) + '\n')
                return control

            u_n = float(scal) * MS_TO_KMH
            brake_prob = float(dist[0])

            pred_bb = getattr(self, '_last_pred_bb', None)
            if pred_bb is None:
                self._no_box_ticks += 1

            ego_kmh = (float(self.state_log[-1][3]) * MS_TO_KMH
                       if len(self.state_log) else 0.0)
            u_c, wit = self.channel.step(pred_bb, ego_kmh, maneuver='PROCEED')
            can_stop = self.channel.can_stop(wit['gap_effective'], ego_kmh)

            u_star, arb = self.arbiter.arbitrate(
                u_n, u_c, permitted=wit['permitted'], can_stop=can_stop)

            rec.update({'valid': True,
                        'nominal': {'target_speed_kmh': round(u_n, 2),
                                    'brake_class_prob': round(brake_prob, 4),
                                    'self_braked': bool(
                                        brake_prob >
                                        self.config.brake_uncertainty_threshold),
                                    'control': {
                                        'steer': round(control.steer, 4),
                                        'throttle': round(control.throttle, 4),
                                        'brake': round(control.brake, 4)}},
                        'conservative': wit,
                        'arbitration': arb,
                        'applied': bool(self.arbitrate)})

            if self.arbitrate and u_star < u_n - 1e-6:
                control = self._control_for_speed(control, ego_kmh, u_star)
                rec['applied_control'] = {
                    'throttle': round(control.throttle, 4),
                    'brake': round(control.brake, 4)}
        except Exception as e:
            rec['error'] = f'{type(e).__name__}: {e}'[:200]

        self._log.write(json.dumps(rec) + '\n')
        if self._n % 200 == 0:
            self._log.flush()
        return control

    def _control_for_speed(self, control, ego_kmh, target_kmh):
        """Longitudinal only; steering is the planner's throughout."""
        err = target_kmh - ego_kmh
        c = carla.VehicleControl()
        c.steer = control.steer
        c.hand_brake = False
        c.reverse = False
        if err >= 0.0:
            c.throttle = min(control.throttle, 0.75)
            c.brake = 0.0
        else:
            deficit = min(1.0, -err / max(10.0, ego_kmh))
            c.throttle = 0.0
            c.brake = float(min(1.0, 0.25 + 0.75 * deficit))
        return c

    def destroy(self, results=None):
        try:
            s = self.arbiter.summary()
            s['ticks_without_boxes'] = self._no_box_ticks
            self._log.write(json.dumps({'summary': s}) + '\n')
            self._log.close()
            print(f'[ACG-NSM/shared] {s}')
            if self._no_box_ticks > 0.5 * max(self._n, 1):
                print('[ACG-NSM/shared] WARNING the planner supplied no boxes '
                      'on most ticks; the conversion path is probably still '
                      'disabled and the conservative channel saw nothing')
        except Exception:
            pass
        try:
            super().destroy(results)
        except Exception:
            super().destroy()
