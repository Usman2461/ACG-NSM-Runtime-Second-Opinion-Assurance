"""
56_dual_perception.py
=====================
Runs ACG-NSM twice per tick -- once on its own detector, once on
TransFuser++'s internal object predictions -- and records where the two
disagree about what is in the scene.

Why this module exists
----------------------
The paper claims ACG-NSM is an independent conservative opinion, not a
post-processor of the planner's beliefs. That claim is currently asserted
architecturally (separate detector, separate LiDAR routine) but never
measured. A reviewer who understands runtime assurance will ask what the
independence actually buys, and the honest answer has to be a number.

Running the same conservative reasoning over both perception sources answers
it directly, because the two channels share everything EXCEPT perception: the
same graded bridge, the same thresholds, the same state machine. Any
difference in the conservative speed they demand is therefore attributable to
perception alone.

The four cases, and what each one means
---------------------------------------
    BOTH            both channels assert the hazard.
                    Independence bought nothing here; the planner already
                    had the evidence. Expect this to dominate.

    ONLY_INDEPENDENT the ACG-NSM detector asserts a hazard the planner's own
                    predictions do not contain.
                    This is the case that justifies the architecture. If the
                    planner subsequently collided, an independent monitor had
                    the evidence to prevent it and a shared-perception monitor
                    did not.

    ONLY_PLANNER    the planner predicts an object our detector missed.
                    This is a detector miss, and it is the number that bounds
                    what the conservative channel can do. It also feeds the
                    absence model: these are exactly the situations where
                    asserting "nothing is there" was wrong.

    NEITHER         both blind. If a collision happens here, no perception
                    monitor of this design could have prevented it, and the
                    paper should say so rather than leaving it implied.

The ONLY_PLANNER count is the one to look at first. If it is large, the
independent detector is the weak link and the retrain matters more than the
arbitration policy. If ONLY_INDEPENDENT is non-trivial and lines up with the
baseline's collisions, the independence claim has direct evidence.

Required patch to carla_garage
------------------------------
The planner computes object predictions but does not expose them. One line in
`team_code/sensor_agent.py`, in the same place the target-speed lines were
added, alongside the existing patches (keep a backup):

    # after the network forward pass, where pred_bb / pred_bounding_box is
    # available in the local scope:
    self._last_pred_boxes = pred_bb            # <-- add this line

`config.detect_boxes` must be enabled for the head to run at all. If the
attribute never appears, this module reports the planner channel as
unavailable and the guided run degrades to single-channel rather than
crashing -- but the dual-channel comparison will be empty, so check the
`[dual]` line printed on the first tick.

Box layout
----------
carla_garage returns metric BEV boxes. The column layout has changed between
revisions, so it is configured here rather than assumed, and
`--probe` prints what actually arrived so the mapping can be confirmed in
one run instead of debugged in five.
"""
import os, math, json
import numpy as np

# ---------------------------------------------------------------- box layout
# Column indices into a single predicted box row. Override from the
# environment if a probe shows this revision differs, e.g.
#   ACGNSM_BOX_COLS="x=0,y=1,ex=2,ey=3,yaw=4,speed=5,cls=7,conf=6"
BOX_COLS = {'x': 0, 'y': 1, 'ex': 2, 'ey': 3, 'yaw': 4,
            'speed': 5, 'cls': 7, 'conf': 6}

# carla_garage's bb head predicts vehicles and pedestrians only. Traffic light
# state is NOT among them, which is itself a finding: the planner's object
# predictions cannot support a legality assessment, so on the planner channel
# the signal field is always unknown and only the risk path is comparable.
PLANNER_CLS_VEHICLE = 0
PLANNER_CLS_PEDESTRIAN = 1


def _cols():
    spec = os.environ.get('ACGNSM_BOX_COLS', '').strip()
    if not spec:
        return dict(BOX_COLS)
    out = dict(BOX_COLS)
    for kv in spec.split(','):
        k, _, v = kv.partition('=')
        k = k.strip()
        if k in out and v.strip():
            out[k] = int(v)
    return out


def extract_planner_boxes(agent):
    """Pull the planner's predicted boxes off the agent, defensively.

    Returns (array_or_None, note). The attribute name has moved between
    carla_garage revisions, so several are tried before giving up; the note
    says which one hit, or why nothing did, and is logged once at startup.
    """
    names = ('_last_pred_boxes', '_last_pred_bb', 'pred_bb',
             '_last_bounding_boxes', '_last_boxes')
    for n in names:
        v = getattr(agent, n, None)
        if v is None:
            continue
        try:
            if hasattr(v, 'detach'):
                v = v.detach().cpu().numpy()
            arr = np.asarray(v, dtype=np.float32)
        except Exception as e:
            return None, f'{n} present but not convertible: {e}'
        if arr.ndim == 3 and arr.shape[0] == 1:
            arr = arr[0]
        if arr.ndim != 2 or arr.shape[0] == 0:
            return np.zeros((0, 8), np.float32), f'{n} empty this tick'
        return arr, f'{n} shape={arr.shape}'
    return None, ('no predicted-box attribute found; patch sensor_agent.py '
                  '(see module docstring) and enable config.detect_boxes')


def planner_percept(boxes, ego_kmh, corridor_half_width=1.6,
                    max_range=60.0, min_conf=0.30, assumed_conf=0.85):
    """Convert planner boxes into the perception dict the bridge consumes.

    Deliberately mirrors ACGNSMChannel._detect's output contract so the same
    bridge can consume either without knowing which it got.

    Confidence handling is the delicate part. If the box array carries no
    confidence column, one is NOT invented silently -- `assumed_conf` is used
    and the witness records conf_source='assumed', because a fabricated
    confidence would flow into the calibration and quietly become part of the
    safety argument. This is the same failure as the constant 0.617 absence
    confidence that made every tick a hazard.
    """
    c = _cols()
    has_conf = boxes is not None and boxes.shape[1] > c['conf']
    has_cls = boxes is not None and boxes.shape[1] > c['cls']

    ped = (False, 0.5)
    veh = (False, 0.5)
    gap, gap_conf = 100.0, 0.30
    n_used = 0

    if boxes is not None and boxes.shape[0] > 0:
        best_ped, best_veh = 0.0, 0.0
        for row in boxes:
            conf = float(row[c['conf']]) if has_conf else assumed_conf
            if conf < min_conf:
                continue
            x = float(row[c['x']])
            y = float(row[c['y']])
            d = math.hypot(x, y)
            if d > max_range:
                continue
            n_used += 1
            cls = int(round(float(row[c['cls']]))) if has_cls else PLANNER_CLS_VEHICLE
            if cls == PLANNER_CLS_PEDESTRIAN:
                best_ped = max(best_ped, conf)
            else:
                best_veh = max(best_veh, conf)
            # forward corridor, same geometry as the LiDAR routine so the two
            # obstacle distances are comparable rather than merely similar
            if x > 1.5 and abs(y) < corridor_half_width:
                gap = min(gap, d)
        if best_ped > 0.0:
            ped = (True, best_ped)
        if best_veh > 0.0:
            veh = (True, best_veh)
        if gap < 100.0:
            gap_conf = 0.90 if has_conf else 0.70

    return {
        'pedestrian': ped,
        'oncoming': veh,
        # The planner's box head does not predict signal state. Reporting
        # unknown is correct; inventing a colour here would let the legality
        # assessor make claims the planner never made.
        'traffic_light': (-1, 0.5),
        'obs_dist': (gap, gap_conf),
        'ego_speed': (ego_kmh, 0.95),
    }, {'boxes_total': 0 if boxes is None else int(boxes.shape[0]),
        'boxes_used': n_used,
        'conf_source': 'predicted' if has_conf else 'assumed',
        'cls_source': 'predicted' if has_cls else 'assumed_vehicle'}


def classify(ind_asserted, pln_asserted):
    """Four-way agreement label for one hazard field."""
    if ind_asserted and pln_asserted:
        return 'BOTH'
    if ind_asserted:
        return 'ONLY_INDEPENDENT'
    if pln_asserted:
        return 'ONLY_PLANNER'
    return 'NEITHER'


class DualPerception:
    """Second conservative channel fed from the planner's own predictions.

    Holds its own GradedBridge instance. Sharing one bridge between the two
    channels would be wrong if the bridge carries any state across ticks --
    the hysteresis in the graded fail-safe does -- so each perception source
    gets its own, and the only difference between them stays perception.
    """

    def __init__(self, bridge_factory, speed_limit=50.0, max_range=60.0,
                 min_conf=0.30, verbose=True):
        self.bridge = bridge_factory()
        self.speed_limit = speed_limit
        self.max_range = max_range
        self.min_conf = min_conf
        self.verbose = verbose
        self._announced = False
        self.available = None
        self.tally = {k: {'BOTH': 0, 'ONLY_INDEPENDENT': 0,
                          'ONLY_PLANNER': 0, 'NEITHER': 0}
                      for k in ('pedestrian', 'oncoming')}
        self.n = 0
        self.n_planner_more_conservative = 0
        self.n_independent_more_conservative = 0
        self.speed_gap_sum = 0.0

    def step(self, agent, ego_kmh, independent_out, u_c_independent,
             maneuver='PROCEED'):
        """Returns (u_c_planner_or_None, record). Never raises into the agent."""
        boxes, note = extract_planner_boxes(agent)
        if not self._announced:
            self._announced = True
            self.available = boxes is not None
            if self.verbose:
                print(f'[dual] planner boxes: {note}')
        if boxes is None:
            return None, {'available': False, 'note': note}

        percept, meta = planner_percept(
            boxes, ego_kmh, max_range=self.max_range, min_conf=self.min_conf)
        out = self.bridge.process(percept, {'speed_limit': self.speed_limit})
        u_c_planner = self.bridge.target_speed(out, maneuver)

        self.n += 1
        agree = {}
        for field in ('pedestrian', 'oncoming'):
            a = bool(independent_out['asserted'].get(field, False))
            b = bool(out['asserted'].get(field, False))
            lab = classify(a, b)
            agree[field] = lab
            self.tally[field][lab] += 1

        gap = u_c_independent - u_c_planner
        self.speed_gap_sum += abs(gap)
        if gap > 1e-6:
            self.n_planner_more_conservative += 1
        elif gap < -1e-6:
            self.n_independent_more_conservative += 1

        return u_c_planner, {
            'available': True,
            'boxes': meta,
            'agreement': agree,
            'risk_graded': round(out['risk_graded'], 4),
            'risk_tier': out['risk_tier'],
            'asserted': out['asserted'],
            'gap_effective': round(out['gap_effective'], 2),
            'u_conservative_planner': round(u_c_planner, 2),
            'u_conservative_independent': round(u_c_independent, 2),
            'speed_delta': round(gap, 2),
        }

    def summary(self):
        """What goes in the paper's independence table."""
        if not self.n:
            return {'ticks': 0, 'available': bool(self.available)}
        s = {'ticks': self.n, 'available': True, 'agreement': {}}
        for field, t in self.tally.items():
            tot = sum(t.values()) or 1
            s['agreement'][field] = {
                k: {'n': v, 'pct': round(100.0 * v / tot, 2)}
                for k, v in t.items()}
        s['planner_more_conservative_pct'] = round(
            100.0 * self.n_planner_more_conservative / self.n, 2)
        s['independent_more_conservative_pct'] = round(
            100.0 * self.n_independent_more_conservative / self.n, 2)
        s['mean_abs_speed_delta_kmh'] = round(self.speed_gap_sum / self.n, 3)
        return s


# ------------------------------------------------------------------- probing
def probe(path):
    """Print what a witness log says about the planner box layout.

    Run this on a short observe-only guided run before trusting the class and
    confidence columns; a wrong column index would silently turn every
    pedestrian into a vehicle and the disagreement table into fiction.
    """
    seen, shapes, notes = 0, set(), set()
    with open(path) as f:
        for line in f:
            try:
                r = json.loads(line)
            except Exception:
                continue
            d = (r.get('dual') or {})
            if not d:
                continue
            if 'note' in d:
                notes.add(d['note'])
            b = d.get('boxes')
            if b:
                seen += 1
                shapes.add((b.get('conf_source'), b.get('cls_source')))
    print(f'ticks with planner boxes : {seen}')
    print(f'confidence / class source: {sorted(shapes)}')
    for n in sorted(notes):
        print(f'note: {n}')
    if any(s[0] == 'assumed' for s in shapes):
        print('\n[warn] confidence column not found, so a constant was used. '
              'Confirm the layout and set ACGNSM_BOX_COLS before quoting any '
              'number that depends on planner confidence.')


if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--probe', help='witness .jsonl from an observe-only run')
    a = ap.parse_args()
    if a.probe:
        probe(a.probe)
        raise SystemExit(0)

    print(__doc__)
    print('self-test: synthetic boxes -> perception dict\n')
    c = _cols()
    w = max(c.values()) + 1
    rows = []
    for x, y, cls, conf in ((12.0, 0.4, PLANNER_CLS_PEDESTRIAN, 0.91),
                            (28.0, -0.8, PLANNER_CLS_VEHICLE, 0.77),
                            (55.0, 9.0, PLANNER_CLS_VEHICLE, 0.42),
                            (8.0, 0.2, PLANNER_CLS_VEHICLE, 0.11)):
        r = np.zeros(w, np.float32)
        r[c['x']], r[c['y']], r[c['cls']], r[c['conf']] = x, y, cls, conf
        rows.append(r)
    boxes = np.stack(rows)
    p, meta = planner_percept(boxes, ego_kmh=30.0)
    for k, v in p.items():
        print(f'   {k:>14}: {v}')
    print(f'   meta: {meta}')
    print('\n   (the 0.11-confidence box is below min_conf and the 55 m box is '
          'out of the corridor, so the gap is the 12 m pedestrian)')
    print('\nagreement labels:')
    for a_, b_ in ((True, True), (True, False), (False, True), (False, False)):
        print(f'   independent={a_!s:<5} planner={b_!s:<5} -> {classify(a_, b_)}')
