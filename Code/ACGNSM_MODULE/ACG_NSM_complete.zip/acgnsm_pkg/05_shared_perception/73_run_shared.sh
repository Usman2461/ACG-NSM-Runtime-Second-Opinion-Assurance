#!/usr/bin/env bash
# 73_run_shared.sh -- ACG-NSM with the planner's own perception (Town12).
#
# The independent detector does not transfer to Town12: it reported no traffic
# lights across 9807 ticks and the gate refused every maneuver. This variant
# reads the boxes TransFuser++ already computes, so the conservative channel
# sees exactly what the planner sees and the question becomes whether the
# planner acted against its own evidence.
set -euo pipefail

GARAGE=${GARAGE:-/mnt/d/carla_garage}
PROJ=${PROJ:-/mnt/d/NSTM_Project}
export CARLA_ROOT=${CARLA_ROOT:-/mnt/d/CARLA_0.9.15/WindowsNoEditor}
export SCENARIO_RUNNER_ROOT=${GARAGE}/scenario_runner
export LEADERBOARD_ROOT=${GARAGE}/leaderboard
export PYTHONPATH="${CARLA_ROOT}/PythonAPI/carla:${SCENARIO_RUNNER_ROOT}:${LEADERBOARD_ROOT}:${GARAGE}/team_code:${PYTHONPATH:-}"

HOST=${HOST:-192.168.144.1}; PORT=${PORT:-2000}; TM_PORT=${TM_PORT:-8000}
ROUTES_NAME=${ROUTES:-routes_devtest}
export ROUTES=${LEADERBOARD_ROOT}/data/${ROUTES_NAME}.xml
export TEAM_AGENT=${PROJ}/src_shared/71_shared_agent.py
export TEAM_CONFIG=${TEAM_CONFIG:-${GARAGE}/pretrained_models/all_towns}

OUT=${OUT:-${PROJ}/results/shared_${ROUTES_NAME}}
mkdir -p "${OUT}"
export CHECKPOINT_ENDPOINT=${OUT}/${ROUTES_NAME}_results.json
export ACGNSM_LOG=${OUT}/${ROUTES_NAME}_witness.jsonl
export SAVE_PATH=${OUT}/logs; mkdir -p "${SAVE_PATH}"

# planner behaviour, as published
export CHALLENGE_TRACK_CODENAME=SENSORS
export REPETITIONS=1 RESUME=0 SEED=${SEED:-0}
export DEBUG_ENV_AGENT=0 RECORD=0 DIRECT=1 COMPILE=0
export TOWN=eval REPETITION=0 DATAGEN=0
export TUNED_AIM_DISTANCE=0 SLOWER=0 UNCERTAINTY_WEIGHT=1
export STOP_AFTER_METER=-1 STOP_CONTROL=${STOP_CONTROL:-1}
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1

# ACG-NSM
export ACGNSM_ARBITRATE=${ACGNSM_ARBITRATE:-0}
export ACGNSM_TAU=${ACGNSM_TAU:-0.25}
export ACGNSM_LAMBDA=${ACGNSM_LAMBDA:-0.6667}
export ACGNSM_POLICY=${ACGNSM_POLICY:-suppress}
export ACGNSM_SHARED_RECALL=${ACGNSM_SHARED_RECALL:-0.85}
export ACGNSM_SHARED_DET_CONF=${ACGNSM_SHARED_DET_CONF:-0.90}

echo "=================================================================="
echo " variant           : SHARED perception (planner's own boxes)"
echo " routes            : ${ROUTES}"
echo " agent             : ${TEAM_AGENT}"
echo " arbitrate         : ${ACGNSM_ARBITRATE}   lambda=${ACGNSM_LAMBDA}  tau=${ACGNSM_TAU}"
echo " witness           : ${ACGNSM_LOG}"
echo "=================================================================="

cd "${GARAGE}"
python -u "${LEADERBOARD_ROOT}/leaderboard/leaderboard_evaluator_local.py" \
  --host="${HOST}" --port="${PORT}" \
  --traffic-manager-port="${TM_PORT}" --traffic-manager-seed="${SEED}" \
  --routes="${ROUTES}" --repetitions="${REPETITIONS}" \
  --track="${CHALLENGE_TRACK_CODENAME}" \
  --checkpoint="${CHECKPOINT_ENDPOINT}" \
  --agent="${TEAM_AGENT}" --agent-config="${TEAM_CONFIG}" \
  --debug=0 --resume="${RESUME}"

echo; echo "[OK] results : ${CHECKPOINT_ENDPOINT}"; echo "[OK] witness : ${ACGNSM_LOG}"
