# Shared-perception ACG-NSM

ACG-NSM reading the planner's own bounding boxes instead of an independent
detector. Built for Town12, where the Town10-trained detector does not
transfer: it reported no traffic lights across 9807 ticks and the gate refused
every maneuver.

## What this variant can and cannot show

CAN: whether TransFuser++ acted against evidence it already had. If its own
boxes showed an obstacle and it drove into it, ACG-NSM catches that with no
perception advantage at all.

CANNOT: whether independent sensing would have caught something the planner
missed. A hazard absent from the planner's boxes is absent here too. This is a
consistency check on the planner's reasoning, not redundant sensing.

## Signal field

TransFuser++ has no traffic-light output, so the signal field is marked
UNAVAILABLE and excluded from the gate and from legality. A field the sensor
cannot report is not a field reported with low confidence -- conflating the two
is what made the first Town12 run assert a red light on every tick from a
signal it never saw. Article 38 therefore cannot be evaluated in this
configuration, which is a property of the experiment rather than a defect.

## Install

    mkdir -p /mnt/d/NSTM_Project/src_shared
    cp 7*.py 5*.py /mnt/d/NSTM_Project/src_shared/
    cp 73_run_shared.sh /mnt/d/NSTM_Project/src_shared/

    # expose the planner's boxes (backup written, idempotent)
    python /mnt/d/NSTM_Project/src_shared/72_patch_boxes.py --garage /mnt/d/carla_garage

## Run

    cd /mnt/d/NSTM_Project

    # observe only -- changes nothing, drive matches the baseline
    ACGNSM_ARBITRATE=0 ROUTES=routes_devtest \
    OUT=/mnt/d/NSTM_Project/results/shared_observe \
      bash src_shared/73_run_shared.sh 2>&1 | grep -v "^=== \[Agent\]" \
      | tee results/shared_observe.log

    # guided -- suppression applied
    ACGNSM_ARBITRATE=1 ROUTES=routes_devtest \
    OUT=/mnt/d/NSTM_Project/results/shared_guided \
      bash src_shared/73_run_shared.sh 2>&1 | grep -v "^=== \[Agent\]" \
      | tee results/shared_guided.log

## Check first

The startup banner must show

    [ACG-NSM/shared] channel ready  tau=0.25  signal field marked unavailable

and after 2-3 minutes the witness should contain non-zero `n_boxes`. If
`n_boxes` is 0 on most ticks the conversion guard did not take effect and the
channel is seeing nothing -- 72_patch_boxes.py prints a warning for this case
at the end of a run.

## Revert

    python src_shared/72_patch_boxes.py --garage /mnt/d/carla_garage --revert
