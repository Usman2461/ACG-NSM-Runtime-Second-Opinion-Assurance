"""
72_patch_boxes.py
=================
Exposes the planner's bounding boxes so the shared-perception channel can read
them, and forces the conversion that normally only runs for debug output.

Two edits to carla_garage/team_code/sensor_agent.py, both assignments that
change no behaviour:

  1. after the non-maximum suppression that merges the ensemble's boxes,
     store the result on the agent
  2. relax the guard that skips box conversion unless debug output or the
     aim backbone is active, so the boxes exist to be stored

A timestamped backup is written. Idempotent.

    python src/72_patch_boxes.py --garage /mnt/d/carla_garage
    python src/72_patch_boxes.py --garage /mnt/d/carla_garage --revert
"""
import argparse, glob, os, shutil, time
from pathlib import Path

ANCHOR_NMS = ('bbs_vehicle_coordinate_system = t_u.non_maximum_suppression('
              'bounding_boxes, self.config.iou_treshold_nms)')
STORE = 'self._last_pred_bb = bbs_vehicle_coordinate_system'

GUARD_OLD = ('if self.config.detect_boxes and (compute_debug_output or '
             'self.config.backbone in (\'aim\') or')
GUARD_NEW = ('if self.config.detect_boxes and (True or compute_debug_output or '
             'self.config.backbone in (\'aim\') or')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--garage', default='/mnt/d/carla_garage')
    ap.add_argument('--revert', action='store_true')
    a = ap.parse_args()

    f = Path(a.garage) / 'team_code' / 'sensor_agent.py'
    if not f.is_file():
        raise SystemExit(f'not found: {f}')

    if a.revert:
        baks = sorted(glob.glob(str(f) + '.boxbak.*'))
        if not baks:
            raise SystemExit('no backup from this patch found')
        shutil.copy(baks[-1], f)
        print(f'[OK] restored {baks[-1]}')
        return

    src = f.read_text()
    if STORE in src:
        print('[skip] already patched')
        return

    if ANCHOR_NMS not in src:
        raise SystemExit('[FAIL] non-maximum-suppression line not found; the '
                         'upstream file differs from what this patch expects')

    bak = f'{f}.boxbak.{int(time.time())}'
    shutil.copy(f, bak)

    indent = src[:src.index(ANCHOR_NMS)].split('\n')[-1]
    src = src.replace(ANCHOR_NMS, ANCHOR_NMS + '\n' + indent + STORE, 1)

    n_guard = src.count(GUARD_OLD)
    if n_guard:
        src = src.replace(GUARD_OLD, GUARD_NEW)
    f.write_text(src)

    print(f'[OK] stored boxes on the agent as _last_pred_bb')
    print(f'[OK] relaxed {n_guard} conversion guard(s) so the boxes are built')
    print(f'[OK] backup {bak}')
    if n_guard == 0:
        print('[warn] no conversion guard matched; if the channel reports no '
              'boxes, the guard wording has changed and needs checking')


if __name__ == '__main__':
    main()
